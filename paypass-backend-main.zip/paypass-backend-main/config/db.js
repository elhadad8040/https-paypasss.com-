const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME || 'joudk_pay1',
  process.env.DB_USER || 'joudk_pay2',
  process.env.DB_PASSWORD || 'c[bbpu*6OWDy',
  {
    host: process.env.DB_HOST || '127.0.0.1',
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    },
    define: {
      timestamps: true,
      underscored: true,
      freezeTableName: true
    }
  }
);

const connectDB = async () => {
  try {
    console.log('Attempting to connect to database...');
    console.log('Host:', process.env.DB_HOST || '127.0.0.1');
    console.log('Database:', process.env.DB_NAME || 'joudk_pay1');
    console.log('User:', process.env.DB_USER || 'joudk_pay2');
    
    await sequelize.authenticate();
    console.log('MySQL database connected successfully.');
    
    // Load associations
    require('./associations');
    
    // Sync all models with database (force: false to avoid dropping tables)
    await sequelize.sync({ force: false, alter: false });
    console.log('Database synchronized.');
  } catch (err) {
    console.error('Unable to connect to the database:', err.message);
    console.log('Starting server without database connection for testing...');
    
    // Continue without database for testing
    console.log('Server will run in test mode without database.');
  }
};

module.exports = { sequelize, connectDB }; 