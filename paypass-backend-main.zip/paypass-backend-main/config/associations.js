const User = require('../modules/user/user.model');
const Car = require('../modules/car/car.model');
const Package = require('../modules/package/package.model');
const UserPackage = require('../modules/package/userPackage.model');
const WashingPlace = require('../modules/washingPlace/washingPlace.model');
const Wash = require('../modules/wash/wash.model');
const Payment = require('../modules/payment/payment.model');
const Feedback = require('../modules/feedback/feedback.model');
const Notification = require('../modules/feedback/notification.model');
const Referral = require('../modules/user/referral.model');

// User Associations
User.hasMany(Car, { foreignKey: 'userId', as: 'cars' });
User.hasMany(UserPackage, { foreignKey: 'userId', as: 'userPackages' });
User.hasMany(Wash, { foreignKey: 'userId', as: 'washes' });
User.hasMany(Payment, { foreignKey: 'userId', as: 'payments' });
User.hasMany(Feedback, { foreignKey: 'userId', as: 'feedbacks' });
User.hasMany(Notification, { foreignKey: 'userId', as: 'notifications' });
User.hasMany(Referral, { foreignKey: 'inviterId', as: 'sentReferrals' });
User.hasMany(Referral, { foreignKey: 'inviteeId', as: 'receivedReferrals' });

// Car Associations
Car.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Car.hasMany(Wash, { foreignKey: 'carId', as: 'washes' });

// Package Associations
Package.hasMany(UserPackage, { foreignKey: 'packageId', as: 'userPackages' });
Package.hasMany(Wash, { foreignKey: 'packageId', as: 'washes' });
Package.hasMany(Payment, { foreignKey: 'packageId', as: 'payments' });

// UserPackage Associations
UserPackage.belongsTo(User, { foreignKey: 'userId', as: 'user' });
UserPackage.belongsTo(Package, { foreignKey: 'packageId', as: 'package' });

// WashingPlace Associations
WashingPlace.hasMany(Wash, { foreignKey: 'washingPlaceId', as: 'washes' });
WashingPlace.hasMany(Feedback, { foreignKey: 'washingPlaceId', as: 'feedbacks' });
WashingPlace.hasMany(Payment, { foreignKey: 'stationId', as: 'payments' });

// Wash Associations
Wash.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Wash.belongsTo(Car, { foreignKey: 'carId', as: 'car' });
Wash.belongsTo(WashingPlace, { foreignKey: 'washingPlaceId', as: 'washingPlace' });
Wash.belongsTo(Package, { foreignKey: 'packageId', as: 'package' });
Wash.belongsTo(User, { foreignKey: 'ownerId', as: 'owner' });
Wash.hasOne(Feedback, { foreignKey: 'washId', as: 'feedback' });

// Payment Associations
Payment.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Payment.belongsTo(Package, { foreignKey: 'packageId', as: 'package' });
Payment.belongsTo(WashingPlace, { foreignKey: 'stationId', as: 'station' });

// Feedback Associations
Feedback.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Feedback.belongsTo(Wash, { foreignKey: 'washId', as: 'wash' });
Feedback.belongsTo(WashingPlace, { foreignKey: 'washingPlaceId', as: 'washingPlace' });

// Notification Associations
Notification.belongsTo(User, { foreignKey: 'userId', as: 'user' });
Notification.belongsTo(Wash, { foreignKey: 'relatedWashId', as: 'relatedWash' });
Notification.belongsTo(Feedback, { foreignKey: 'relatedFeedbackId', as: 'relatedFeedback' });

// Referral Associations
Referral.belongsTo(User, { foreignKey: 'inviterId', as: 'inviter' });
Referral.belongsTo(User, { foreignKey: 'inviteeId', as: 'invitee' });

module.exports = {
  User,
  Car,
  Package,
  UserPackage,
  WashingPlace,
  Wash,
  Payment,
  Feedback,
  Notification,
  Referral
}; 