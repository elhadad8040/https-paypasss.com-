const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const Car = sequelize.define('Car', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  make: {
    type: DataTypes.STRING,
    allowNull: false
  },
  model: {
    type: DataTypes.STRING,
    allowNull: false
  },
  year: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  licensePlate: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  color: {
    type: DataTypes.STRING,
    allowNull: true
  },
  type: {
    type: DataTypes.ENUM('sedan', 'suv', 'truck', 'van', 'coupe', 'convertible', 'wagon', 'other'),
    allowNull: false
  },
  size: {
    type: DataTypes.ENUM('small', 'medium', 'large'),
    allowNull: false
  }
}, {
  tableName: 'cars'
});

module.exports = Car; 