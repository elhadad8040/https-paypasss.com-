const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const UserPackage = sequelize.define('UserPackage', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  packageId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'packages',
      key: 'id'
    }
  },
  carSize: {
    type: DataTypes.ENUM('sedan', 'suv', 'truck', 'van', 'luxury'),
    allowNull: false,
    comment: 'Car size category for this package'
  },
  barcode: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    comment: 'barcode/QR code string'
  },
  barcodeImage: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'base64 or URL to QR image'
  },
  washesLeft: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  expiry: {
    type: DataTypes.DATE,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('active', 'expired', 'used'),
    defaultValue: 'active'
  }
}, {
  tableName: 'user_packages'
});

module.exports = UserPackage; 