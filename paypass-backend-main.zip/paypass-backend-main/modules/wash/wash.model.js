const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const Wash = sequelize.define('Wash', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  carId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'cars',
      key: 'id'
    }
  },
  washingPlaceId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'washing_places',
      key: 'id'
    }
  },
  packageId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'packages',
      key: 'id'
    }
  },
  ownerId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'users',
      key: 'id'
    },
    comment: 'Owner who scanned the QR code'
  },
  date: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  },
  status: {
    type: DataTypes.ENUM('scheduled', 'completed', 'cancelled'),
    defaultValue: 'scheduled'
  },
  feedbackId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'feedbacks',
      key: 'id'
    }
  },
  tip: {
    type: DataTypes.DECIMAL(10, 2),
    defaultValue: 0
  }
}, {
  tableName: 'washes'
});

module.exports = Wash; 