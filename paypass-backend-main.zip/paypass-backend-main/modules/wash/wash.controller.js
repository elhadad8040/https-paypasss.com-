const UserPackage = require('../package/userPackage.model');
const Package = require('../package/package.model');
const Car = require('../car/car.model');
const Wash = require('./wash.model');
const { sendNotification } = require('../../services/notification');
const { Op } = require('sequelize');

exports.createWash = async (req, res) => {
  try {
    const wash = await Wash.create({ ...req.body, userId: req.user.id });
    res.status(201).json(wash);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getWashes = async (req, res) => {
  try {
    const washes = await Wash.findAll({
      where: { userId: req.user.id },
      include: [
        { model: require('../washingPlace/washingPlace.model'), as: 'washingPlace' },
        { model: Package, as: 'package' },
        { model: require('../feedback/feedback.model'), as: 'feedback' }
      ]
    });
    res.json(washes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getWash = async (req, res) => {
  try {
    const wash = await Wash.findOne({
      where: { id: req.params.id, userId: req.user.id },
      include: [
        { model: require('../washingPlace/washingPlace.model'), as: 'washingPlace' },
        { model: Package, as: 'package' }
      ]
    });
    if (!wash) return res.status(404).json({ error: 'Wash not found' });
    res.json(wash);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateWash = async (req, res) => {
  try {
    const wash = await Wash.findOne({
      where: { id: req.params.id, userId: req.user.id }
    });
    if (!wash) return res.status(404).json({ error: 'Wash not found' });
    
    await wash.update(req.body);
    res.json(wash);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteWash = async (req, res) => {
  try {
    const wash = await Wash.findOne({
      where: { id: req.params.id, userId: req.user.id }
    });
    if (!wash) return res.status(404).json({ error: 'Wash not found' });
    
    await wash.destroy();
    res.json({ message: 'Wash deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.scanBarcodeAndDeductWash = async (req, res) => {
  try {
    const { barcode, washingPlace } = req.body;
    // Find active user package by barcode
    const userPackage = await UserPackage.findOne({
      where: {
        barcode,
        status: 'active',
        expiry: { [Op.gt]: new Date() },
        washesLeft: { [Op.gt]: 0 }
      },
      include: [
        { model: require('../user/user.model'), as: 'user' },
        { model: Package, as: 'package' }
      ]
    });
    if (!userPackage) return res.status(400).json({ error: 'Invalid or expired barcode, or no washes left' });
    
    // Deduct a wash
    userPackage.washesLeft -= 1;
    if (userPackage.washesLeft === 0) userPackage.status = 'used';
    await userPackage.save();
    
    // Create wash record
    const wash = await Wash.create({
      userId: userPackage.userId,
      washingPlaceId: washingPlace,
      packageId: userPackage.packageId,
      status: 'completed',
      ownerId: req.user.id, // set owner to the scanning owner
    });
    
    // Send feedback notification
    await sendNotification({
      user: userPackage.userId,
      type: 'feedback',
      message: 'Please rate your recent wash and optionally add a tip.',
      relatedWash: wash.id,
    });
    
    res.json({
      user: userPackage.user,
      carSize: userPackage.carSize,
      package: userPackage.package,
      washesLeft: userPackage.washesLeft,
      expiry: userPackage.expiry,
      wash,
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get all washes performed by the current owner
exports.getWashesByOwner = async (req, res) => {
  try {
    const washes = await Wash.findAll({
      where: { ownerId: req.user.id },
      include: [
        { model: require('../user/user.model'), as: 'user' },
        { model: Package, as: 'package' },
        { model: require('../washingPlace/washingPlace.model'), as: 'washingPlace' }
      ]
    });
    res.json(washes);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}; 