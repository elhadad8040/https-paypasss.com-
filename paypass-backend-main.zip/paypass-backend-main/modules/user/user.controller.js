const User = require("./user.model");
const jwt = require("jsonwebtoken");
const UserPackage = require("../package/userPackage.model");
const Package = require("../package/package.model");
const Referral = require("./referral.model");
const crypto = require("crypto");
const { generateOTP, isOTPValid } = require("../../services/otp");
const { sendNotification } = require("../../services/notification");
const admin = require('../../config/firebase');

exports.register = async (req, res) => {
  try {
    const user = await User.create(req.body);
    res.status(201).json({ message: "User registered" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const user = await User.findOne({ where: { email: req.body.email } });
    if (!user) return res.status(400).json({ error: "Invalid credentials" });
    const isMatch = await user.comparePassword(req.body.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "7d" }
    );
    const userData = user.toJSON();
    delete userData.password;
    res.json({ token, user: userData });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: { exclude: ['password'] }
    });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);
    if (!user) return res.status(404).json({ error: "User not found" });
    
    await user.update(req.body);
    const userData = user.toJSON();
    delete userData.password;
    res.json(userData);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.deleteProfile = async (req, res) => {
  try {
    await User.destroy({ where: { id: req.user.id } });
    res.json({ message: "User deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getActiveUserPackages = async (req, res) => {
  try {
    const userPackages = await UserPackage.findAll({
      where: {
        userId: req.user.id,
        status: "active",
        expiry: { [require('sequelize').Op.gt]: new Date() }
      },
      include: [{ model: Package, as: 'package' }]
    });
    res.json(userPackages);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.generateReferralLink = async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id);
    if (!user.referralCode) {
      user.referralCode = crypto.randomBytes(6).toString("hex");
      await user.save();
    }
    const link = `${
      process.env.APP_URL || "http://localhost:3000"
    }/register?ref=${user.referralCode}`;
    res.json({ referralLink: link });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.acceptReferral = async (req, res) => {
  try {
    const { referralCode } = req.body;
    const inviter = await User.findOne({ where: { referralCode } });
    if (!inviter) return res.status(400).json({ error: "Invalid referral code" });
    
    const user = await User.findByPk(req.user.id);
    if (user.referredById) return res.status(400).json({ error: "Already used a referral" });
    
    user.referredById = inviter.id;
    await user.save();
    
    await Referral.create({
      inviterId: inviter.id,
      inviteeId: user.id,
      status: 'completed'
    });
    
    res.json({ message: "Referral accepted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.rewardReferral = async (req, res) => {
  try {
    const { inviteeId } = req.body;
    const referral = await Referral.findOne({
      where: { inviterId: req.user.id, inviteeId, status: 'completed' }
    });
    if (!referral) return res.status(404).json({ error: "Referral not found" });
    
    referral.status = 'rewarded';
    referral.rewardGiven = true;
    await referral.save();
    
    res.json({ message: "Referral rewarded" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.sendOTP = async (req, res) => {
  try {
    const { phone } = req.body;
    const user = await User.findOne({ where: { phone } });
    if (!user) return res.status(404).json({ error: "User not found" });
    
    const otp = generateOTP();
    user.otp = otp;
    user.otpExpires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    await user.save();
    
    await sendNotification({
      user: user.id,
      type: 'otp',
      message: `Your OTP is: ${otp}`,
      phone: user.phone
    });
    
    res.json({ message: "OTP sent" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.verifyOTP = async (req, res) => {
  try {
    const { phone, otp } = req.body;
    const user = await User.findOne({ where: { phone } });
    if (!user) return res.status(404).json({ error: "User not found" });
    
    if (!isOTPValid(user.otp, user.otpExpires, otp)) {
      return res.status(400).json({ error: "Invalid or expired OTP" });
    }
    
    user.otp = null;
    user.otpExpires = null;
    await user.save();
    res.json({ message: "OTP verified successfully (demo mode)" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getReferralStatus = async (req, res) => {
  try {
    // Referrals where user is inviter (sent invites)
    const sent = await Referral.findAll({
      where: { inviterId: req.user.id },
      include: [{ model: User, as: 'invitee', attributes: ['name', 'email'] }]
    });
    // Referrals where user is invitee (was invited)
    const received = await Referral.findAll({
      where: { inviteeId: req.user.id },
      include: [{ model: User, as: 'inviter', attributes: ['name', 'email'] }]
    });
    res.json({ sent, received });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// POST /users/phone-login-initiate
exports.phoneLoginInitiate = async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone number required' });
  const user = await User.findOne({ where: { phone } });
  if (user) {
    return res.json({ exists: true });
  }
  return res.status(404).json({ exists: false, message: 'User not found' });
};

// POST /users/phone-login-verify
exports.phoneLoginVerify = async (req, res) => {
  const { phone, firebaseIdToken } = req.body;
  if (!phone || !firebaseIdToken) return res.status(400).json({ error: 'Phone and firebaseIdToken required' });
  try {
    const decoded = await admin.auth().verifyIdToken(firebaseIdToken);
    if (decoded.phone_number !== phone) {
      return res.status(400).json({ error: 'Phone number mismatch' });
    }
    const user = await User.findOne({ where: { phone } });
    if (!user) return res.status(404).json({ error: 'User not found' });
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    const userData = user.toJSON();
    delete userData.password;
    return res.json({ token, user: userData });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid OTP or token' });
  }
};

// POST /users/phone-signup-initiate
exports.phoneSignupInitiate = async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ error: 'Phone number required' });
  const user = await User.findOne({ where: { phone } });
  if (user) {
    return res.status(409).json({ canRegister: false, message: 'Phone already registered' });
  }
  return res.json({ canRegister: true });
};

// POST /users/phone-signup-verify
exports.phoneSignupVerify = async (req, res) => {
  const { phone, firebaseIdToken, name, email, password, username } = req.body;
  if (!phone || !firebaseIdToken || !name || !email || !password || !username) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  try {
    const decoded = await admin.auth().verifyIdToken(firebaseIdToken);
    if (decoded.phone_number !== phone) {
      return res.status(400).json({ error: 'Phone number mismatch' });
    }
    let user = await User.findOne({ where: { phone } });
    if (user) return res.status(409).json({ error: 'User already exists' });
    user = await User.create({ phone, name, email, password, username });
    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );
    const userData = user.toJSON();
    delete userData.password;
    return res.json({ token, user: userData });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid OTP or token' });
  }
};
