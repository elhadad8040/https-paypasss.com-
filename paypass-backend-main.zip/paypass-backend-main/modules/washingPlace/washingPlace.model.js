const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const WashingPlace = sequelize.define('WashingPlace', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  address: {
    type: DataTypes.STRING,
    allowNull: false
  },
  phone: {
    type: DataTypes.STRING,
    allowNull: false
  },
  hours: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    allowNull: true
  },
  location: {
    type: DataTypes.STRING,
    defaultValue: 'Point'
  },
  city: {
    type: DataTypes.STRING,
    allowNull: true
  },
  rating: {
    type: DataTypes.DECIMAL(3, 2),
    allowNull: true,
    validate: {
      min: 0,
      max: 5
    }
  },
  customers: {
    type: DataTypes.INTEGER,
    allowNull: true
  }
}, {
  tableName: 'washing_places'
});

module.exports = WashingPlace; 