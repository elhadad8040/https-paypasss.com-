const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const Feedback = sequelize.define('Feedback', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  washId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'washes',
      key: 'id'
    }
  },
  washingPlaceId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'washing_places',
      key: 'id'
    }
  },
  rating: {
    type: DataTypes.INTEGER,
    allowNull: false,
    validate: {
      min: 1,
      max: 5
    }
  },
  comment: {
    type: DataTypes.TEXT,
    allowNull: true
  },
  complaint: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'Optional complaint field'
  },
  photo: {
    type: DataTypes.TEXT,
    allowNull: true,
    comment: 'URL or base64 string for car photo after wash'
  }
}, {
  tableName: 'feedbacks'
});

module.exports = Feedback; 