const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db');

const Notification = sequelize.define('Notification', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: 'users',
      key: 'id'
    }
  },
  type: {
    type: DataTypes.ENUM('otp', 'feedback', 'reminder', 'referral', 'general'),
    allowNull: false
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  status: {
    type: DataTypes.ENUM('sent', 'delivered', 'read', 'failed'),
    defaultValue: 'sent'
  },
  relatedWashId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'washes',
      key: 'id'
    }
  },
  relatedFeedbackId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: 'feedbacks',
      key: 'id'
    }
  },
  sentAt: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW
  }
}, {
  tableName: 'notifications'
});

module.exports = Notification; 