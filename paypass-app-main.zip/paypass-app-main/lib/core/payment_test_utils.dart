import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'payment_message_handler.dart';

/// Test utilities for payment messaging system
class PaymentTestUtils {
  
  /// Test payment success scenario
  static Future<void> testPaymentSuccess(BuildContext context) async {
    final testResult = {
      'success': true,
      'transactionId': 'TEST_${DateTime.now().millisecondsSinceEpoch}',
      'message': 'تم الدفع بنجاح (اختبار)',
      'details': 'This is a test payment success',
    };
    
    if (kIsWeb) {
      // Store in localStorage for web testing
      PaymentMessageHandler.storePaymentResult(testResult);
      
      // Show test message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إرسال نتيجة الدفع الناجحة للاختبار'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      // Send via MethodChannel for mobile testing
      await PaymentMessageHandler.sendTestPaymentResult(testResult);
      
      // Show test message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إرسال نتيجة الدفع الناجحة للاختبار'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }
  
  /// Test payment failure scenario
  static Future<void> testPaymentFailure(BuildContext context) async {
    final testResult = {
      'success': false,
      'transactionId': 'TEST_FAIL_${DateTime.now().millisecondsSinceEpoch}',
      'message': 'فشل في الدفع (اختبار)',
      'details': 'This is a test payment failure',
    };
    
    if (kIsWeb) {
      // Store in localStorage for web testing
      PaymentMessageHandler.storePaymentResult(testResult);
      
      // Show test message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إرسال نتيجة الدفع الفاشلة للاختبار'),
          backgroundColor: Colors.orange,
        ),
      );
    } else {
      // Send via MethodChannel for mobile testing
      await PaymentMessageHandler.sendTestPaymentResult(testResult);
      
      // Show test message
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تم إرسال نتيجة الدفع الفاشلة للاختبار'),
          backgroundColor: Colors.orange,
        ),
      );
    }
  }
  
  /// Show test buttons in a dialog
  static void showTestDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('اختبار نظام الدفع'),
          content: const Text('اختر نوع الاختبار:'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                testPaymentSuccess(context);
              },
              child: const Text('اختبار الدفع الناجح'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                testPaymentFailure(context);
              },
              child: const Text('اختبار الدفع الفاشل'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('إلغاء'),
            ),
          ],
        );
      },
    );
  }
  
  /// Check if payment message handler is working
  static Future<bool> checkMessageHandlerStatus() async {
    try {
      await PaymentMessageHandler.initialize();
      return true;
    } catch (e) {
      print('PaymentTestUtils: Message handler status check failed: $e');
      return false;
    }
  }
  
  /// Get platform-specific information
  static String getPlatformInfo() {
    if (kIsWeb) {
      return 'Web Platform';
    } else {
      return 'Mobile Platform';
    }
  }
} 