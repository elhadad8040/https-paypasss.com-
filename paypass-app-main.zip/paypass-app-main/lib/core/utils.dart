import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'constants.dart';

class AppUtils {
  // تهيئة البيانات المحلية
  static Future<void> initializeLocale() async {
    await initializeDateFormatting('ar', null);
  }

  // تنسيق السعر
  static String formatPrice(double price) {
    final formatter = NumberFormat.currency(
      locale: 'ar_SA',
      symbol: 'ر.س ',
      decimalDigits: 2,
    );
    return formatter.format(price);
  }

  // تنسيق التاريخ
  static String formatDate(DateTime date) {
    final formatter = DateFormat('yyyy/MM/dd', 'ar');
    return formatter.format(date);
  }

  // تنسيق الوقت
  static String formatTime(DateTime time) {
    final formatter = DateFormat('HH:mm', 'ar');
    return formatter.format(time);
  }

  // تنسيق التاريخ والوقت
  static String formatDateTime(DateTime dateTime) {
    final formatter = DateFormat('yyyy/MM/dd HH:mm', 'ar');
    return formatter.format(dateTime);
  }

  // تنسيق التقييم
  static String formatRating(double rating) {
    return rating.toStringAsFixed(1);
  }

  // التحقق من صحة رقم الهاتف
  static bool isValidPhoneNumber(String phone) {
    // التحقق من أن رقم الهاتف يبدأ بـ 05 ويتكون من 10 أرقام
    final phoneRegex = RegExp(r'^05\d{8}$');
    return true;
  }

  // الحصول على أيقونة السيارة حسب النوع
  static IconData getCarIcon(String carType) {
    switch (carType.toLowerCase()) {
      case 'شاحنة صغيرة':
      case 'شاحنة كبيرة':
        return Icons.local_shipping;
      case 'سيارة صغيرة':
      case 'سيارة متوسطة':
      case 'سيارة كبيرة':
      default:
        return Icons.directions_car;
    }
  }

  // الحصول على لون التقييم
  static Color getRatingColor(double rating) {
    if (rating >= 4.5) {
      return kSuccessColor;
    } else if (rating >= 3.5) {
      return kWarningColor;
    } else {
      return kErrorColor;
    }
  }

  // عرض رسالة نجاح
  static void showSuccessSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: kSuccessColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kBorderRadius),
        ),
      ),
    );
  }

  // عرض رسالة خطأ
  static void showErrorSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.error, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: kErrorColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kBorderRadius),
        ),
      ),
    );
  }

  // عرض رسالة تحذير
  static void showWarningSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.warning, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: kWarningColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kBorderRadius),
        ),
      ),
    );
  }

  // عرض رسالة معلومات
  static void showInfoSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.info, color: Colors.white),
            const SizedBox(width: 8),
            Expanded(child: Text(message)),
          ],
        ),
        backgroundColor: kSecondaryColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(kBorderRadius),
        ),
      ),
    );
  }

  // عرض حوار تأكيد
  static Future<bool> showConfirmDialog({
    required BuildContext context,
    required String title,
    required String message,
    String confirmText = kConfirm,
    String cancelText = kCancel,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: Text(cancelText),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
            child: Text(confirmText),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  // عرض حوار معلومات
  static Future<void> showInfoDialog({
    required BuildContext context,
    required String title,
    required String message,
    String okText = 'حسناً',
  }) async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(),
            style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
            child: Text(okText),
          ),
        ],
      ),
    );
  }
}
