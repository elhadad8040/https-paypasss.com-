// نموذج الباقة
class Package {
  final String id;
  final String name;
  final double price;
  final int washes;
  final String description;
  final List<String> features;
  final double? originalPrice;
  final bool isPopular;
  final int validityDays;
  final double? savings;
  final List<String> supportedCarSizes;

  Package({
    required this.id,
    required this.name,
    required this.price,
    required this.washes,
    required this.description,
    required this.features,
    this.originalPrice,
    this.isPopular = false,
    this.validityDays = 30,
    this.savings,
    this.supportedCarSizes = const ['small', 'medium', 'large'],
  });

  factory Package.fromMap(Map<String, dynamic> map) {
    return Package(
      id: map['_id'] ?? map['id'] ?? '',
      name: map['name'] ?? '',
      price: (map['basePrice'] ?? map['price'] ?? 0.0).toDouble(),
      washes: map['washes'] ?? 0,
      description: map['description'] ?? '',
      features: List<String>.from(map['features'] ?? []),
      originalPrice: map['originalPrice'] != null
          ? (map['originalPrice'] ?? 0.0).toDouble()
          : null,
      isPopular: map['popular'] ?? map['isPopular'] ?? false,
      validityDays: map['duration'] ?? map['validityDays'] ?? 30,
      savings:
          map['savings'] != null ? (map['savings'] ?? 0.0).toDouble() : null,
      supportedCarSizes: List<String>.from(
          map['supportedCarSizes'] ?? ['small', 'medium', 'large']),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'basePrice': price,
      'washes': washes,
      'description': description,
      'features': features,
      'originalPrice': originalPrice,
      'popular': isPopular,
      'duration': validityDays,
      'savings': savings,
      'supportedCarSizes': supportedCarSizes,
    };
  }
}

// نموذج السيارة
class Car {
  final String id;
  final String name;
  final String type;
  final double priceMultiplier;
  final String plateNumber;
  final String color;
  final String make;
  final String model;
  final int year;
  final String size;

  Car({
    required this.id,
    required this.name,
    required this.type,
    required this.priceMultiplier,
    required this.plateNumber,
    required this.color,
    required this.make,
    required this.model,
    required this.year,
    required this.size,
  });

  factory Car.fromMap(Map<String, dynamic> map) {
    return Car(
      id: map['_id'] ?? map['id'] ?? '',
      name: '${map['make'] ?? ''} ${map['model'] ?? ''}',
      type: map['type'] ?? '',
      priceMultiplier: (map['priceMultiplier'] ?? 1.0).toDouble(),
      plateNumber: map['licensePlate'] ?? map['plateNumber'] ?? '',
      color: map['color'] ?? '',
      make: map['make'] ?? '',
      model: map['model'] ?? '',
      year: map['year'] ?? 0,
      size: map['size'] ?? 'medium',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'make': make,
      'model': model,
      'year': year,
      'licensePlate': plateNumber,
      'color': color,
      'type': type,
      'size': size,
    };
  }
}

// نموذج محطة الغسيل
class WashStation {
  final String id;
  final String name;
  final String location;
  final String distance;
  final double rating;
  final bool isNearest;
  final bool isOpen;
  final List<String> availableServices;
  final String address;
  final String phone;
  final String hours;
  final String? email;
  final String? city;
  final int availableWashingMachines;
  final List<String> supportedCarSizes;

  WashStation({
    required this.id,
    required this.name,
    required this.location,
    required this.distance,
    required this.rating,
    required this.isNearest,
    required this.isOpen,
    required this.availableServices,
    required this.address,
    required this.phone,
    required this.hours,
    this.email,
    this.city,
    this.availableWashingMachines = 5,
    this.supportedCarSizes = const ['small', 'medium', 'large'],
  });

  factory WashStation.fromMap(Map<String, dynamic> map) => WashStation(
        id: map['_id'] ?? map['id'] ?? '',
        name: map['name'] ?? '',
        location: map['address'] ?? map['location'] ?? '',
        distance: map['distance'] ?? '0.5 كم',
        rating: (map['avgRating'] ?? map['rating'] ?? 0.0).toDouble(),
        isNearest: map['isNearest'] ?? false,
        isOpen: map['isOpen'] ?? true,
        availableServices: List<String>.from(map['availableServices'] ?? []),
        address: map['address'] ?? '',
        phone: map['phone'] ?? '',
        hours: map['hours'] ?? '',
        email: map['email'],
        city: map['city'],
        availableWashingMachines: map['availableWashingMachines'] ?? 5,
        supportedCarSizes: List<String>.from(
            map['supportedCarSizes'] ?? ['small', 'medium', 'large']),
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'location': location,
        'distance': distance,
        'rating': rating,
        'isNearest': isNearest,
        'isOpen': isOpen,
        'availableServices': availableServices,
        'address': address,
        'phone': phone,
        'hours': hours,
        'email': email,
        'city': city,
        'availableWashingMachines': availableWashingMachines,
        'supportedCarSizes': supportedCarSizes,
      };
}

// نموذج الطلب
class Order {
  final String id;
  final String userId;
  final String packageId;
  final String? stationId; // جعل معرف المحطة اختياري
  final double totalPrice;
  final DateTime orderDate;
  final String status;
  String qrCode;
  final DateTime expiryDate;
  final int remainingWashes;
  final String carSize; // required
  // Hotel fields for VIP package
  final String? hotelName;
  final String? guestName;
  final String? guestEmail;
  final String? roomNumber;

  Order({
    required this.id,
    required this.userId,
    required this.packageId,
    this.stationId, // جعل معرف المحطة اختياري
    required this.totalPrice,
    required this.orderDate,
    required this.status,
    required this.qrCode,
    required this.expiryDate,
    required this.remainingWashes,
    required this.carSize,
    this.hotelName,
    this.guestName,
    this.guestEmail,
    this.roomNumber,
  });

  factory Order.fromMap(Map<String, dynamic> map) => Order(
        id: map['_id'] ?? map['id'] ?? '',
        userId: map['user'] ?? map['userId'] ?? '',
        packageId: map['package'] ?? map['packageId'] ?? '',
        stationId:
            map['washingPlace'] ?? map['stationId'], // جعل معرف المحطة اختياري
        totalPrice: (map['totalPrice'] ?? 0.0).toDouble(),
        orderDate: map['date'] != null
            ? DateTime.parse(map['date'])
            : DateTime.parse(
                map['orderDate'] ?? DateTime.now().toIso8601String()),
        status: map['status'] ?? 'scheduled',
        qrCode: map['qrCode'] ?? '',
        expiryDate: map['expiryDate'] != null
            ? DateTime.parse(map['expiryDate'])
            : DateTime.now().add(const Duration(days: 30)),
        remainingWashes: map['remainingWashes'] ?? 0,
        carSize: map['carSize'] ?? 'medium',
        hotelName: map['hotelName'],
        guestName: map['guestName'],
        guestEmail: map['guestEmail'],
        roomNumber: map['roomNumber'],
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'user': userId,
        'package': packageId,
        if (stationId != null)
          'washingPlace': stationId, // إضافة معرف المحطة فقط إذا كان موجودًا
        'date': orderDate.toIso8601String(),
        'status': status,
        'qrCode': qrCode,
        'expiryDate': expiryDate.toIso8601String(),
        'remainingWashes': remainingWashes,
        'carSize': carSize,
        if (hotelName != null) 'hotelName': hotelName,
        if (guestName != null) 'guestName': guestName,
        if (guestEmail != null) 'guestEmail': guestEmail,
        if (roomNumber != null) 'roomNumber': roomNumber,
      };

  bool get isExpired => DateTime.now().isAfter(expiryDate);

  bool get hasRemainingWashes => remainingWashes > 0;

  bool get canBeUsed => !isExpired && hasRemainingWashes;
}

// نموذج المستخدم
class User {
  final String id;
  final String name;
  final String email;
  final String phone;
  final List<String> cars;
  final List<String> orders;
  final int totalWashesUsed;
  final int totalWashesPurchased;
  final List<String> invitations;
  final int freeWashesEarned;
  final String? referralCode;
  final String? referredBy;
  final List<String> notifications;
  final String? otp;
  final DateTime? otpExpires;
  final String? role;

  User({
    required this.id,
    required this.name,
    required this.email,
    required this.phone,
    required this.cars,
    required this.orders,
    this.totalWashesUsed = 0,
    this.totalWashesPurchased = 0,
    this.invitations = const [],
    this.freeWashesEarned = 0,
    this.referralCode,
    this.referredBy,
    this.notifications = const [],
    this.otp,
    this.otpExpires,
    this.role,
  });

  factory User.fromMap(Map<String, dynamic> map) {
    return User(
      id: map['_id'] ?? map['id'] ?? '',
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      cars: List<String>.from(map['cars'] ?? []),
      orders: List<String>.from(map['orders'] ?? []),
      totalWashesUsed: map['totalWashesUsed'] ?? 0,
      totalWashesPurchased: map['totalWashesPurchased'] ?? 0,
      invitations: List<String>.from(map['invitations'] ?? []),
      freeWashesEarned: map['freeWashesEarned'] ?? 0,
      referralCode: map['referralCode'],
      referredBy: map['referredBy'],
      notifications: List<String>.from(map['notifications'] ?? []),
      otp: map['otp'],
      otpExpires:
          map['otpExpires'] != null ? DateTime.parse(map['otpExpires']) : null,
      role: map['role'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'phone': phone,
      'cars': cars,
      'orders': orders,
      'totalWashesUsed': totalWashesUsed,
      'totalWashesPurchased': totalWashesPurchased,
      'invitations': invitations,
      'freeWashesEarned': freeWashesEarned,
      'referralCode': referralCode,
      'referredBy': referredBy,
      'notifications': notifications,
      'otp': otp,
      'otpExpires': otpExpires?.toIso8601String(),
      'role': role,
    };
  }
}

// نموذج الدفع
class Payment {
  final String id;
  final String orderId;
  final double amount;
  final String method;
  final String status;
  final DateTime paymentDate;
  final String packageId;
  final String? transactionId;
  final String? paymentProvider;

  Payment({
    required this.id,
    required this.orderId,
    required this.amount,
    required this.method,
    required this.status,
    required this.paymentDate,
    required this.packageId,
    this.transactionId,
    this.paymentProvider,
  });

  factory Payment.fromMap(Map<String, dynamic> map) {
    return Payment(
      id: map['_id'] ?? map['id'] ?? '',
      orderId: map['wash'] ?? map['orderId'] ?? '',
      amount: (map['amount'] ?? 0.0).toDouble(),
      method: map['method'] ?? '',
      status: map['status'] ?? 'pending',
      paymentDate: DateTime.parse(map['createdAt'] ??
          map['paymentDate'] ??
          DateTime.now().toIso8601String()),
      packageId: map['package'] ?? '',
      transactionId: map['transactionId'],
      paymentProvider: map['paymentProvider'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'package': packageId,
      'amount': amount,
      'method': method,
      'status': status,
      'transactionId': transactionId,
      'paymentProvider': paymentProvider,
    };
  }
}

// نموذج التقييم
class Feedback {
  final String id;
  final String userId;
  final String? stationId;
  final double rating;
  final String comment;
  final DateTime createdAt;
  final String washId;
  final double? tip;
  final String? washStatus;

  Feedback({
    required this.id,
    required this.userId,
    this.stationId,
    required this.rating,
    required this.comment,
    required this.createdAt,
    required this.washId,
    this.tip,
    this.washStatus,
  });

  factory Feedback.fromMap(Map<String, dynamic> map) {
    return Feedback(
      id: map['_id'] ?? map['id'] ?? '',
      userId: map['user'] ?? map['userId'] ?? '',
      stationId: map['washingPlace'] ?? map['stationId'] ?? '',
      rating: (map['rating'] ?? 0.0).toDouble(),
      comment: map['comment'] ?? '',
      createdAt:
          DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      washId: map['wash'] ?? '',
      tip: map['tip'] != null ? (map['tip'] ?? 0.0).toDouble() : null,
      washStatus: map['washStatus'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user': userId,
      if (stationId != null) 'washingPlace': stationId,
      'rating': rating,
      'comment': comment,
      'wash': washId,
      'tip': tip,
      'washStatus': washStatus,
    };
  }
}

// نموذج الإشعارات
class Notification {
  final String id;
  final String userId;
  final String title;
  final String message;
  final DateTime createdAt;
  final bool isRead;
  final String type;
  final Map<String, dynamic>? data;

  Notification({
    required this.id,
    required this.userId,
    required this.title,
    required this.message,
    required this.createdAt,
    this.isRead = false,
    required this.type,
    this.data,
  });

  factory Notification.fromMap(Map<String, dynamic> map) {
    return Notification(
      id: map['_id'] ?? map['id'] ?? '',
      userId: map['user'] ?? map['userId'] ?? '',
      title: map['title'] ?? '',
      message: map['message'] ?? '',
      createdAt:
          DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      isRead: map['isRead'] ?? false,
      type: map['type'] ?? '',
      data: map['data'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user': userId,
      'title': title,
      'message': message,
      'createdAt': createdAt.toIso8601String(),
      'isRead': isRead,
      'type': type,
      'data': data,
    };
  }
}

// نموذج الشكاوى
class Complaint {
  final String id;
  final String userId;
  final String? stationId;
  final String title;
  final String description;
  final DateTime createdAt;
  final String status;
  final String? adminResponse;
  final DateTime? resolvedAt;

  Complaint({
    required this.id,
    required this.userId,
    this.stationId,
    required this.title,
    required this.description,
    required this.createdAt,
    this.status = 'pending',
    this.adminResponse,
    this.resolvedAt,
  });

  factory Complaint.fromMap(Map<String, dynamic> map) {
    return Complaint(
      id: map['_id'] ?? map['id'] ?? '',
      userId: map['user'] ?? map['userId'] ?? '',
      stationId: map['washingPlace'] ?? map['stationId'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      createdAt:
          DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      status: map['status'] ?? 'pending',
      adminResponse: map['adminResponse'],
      resolvedAt:
          map['resolvedAt'] != null ? DateTime.parse(map['resolvedAt']) : null,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user': userId,
      if (stationId != null) 'washingPlace': stationId,
      'title': title,
      'description': description,
      'createdAt': createdAt.toIso8601String(),
      'status': status,
      'adminResponse': adminResponse,
      'resolvedAt': resolvedAt?.toIso8601String(),
    };
  }
}

// نموذج الدعوات
class Invitation {
  final String id;
  final String inviterId;
  final String inviteePhone;
  final String inviteeName;
  final DateTime createdAt;
  final String status;
  final DateTime? acceptedAt;
  final String? inviteeId;

  Invitation({
    required this.id,
    required this.inviterId,
    required this.inviteePhone,
    required this.inviteeName,
    required this.createdAt,
    this.status = 'sent',
    this.acceptedAt,
    this.inviteeId,
  });

  factory Invitation.fromMap(Map<String, dynamic> map) {
    return Invitation(
      id: map['_id'] ?? map['id'] ?? '',
      inviterId: map['inviter'] ?? map['inviterId'] ?? '',
      inviteePhone: map['inviteePhone'] ?? '',
      inviteeName: map['inviteeName'] ?? '',
      createdAt:
          DateTime.parse(map['createdAt'] ?? DateTime.now().toIso8601String()),
      status: map['status'] ?? 'sent',
      acceptedAt:
          map['acceptedAt'] != null ? DateTime.parse(map['acceptedAt']) : null,
      inviteeId: map['inviteeId'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'inviter': inviterId,
      'inviteePhone': inviteePhone,
      'inviteeName': inviteeName,
      'createdAt': createdAt.toIso8601String(),
      'status': status,
      'acceptedAt': acceptedAt?.toIso8601String(),
      'inviteeId': inviteeId,
    };
  }
}

// نموذج عملية الغسيل
class WashSession {
  final String id;
  final String orderId;
  final String userId;
  final String? stationId;
  final DateTime startTime;
  final DateTime? endTime;
  final String status;
  final String? notes;
  final double? tip;
  final String? feedbackId;
  final String carSize; // required

  WashSession({
    required this.id,
    required this.orderId,
    required this.userId,
    this.stationId,
    required this.startTime,
    this.endTime,
    this.status = 'started',
    this.notes,
    this.tip,
    this.feedbackId,
    required this.carSize,
  });

  factory WashSession.fromMap(Map<String, dynamic> map) {
    return WashSession(
      id: map['_id'] ?? map['id'] ?? '',
      orderId: map['order'] ?? map['orderId'] ?? '',
      userId: map['user'] ?? map['userId'] ?? '',
      stationId: map['washingPlace'] ?? map['stationId'] ?? '',
      startTime:
          DateTime.parse(map['startTime'] ?? DateTime.now().toIso8601String()),
      endTime: map['endTime'] != null ? DateTime.parse(map['endTime']) : null,
      status: map['status'] ?? 'started',
      notes: map['notes'],
      tip: map['tip'] != null ? (map['tip'] ?? 0.0).toDouble() : null,
      feedbackId: map['feedbackId'],
      carSize: map['carSize'] ?? 'medium',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'order': orderId,
      'user': userId,
      if (stationId != null) 'washingPlace': stationId,
      'startTime': startTime.toIso8601String(),
      'endTime': endTime?.toIso8601String(),
      'status': status,
      'notes': notes,
      'tip': tip,
      'feedbackId': feedbackId,
      'carSize': carSize,
    };
  }
}

// نموذج باقة المستخدم (UserPackage)
class UserPackage {
  final String id;
  final String userId;
  final String packageId;
  final String carSize; // required
  final String barcode;
  final String barcodeImage;
  int washesLeft;
  final DateTime expiry;
  final String status; // active, expired, used
  final Package? package;

  UserPackage({
    required this.id,
    required this.userId,
    required this.packageId,
    required this.carSize,
    required this.barcode,
    required this.barcodeImage,
    required this.washesLeft,
    required this.expiry,
    required this.status,
    this.package,
  });

  factory UserPackage.fromMap(Map<String, dynamic> map) {
    return UserPackage(
      id: map['_id'] ?? map['id'] ?? '',
      userId: map['user'] is String ? map['user'] : (map['user']?['_id'] ?? ''),
      packageId: map['package'] is String
          ? map['package']
          : (map['package']?['_id'] ?? ''),
      carSize: map['carSize'] ?? 'medium',
      barcode: map['barcode'] ?? '',
      barcodeImage: map['barcodeImage'] ?? '',
      washesLeft: map['washesLeft'] ?? 0,
      expiry: DateTime.parse(map['expiry'] ?? DateTime.now().toIso8601String()),
      status: map['status'] ?? 'active',
      package: map['package'] is Map ? Package.fromMap(map['package']) : null,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'user': userId,
        'package': packageId,
        'carSize': carSize,
        'barcode': barcode,
        'barcodeImage': barcodeImage,
        'washesLeft': washesLeft,
        'expiry': expiry.toIso8601String(),
        'status': status,
      };
}

// نموذج الإحالة (Referral)
class Referral {
  final String id;
  final String inviterId;
  final String? inviteeId;
  final String? inviteeEmail;
  final String status; // pending, completed, rewarded
  final bool rewardGiven;
  final DateTime createdAt;

  Referral({
    required this.id,
    required this.inviterId,
    this.inviteeId,
    this.inviteeEmail,
    required this.status,
    required this.rewardGiven,
    required this.createdAt,
  });

  factory Referral.fromMap(Map<String, dynamic> map) => Referral(
        id: map['_id'] ?? map['id'] ?? '',
        inviterId: map['inviter'] ?? '',
        inviteeId: map['invitee'],
        inviteeEmail: map['inviteeEmail'],
        status: map['status'] ?? 'pending',
        rewardGiven: map['rewardGiven'] ?? false,
        createdAt: DateTime.parse(
            map['createdAt'] ?? DateTime.now().toIso8601String()),
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'inviter': inviterId,
        'invitee': inviteeId,
        'inviteeEmail': inviteeEmail,
        'status': status,
        'rewardGiven': rewardGiven,
        'createdAt': createdAt.toIso8601String(),
      };
}
