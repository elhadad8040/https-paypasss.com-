class AppConfig {
  // API Configuration
  static const String apiBaseUrl = 'https://paypass-backend-five.vercel.app/api';

  // App Configuration
  static const String appName = 'PayPass';
  static const String appVersion = '1.0.0';
  
  // Timeout Configuration
  static const int connectionTimeout = 30000; // 30 seconds
  static const int receiveTimeout = 30000; // 30 seconds
  
  // Cache Configuration
  static const int cacheExpiryMinutes = 5;
  
  // QR Code Configuration
  static const int qrCodeSize = 200;
  
  // Location Configuration
  static const double defaultLatitude = 24.7136;
  static const double defaultLongitude = 46.6753;
}

// Google Maps Configuration
class MapsConfig {
  // Replace with your actual Google Maps API key
  static const String googleMapsApiKey = 'AIzaSyAGBmm-cAtFewmS4vrr-3vCQdm8O6elFW4';
  
  // Google Maps URLs
  static const String googleMapsBaseUrl = 'https://www.google.com/maps';
  static const String googleMapsSearchUrl = 'https://www.google.com/maps/search';
  
  // Default zoom level for maps
  static const int defaultZoomLevel = 15;
} 