import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'api_service.dart';
import 'config.dart';

class HyperPayService {
  static const String _paymentBaseUrl = 'https://eu-test.oppwa.com';

  /// Launches HyperPay payment on web platform using url_launcher
  static Future<void> launchHyperPayWebPayment({
    required String checkoutId,
    required String amount,
    required String currency,
    required String customerEmail,
    required String customerName,
    String? userId,
    String? packageId,
    String? carSize,
  }) async {
    // Create a simple payment page URL that will redirect to HyperPay
    // In a real implementation, you would host this HTML page on your server
    final paymentUrl = _buildPaymentUrl(
      checkoutId: checkoutId,
      amount: amount,
      currency: currency,
      customerEmail: customerEmail,
      customerName: customerName,
      userId: userId,
      packageId: packageId,
      carSize: carSize,
    );

    final uri = Uri.parse(paymentUrl);

    if (await canLaunchUrl(uri)) {
      await launchUrl(
        uri,
        webOnlyWindowName: '_blank', // Opens in new tab on web
        mode: LaunchMode
            .externalApplication, // Opens in external browser on mobile
      );
    } else {
      throw 'Could not launch payment URL: $paymentUrl';
    }
  }

  /// Builds the payment URL with the checkout ID
  static String _buildPaymentUrl({
    required String checkoutId,
    required String amount,
    required String currency,
    required String customerEmail,
    required String customerName,
    String? userId,
    String? packageId,
    String? carSize,
  }) {
    // Use the API base URL for payment page
    String url =
        '${AppConfig.apiBaseUrl.replaceAll('/api', '')}/payment.html?checkoutId=$checkoutId';

    // Add order details as query parameters (only if they are not null and not empty)
    if (userId != null && userId.isNotEmpty) url += '&userId=$userId';
    if (packageId != null && packageId.isNotEmpty)
      url += '&packageId=$packageId';
    if (carSize != null && carSize.isNotEmpty) url += '&carSize=$carSize';

    return url;

    // Alternative: Use a hosted version (replace with your actual domain)
    // return 'https://yourdomain.com/payment.html?checkoutId=$checkoutId';
  }

  /// Creates a WebView widget for mobile platforms
  static Widget createHyperPayWebView({
    required String checkoutId,
    required Function(String status) onPaymentResult,
  }) {
    return HyperPayWebViewWidget(
      checkoutId: checkoutId,
      onPaymentResult: onPaymentResult,
    );
  }

  /// Determines if we should use url_launcher (web) or WebView (mobile)
  static bool get shouldUseUrlLauncher => kIsWeb;
}

class HyperPayWebViewWidget extends StatefulWidget {
  final String checkoutId;
  final Function(String status) onPaymentResult;

  const HyperPayWebViewWidget({
    Key? key,
    required this.checkoutId,
    required this.onPaymentResult,
  }) : super(key: key);

  @override
  State<HyperPayWebViewWidget> createState() => _HyperPayWebViewWidgetState();
}

class _HyperPayWebViewWidgetState extends State<HyperPayWebViewWidget> {
  late final WebViewController _controller;
  bool _isLoading = true;
  Timer? _webPollingTimer;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController();

    if (!kIsWeb) {
      _controller.setJavaScriptMode(JavaScriptMode.unrestricted);
      _controller.setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() => _isLoading = true);
          },
          onPageFinished: (url) {
            setState(() => _isLoading = false);
            _checkPaymentResult(url);
          },
        ),
      );
    } else {
      // On web, poll the URL to detect payment result
      _webPollingTimer =
          Timer.periodic(const Duration(seconds: 1), (timer) async {
        final url = await _controller.currentUrl();
        if (url != null && _isPaymentResultUrl(url)) {
          timer.cancel();
          if (mounted) {
            setState(() => _isLoading = false);
            _checkPaymentResult(url);
          }
        }
      });
    }

    _controller.loadRequest(Uri.parse(
      'https://eu-prod.oppwa.com/v1/paymentWidgets.js?checkoutId=${widget.checkoutId}',
    ));
  }

  @override
  void dispose() {
    _webPollingTimer?.cancel();
    super.dispose();
  }

  bool _isPaymentResultUrl(String url) {
    return url.contains('result') ||
        url.contains('success') ||
        url.contains('fail');
  }

  void _checkPaymentResult(String url) {
    if (url.contains('success')) {
      widget.onPaymentResult('success');
    } else if (url.contains('fail') || url.contains('error')) {
      widget.onPaymentResult('fail');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إتمام الدفع'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading) const Center(child: CircularProgressIndicator()),
        ],
      ),
    );
  }
}
