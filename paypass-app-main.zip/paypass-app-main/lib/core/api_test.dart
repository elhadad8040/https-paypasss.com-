import 'api_service.dart';
import 'models.dart';

class ApiTest {
  static Future<void> runTests() async {
    print('=== API Connection Tests ===');
    
    // Test 1: Basic connection
    print('\n1. Testing basic connection...');
    final isConnected = await ApiService.testConnection();
    print('Connection result: $isConnected');
    
    // Test 2: Get packages
    print('\n2. Testing packages endpoint...');
    try {
      final packages = await ApiService.getPackages();
      print('Packages loaded: ${packages.length}');
      if (packages.isNotEmpty) {
        print('First package: ${packages.first.name}');
      }
    } catch (e) {
      print('Error loading packages: $e');
    }
    
    // Test 3: Get washing places
    print('\n3. Testing washing places endpoint...');
    try {
      final stations = await ApiService.getStations();
      print('Stations loaded: ${stations.length}');
      if (stations.isNotEmpty) {
        print('First station: ${stations.first.name}');
      }
    } catch (e) {
      print('Error loading stations: $e');
    }
    
    // Test 4: Get cars (requires auth)
    print('\n4. Testing cars endpoint (requires auth)...');
    try {
      final cars = await ApiService.getCars();
      print('Cars loaded: ${cars.length}');
    } catch (e) {
      print('Error loading cars: $e');
    }
    
    print('\n=== Tests Complete ===');
  }
} 