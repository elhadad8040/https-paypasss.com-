import 'api_service.dart';
import 'models.dart';
import 'constants.dart';
import 'package:url_launcher/url_launcher.dart';
import 'config.dart';

// Package Service
class PackageService {
  static Future<List<Package>> getPackages() async {
    try {
      // Test connection first
      final isConnected = await ApiService.testConnection();
      if (!isConnected) {
        print('API connection failed');
        return [];
      }

      final packages = await ApiService.getPackages();
      print('Successfully loaded ${packages.length} packages from API');
      return packages;
    } catch (e) {
      print('Error getting packages: $e');
      return [];
    }
  }

  static Future<Package?> getPackageById(String id) async {
    try {
      return await ApiService.getPackageById(id);
    } catch (e) {
      print('Error getting package by id: $e');
      return null;
    }
  }

  static Future<void> savePackage(Package package) async {
    try {
      // For now, we'll just use the API to get packages
      // In the future, this could save to local storage or API
      await ApiService.getPackages();
    } catch (e) {
      print('Error saving package: $e');
    }
  }
}

// Car Service
class CarService {
  static Future<List<Car>> getCars() async {
    try {
      final cars = await ApiService.getCars();
      if (cars.isNotEmpty) return cars;
    } catch (e) {
      print('Error getting cars: $e');
    }
    // Demo cars data fallback
    return [
      Car(
        id: '1',
        name: 'تويوتا كورولا',
        type: 'سيدان',
        priceMultiplier: 1.0,
        plateNumber: 'أ ب ج 1234',
        color: 'أبيض',
        make: 'تويوتا',
        model: 'كورولا',
        year: 2020,
        size: 'small',
      ),
      Car(
        id: '2',
        name: 'هيونداي سوناتا',
        type: 'سيدان',
        priceMultiplier: 1.2,
        plateNumber: 'د هـ و 5678',
        color: 'أسود',
        make: 'هيونداي',
        model: 'سوناتا',
        year: 2021,
        size: 'medium',
      ),
      Car(
        id: '3',
        name: 'شيفروليه تاهو',
        type: 'دفع رباعي',
        priceMultiplier: 1.5,
        plateNumber: 'ز ر س 9101',
        color: 'فضي',
        make: 'شيفروليه',
        model: 'تاهو',
        year: 2019,
        size: 'large',
      ),
    ];
  }

  static Future<Car> saveCar(Car car) async {
    try {
      if (car.id.isEmpty) {
        return await ApiService.createCar(car);
      } else {
        return await ApiService.updateCar(car);
      }
    } catch (e) {
      print('Error saving car: $e');
      rethrow;
    }
  }

  static Future<void> deleteCar(String carId) async {
    try {
      await ApiService.deleteCar(carId);
    } catch (e) {
      print('Error deleting car: $e');
      rethrow;
    }
  }
}

// Wash Station Service
class WashStationService {
  static Future<List<WashStation>> getStations() async {
    try {
      // Test connection first
      final isConnected = await ApiService.testConnection();
      if (!isConnected) {
        print('API connection failed');
        return [];
      }

      final stations = await ApiService.getStations();
      print('Successfully loaded ${stations.length} stations from API');
      return stations;
    } catch (e) {
      print('Error getting stations: $e');
      return [];
    }
  }

  static Future<WashStation?> getStationById(String id) async {
    try {
      return await ApiService.getStationById(id);
    } catch (e) {
      print('Error getting station by id: $e');
      return null;
    }
  }
}

// Order Service
class OrderService {
  static Future<List<Order>> getOrders() async {
    try {
      return await ApiService.getOrders();
    } catch (e) {
      print('Error getting orders: $e');
      return [];
    }
  }

  static Future<Order> saveOrder(Order order) async {
    try {
      if (order.id.isEmpty) {
        return await ApiService.createOrder(order);
      } else {
        return await ApiService.updateOrder(order);
      }
    } catch (e) {
      print('Error saving order: $e');
      rethrow;
    }
  }

  static Future<void> deleteOrder(String orderId) async {
    try {
      await ApiService.deleteOrder(orderId);
    } catch (e) {
      print('Error deleting order: $e');
      rethrow;
    }
  }

  static Future<String> generateQRCode(Order order) async {
    // Generate a simple QR code string based on order data
    final qrData = {
      'orderId': order.id,
      'packageId': order.packageId,
      'carSize': order.carSize,
      'totalPrice': order.totalPrice,
      'orderDate': order.orderDate.toIso8601String(),
    };

    // For now, return a simple string representation
    // In a real app, you might want to use a QR code library
    return 'QR_${order.id}_${DateTime.now().millisecondsSinceEpoch}';
  }
}

// Payment Service
class PaymentService {
  static Future<Payment> createPayment(Payment payment) async {
    try {
      return await ApiService.createPayment(payment);
    } catch (e) {
      print('Error creating payment: $e');
      rethrow;
    }
  }

  static Future<List<Payment>> getPayments() async {
    try {
      return await ApiService.getPayments();
    } catch (e) {
      print('Error getting payments: $e');
      return [];
    }
  }
}

// Feedback Service
class FeedbackService {
  static Future<Feedback> createFeedback(Feedback feedback) async {
    try {
      return await ApiService.createFeedback(feedback);
    } catch (e) {
      print('Error creating feedback: $e');
      rethrow;
    }
  }

  static Future<List<Feedback>> getFeedbacksForStation(String stationId) async {
    try {
      return await ApiService.getFeedbacksForStation(stationId);
    } catch (e) {
      print('Error getting feedbacks for station: $e');
      return [];
    }
  }
}

// User Service
class UserService {
  static Future<User?> getCurrentUser() async {
    try {
      // Check authentication first
      final isAuthenticated = await ApiService.isAuthenticated();
      if (!isAuthenticated) {
        print('UserService: User not authenticated');
        return null;
      }

      return await ApiService.getCurrentUser();
    } catch (e) {
      print('Error getting current user: $e');
      return null;
    }
  }

  static Future<User> login(String email, String password) async {
    try {
      return await ApiService.login(email, password);
    } catch (e) {
      print('Error logging in: $e');
      rethrow;
    }
  }

  static Future<User> register(
      String name, String email, String phone, String password,
      {String? referralCode}) async {
    try {
      return await ApiService.register(name, email, phone, password,
          referralCode: referralCode);
    } catch (e) {
      print('Error registering: $e');
      rethrow;
    }
  }

  static Future<void> logout() async {
    try {
      await ApiService.logout();
    } catch (e) {
      print('Error logging out: $e');
    }
  }

  static Future<Map<String, dynamic>> getReferralStatus() async {
    return await ApiService.getReferralStatus();
  }
}

// Maps Service for Google Maps functionality
class MapsService {
  // Open Google Maps with specific location
  static Future<void> openLocationInMaps(String address,
      {String? title}) async {
    try {
      final query =
          Uri.encodeComponent(title != null ? '$title, $address' : address);
      final url = '${MapsConfig.googleMapsSearchUrl}/$query';

      final uri = Uri.parse(url);

      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        throw Exception('Could not launch maps');
      }
    } catch (e) {
      print('Error opening maps: $e');
      rethrow;
    }
  }

  // Open Google Maps with coordinates
  static Future<void> openLocationWithCoordinates(double lat, double lng,
      {String? title}) async {
    try {
      const zoom = MapsConfig.defaultZoomLevel;
      final url = title != null
          ? '${MapsConfig.googleMapsBaseUrl}/search/$title/@$lat,$lng,${zoom}z'
          : '${MapsConfig.googleMapsBaseUrl}/@$lat,$lng,${zoom}z';

      final uri = Uri.parse(url);

      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        throw Exception('Could not launch maps');
      }
    } catch (e) {
      print('Error opening maps with coordinates: $e');
      rethrow;
    }
  }

  // Get coordinates from address (placeholder for future implementation)
  static Future<Map<String, double>?> getCoordinatesFromAddress(
      String address) async {
    // This would typically use Google Geocoding API
    // For now, return null to use address-based navigation
    return null;
  }
}

// Local Data Service for caching and local storage
class LocalDataService {
  static const String _firstTimeKey = 'is_first_time';
  static const String _userDataKey = 'user_data';
  static const String _packagesKey = 'packages';
  static const String _carsKey = 'cars';
  static const String _stationsKey = 'stations';
  static const String _ordersKey = 'orders';

  static Future<bool> isFirstTime() async {
    // Implementation would use SharedPreferences
    return true;
  }

  static Future<void> setNotFirstTime() async {
    // Implementation would use SharedPreferences
  }

  static Future<void> clearAllData() async {
    // Implementation would use SharedPreferences to clear all stored data
  }

  static Future<void> saveData(String key, dynamic data) async {
    // Implementation would use SharedPreferences
  }

  static Future<dynamic> getData(String key) async {
    // Implementation would use SharedPreferences
    return null;
  }
}

// Notification Service
class NotificationService {
  static Future<List<Notification>> getNotifications() async {
    return await ApiService.getNotifications();
  }
}

Future<List<Map<String, dynamic>>> getWashHistory() async {
  return await ApiService.getWashHistory();
}

// UserPackage Service
class UserPackageService {
  static Future<List<UserPackage>> getUserPackages() async {
    try {
      return await ApiService.getUserPackages();
    } catch (e) {
      print('Error getting user packages: $e');
      return [];
    }
  }

  static Future<UserPackage?> getUserPackageById(String id) async {
    try {
      return await ApiService.getUserPackageById(id);
    } catch (e) {
      print('Error getting user package by ID: $e');
      return null;
    }
  }

  static Future<List<UserPackage>> getUserPackagesByUserId(
      String userId) async {
    try {
      return await ApiService.getUserPackagesByUserId(userId);
    } catch (e) {
      print('Error getting user packages by user ID: $e');
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> getRawUserPackagesByUserId(
      String userId) async {
    try {
      return await ApiService.getRawUserPackagesByUserId(userId);
    } catch (e) {
      print('Error getting raw user packages by user ID: $e');
      return [];
    }
  }
}
