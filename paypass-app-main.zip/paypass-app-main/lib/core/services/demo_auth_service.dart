import 'dart:collection';

class DemoUser {
  final String email;
  final String phone;
  final String password;
  final String name;
  DemoUser({required this.email, required this.phone, required this.password, required this.name});
}

class DemoAuthService {
  static final List<DemoUser> _users = [
    DemoUser(email: '', phone: '0500000000', password: '', name: 'Demo User'),
  ];
  static const String demoOtp = '123456';

  static Future<bool> registerWithEmail({required String name, required String email, required String password}) async {
    if (_users.any((u) => u.email == email)) return false;
    _users.add(DemoUser(email: email, phone: '', password: password, name: name));
    return true;
  }

  static Future<bool> registerWithPhone({required String name, required String phone}) async {
    if (_users.any((u) => u.phone == phone)) return false;
    _users.add(DemoUser(email: '', phone: phone, password: '', name: name));
    return true;
  }

  static Future<bool> loginWithEmail({required String email, required String password}) async {
    return _users.any((u) => u.email == email && u.password == password);
  }

  static Future<bool> loginWithPhone({required String phone}) async {
    return _users.any((u) => u.phone == phone);
  }

  static Future<bool> verifyOtp({required String phone, required String otp}) async {
    if (otp != demoOtp) return false;
    return _users.any((u) => u.phone == phone);
  }

  static Future<bool> registerVerifyOtp({required String phone, required String otp}) async {
    if (otp != demoOtp) return false;
    return _users.any((u) => u.phone == phone);
  }

  static void clear() {
    _users.clear();
  }
} 