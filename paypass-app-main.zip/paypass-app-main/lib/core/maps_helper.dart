import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'config.dart';

class MapsHelper {
  static bool _isInitialized = false;
  static String? _lastError;

  /// Test if Google Maps is properly initialized
  static Future<bool> testMapsInitialization() async {
    try {
      // Test basic map creation
      final testMap = GoogleMap(
        onMapCreated: (controller) {},
        initialCameraPosition: const CameraPosition(
          target: LatLng(24.7136, 46.6753),
          zoom: 15,
        ),
      );
      
      _isInitialized = true;
      _lastError = null;
      return true;
    } catch (e) {
      _isInitialized = false;
      _lastError = e.toString();
      print('Google Maps initialization error: $e');
      return false;
    }
  }

  /// Get the last error message
  static String? getLastError() => _lastError;

  /// Check if maps is initialized
  static bool get isInitialized => _isInitialized;

  /// Get API key status
  static String getApiKeyStatus() {
    const apiKey = MapsConfig.googleMapsApiKey;
    if (apiKey.isEmpty || apiKey == 'YOUR_API_KEY_HERE') {
      return 'API key not configured';
    }
    return 'API key configured';
  }

  /// Validate API key format
  static bool isApiKeyValid() {
    const apiKey = MapsConfig.googleMapsApiKey;
    return apiKey.isNotEmpty && 
           apiKey != 'YOUR_API_KEY_HERE' && 
           apiKey.startsWith('AIza');
  }
} 