class ApiException implements Exception {
  final String message;
  final int? statusCode;
  final String? endpoint;

  ApiException(this.message, {this.statusCode, this.endpoint});

  @override
  String toString() {
    return 'ApiException: $message${statusCode != null ? ' (Status: $statusCode)' : ''}${endpoint != null ? ' at $endpoint' : ''}';
  }
}

class NetworkException implements Exception {
  final String message;
  final String? endpoint;

  NetworkException(this.message, {this.endpoint});

  @override
  String toString() {
    return 'NetworkException: $message${endpoint != null ? ' at $endpoint' : ''}';
  }
}

class ErrorHandler {
  static ApiException handleHttpError(int statusCode, String body, String endpoint) {
    String message;
    
    switch (statusCode) {
      case 400:
        message = 'طلب غير صحيح';
        break;
      case 401:
        message = 'غير مصرح لك بالوصول';
        break;
      case 403:
        message = 'ممنوع الوصول';
        break;
      case 404:
        message = 'المورد غير موجود';
        break;
      case 500:
        message = 'خطأ في الخادم';
        break;
      default:
        message = 'حدث خطأ غير متوقع';
    }

    return ApiException(message, statusCode: statusCode, endpoint: endpoint);
  }

  static NetworkException handleNetworkError(String error, String endpoint) {
    String message;
    
    if (error.contains('SocketException') || error.contains('Connection refused')) {
      message = 'لا يمكن الاتصال بالخادم';
    } else if (error.contains('TimeoutException')) {
      message = 'انتهت مهلة الاتصال';
    } else {
      message = 'خطأ في الاتصال بالشبكة';
    }

    return NetworkException(message, endpoint: endpoint);
  }
} 