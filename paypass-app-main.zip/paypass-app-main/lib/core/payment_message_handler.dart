import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:io';
import 'dart:js' as js;
import 'dart:js_interop';

/// Cross-platform payment message handler for Flutter app
/// Handles communication between payment HTML pages and Flutter app
class PaymentMessageHandler {
  static const String _channelName = 'payment_result_channel';
  static const MethodChannel _channel = MethodChannel(_channelName);
  
  static bool _isInitialized = false;
  static bool _isListening = false;
  static Function(Map<String, dynamic>)? _onPaymentResult;
  static StreamSubscription? _webMessageSubscription;
  static Timer? _webPollingTimer;
  
  /// Initialize the payment message handler
  /// Must be called before using any other methods
  static Future<void> initialize() async {
    if (_isInitialized) return;
    
    try {
      if (kIsWeb) {
        _setupWebMessageListener();
      } else {
        _setupMobileMessageListener();
      }
      _isInitialized = true;
    } catch (e) {
      print('PaymentMessageHandler initialization error: $e');
      rethrow;
    }
  }
  
  /// Start listening for payment result messages
  /// [onPaymentResult] callback will be called when payment result is received
  static Future<void> startListening(Function(Map<String, dynamic>) onPaymentResult) async {
    if (!_isInitialized) {
      await initialize();
    }
    
    if (_isListening) {
      await stopListening();
    }
    
    _onPaymentResult = onPaymentResult;
    _isListening = true;
    
    if (kIsWeb) {
      _startWebPolling();
    }
    
    print('PaymentMessageHandler: Started listening for payment results');
  }
  
  /// Stop listening for payment result messages
  static Future<void> stopListening() async {
    if (!_isListening) return;
    
    _isListening = false;
    _onPaymentResult = null;
    
    if (kIsWeb) {
      _stopWebPolling();
    }
    
    print('PaymentMessageHandler: Stopped listening for payment results');
  }
  
  /// Dispose of all resources
  static Future<void> dispose() async {
    await stopListening();
    _isInitialized = false;
    print('PaymentMessageHandler: Disposed');
  }
  
  /// Setup web platform message listener
  static void _setupWebMessageListener() {
    if (!kIsWeb) return;
    
    try {
      // Add message event listener for window
      js.context['window'].callMethod('addEventListener', [
        'message',
        js.allowInterop((event) {
          _handleWebMessage(event);
        })
      ]);
      
      // Add focus event listener to check for payment result
      js.context['window'].callMethod('addEventListener', [
        'focus',
        js.allowInterop((event) {
          _checkForPaymentResult();
        })
      ]);
      
      print('PaymentMessageHandler: Web message listener setup complete');
    } catch (e) {
      print('PaymentMessageHandler: Web setup error: $e');
    }
  }
  
  /// Setup mobile platform message listener
  static void _setupMobileMessageListener() {
    if (kIsWeb) return;
    
    try {
      _channel.setMethodCallHandler((call) async {
        switch (call.method) {
          case 'payment_result':
            final result = call.arguments as Map<String, dynamic>;
            _handlePaymentResult(result);
            break;
          default:
            print('PaymentMessageHandler: Unknown method call: ${call.method}');
        }
      });
      
      print('PaymentMessageHandler: Mobile message listener setup complete');
    } catch (e) {
      print('PaymentMessageHandler: Mobile setup error: $e');
    }
  }
  
  /// Handle web platform messages
  static void _handleWebMessage(js.JsObject event) {
    try {
      if (!_isListening) return;
      
      final origin = event['origin']?.toString() ?? '';
      final data = event['data'];
      
      // Validate origin for security (only accept messages from our domain)
      if (!_isValidOrigin(origin)) {
        print('PaymentMessageHandler: Invalid origin: $origin');
        return;
      }
      
      // Parse payment result data
      if (data != null && data is js.JsObject) {
        final messageType = data['type']?.toString();
        final transactionId = data['transactionId']?.toString();
        final paymentData = data['data'];
        
        if (messageType == 'payment_success' || messageType == 'payment_failed') {
          final result = <String, dynamic>{
            'success': messageType == 'payment_success',
            'transactionId': transactionId ?? '',
            'message': _getPaymentMessage(messageType),
          };
          
          // Add additional data if available
          if (paymentData != null && paymentData is js.JsObject) {
            try {
              final additionalData = js.JsObject.fromBrowserObject(paymentData);
              if (additionalData.hasProperty('message')) {
                result['message'] = additionalData['message']?.toString() ?? result['message'];
              }
              if (additionalData.hasProperty('details')) {
                result['details'] = additionalData['details']?.toString();
              }
            } catch (e) {
              print('PaymentMessageHandler: Error parsing additional data: $e');
            }
          }
          
          _handlePaymentResult(result);
        }
      }
    } catch (e) {
      print('PaymentMessageHandler: Error handling web message: $e');
    }
  }
  
  /// Handle payment result from any platform
  static void _handlePaymentResult(Map<String, dynamic> result) {
    if (!_isListening || _onPaymentResult == null) return;
    
    try {
      _onPaymentResult!(result);
      print('PaymentMessageHandler: Payment result handled: $result');
    } catch (e) {
      print('PaymentMessageHandler: Error in payment result callback: $e');
    }
  }
  
  /// Start web polling for payment results
  static void _startWebPolling() {
    if (!kIsWeb) return;
    
    _stopWebPolling(); // Stop any existing polling
    
    _webPollingTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _checkForPaymentResult();
    });
    
    print('PaymentMessageHandler: Started web polling');
  }
  
  /// Stop web polling
  static void _stopWebPolling() {
    _webPollingTimer?.cancel();
    _webPollingTimer = null;
  }
  
  /// Check for payment result in web platform
  static void _checkForPaymentResult() {
    if (!kIsWeb || !_isListening) return;
    
    try {
      // Check if we have a payment result in localStorage
      final paymentResult = js.context['localStorage'].callMethod('getItem', ['payment_result']);
      if (paymentResult != null) {
        // Clear the stored result
        js.context['localStorage'].callMethod('removeItem', ['payment_result']);
        
        // Parse and handle the result
        try {
          final parsedObject = js.context['JSON'].callMethod('parse', [paymentResult]);
          final result = <String, dynamic>{};
          
          // Convert JsObject to Map<String, dynamic>
          if (parsedObject != null) {
            final jsObject = js.JsObject.fromBrowserObject(parsedObject);
            // Use Object.keys to get the keys of the JavaScript object
            final keys = js.context['Object'].callMethod('keys', [jsObject]);
            for (int i = 0; i < keys.length; i++) {
              final key = keys[i];
              result[key.toString()] = jsObject[key];
            }
          }
          
          _handlePaymentResult(result);
        } catch (e) {
          print('PaymentMessageHandler: Error parsing stored payment result: $e');
        }
      }
    } catch (e) {
      print('PaymentMessageHandler: Error checking for payment result: $e');
    }
  }
  
  /// Validate message origin for security
  static bool _isValidOrigin(String origin) {
    if (origin.isEmpty) return false;
    
    // Allow localhost for development
    if (origin.contains('localhost') || origin.contains('127.0.0.1')) {
      return true;
    }
    
    // Allow your production domain
    if (origin.contains('yourdomain.com')) {
      return true;
    }
    
    // Add more allowed origins as needed
    return false;
  }
  
  /// Get payment message based on message type
  static String _getPaymentMessage(String? messageType) {
    switch (messageType) {
      case 'payment_success':
        return 'تم الدفع بنجاح';
      case 'payment_failed':
        return 'فشل في الدفع';
      default:
        return 'تم استلام نتيجة الدفع';
    }
  }
  
  /// Send payment result to mobile platform (for testing)
  static Future<void> sendTestPaymentResult(Map<String, dynamic> result) async {
    if (kIsWeb) return;
    
    try {
      await _channel.invokeMethod('payment_result', result);
      print('PaymentMessageHandler: Test payment result sent to mobile');
    } catch (e) {
      print('PaymentMessageHandler: Error sending test payment result: $e');
    }
  }
  
  /// Store payment result in web localStorage (for web platform)
  static void storePaymentResult(Map<String, dynamic> result) {
    if (!kIsWeb) return;
    
    try {
      final jsonString = js.context['JSON'].callMethod('stringify', [result]);
      js.context['localStorage'].callMethod('setItem', ['payment_result', jsonString]);
      print('PaymentMessageHandler: Payment result stored in localStorage');
    } catch (e) {
      print('PaymentMessageHandler: Error storing payment result: $e');
    }
  }
} 