import 'package:flutter/material.dart';
import 'payment_message_handler.dart';
import 'payment_test_utils.dart';

/// Example implementation of payment messaging system
/// This demonstrates how to integrate the payment messaging system into your app
class PaymentExample extends StatefulWidget {
  const PaymentExample({Key? key}) : super(key: key);

  @override
  State<PaymentExample> createState() => _PaymentExampleState();
}

class _PaymentExampleState extends State<PaymentExample> {
  bool _isListening = false;
  String _lastPaymentResult = '';

  @override
  void initState() {
    super.initState();
    _initializePaymentHandler();
  }

  Future<void> _initializePaymentHandler() async {
    try {
      await PaymentMessageHandler.initialize();
      await PaymentMessageHandler.startListening(_handlePaymentResult);
      setState(() {
        _isListening = true;
      });
    } catch (e) {
      print('Failed to initialize payment handler: $e');
    }
  }

  void _handlePaymentResult(Map<String, dynamic> result) {
    final bool isSuccess = result['success'] ?? false;
    final String message = result['message'] ?? '';
    final String transactionId = result['transactionId'] ?? '';

    setState(() {
      _lastPaymentResult = '${isSuccess ? "✅" : "❌"} $message (ID: $transactionId)';
    });

    // Show result dialog
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(isSuccess ? 'تم الدفع بنجاح' : 'فشل في الدفع'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message),
            if (transactionId.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'معرف المعاملة: $transactionId',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    PaymentMessageHandler.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مثال نظام الدفع'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Status Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'حالة النظام',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(
                          _isListening ? Icons.check_circle : Icons.error,
                          color: _isListening ? Colors.green : Colors.red,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          _isListening ? 'يعمل بشكل طبيعي' : 'غير متصل',
                          style: TextStyle(
                            color: _isListening ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Last Result Card
            if (_lastPaymentResult.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'آخر نتيجة دفع',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      const SizedBox(height: 8),
                      Text(_lastPaymentResult),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 16),

            // Test Buttons
            ElevatedButton.icon(
              onPressed: () => PaymentTestUtils.showTestDialog(context),
              icon: const Icon(Icons.bug_report),
              label: const Text('اختبار النظام'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
            const SizedBox(height: 8),

            ElevatedButton.icon(
              onPressed: () async {
                await PaymentTestUtils.testPaymentSuccess(context);
              },
              icon: const Icon(Icons.check_circle),
              label: const Text('اختبار الدفع الناجح'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
            const SizedBox(height: 8),

            ElevatedButton.icon(
              onPressed: () async {
                await PaymentTestUtils.testPaymentFailure(context);
              },
              icon: const Icon(Icons.error),
              label: const Text('اختبار الدفع الفاشل'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
            const SizedBox(height: 16),

            // Platform Info
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'معلومات النظام',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text('المنصة: ${PaymentTestUtils.getPlatformInfo()}'),
                    const SizedBox(height: 4),
                    Text('الحالة: ${_isListening ? "متصل" : "غير متصل"}'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Example of how to integrate payment messaging in a real payment screen
class RealPaymentScreen extends StatefulWidget {
  const RealPaymentScreen({Key? key}) : super(key: key);

  @override
  State<RealPaymentScreen> createState() => _RealPaymentScreenState();
}

class _RealPaymentScreenState extends State<RealPaymentScreen> {
  @override
  void initState() {
    super.initState();
    _setupPaymentHandler();
  }

  Future<void> _setupPaymentHandler() async {
    try {
      await PaymentMessageHandler.initialize();
      await PaymentMessageHandler.startListening(_handlePaymentResult);
    } catch (e) {
      print('Error setting up payment handler: $e');
    }
  }

  void _handlePaymentResult(Map<String, dynamic> result) {
    final bool isSuccess = result['success'] ?? false;
    final String message = result['message'] ?? '';
    final String transactionId = result['transactionId'] ?? '';

    // Handle the payment result
    if (isSuccess) {
      // Navigate to success page or show success dialog
      _showSuccessDialog(message, transactionId);
    } else {
      // Show error dialog
      _showErrorDialog(message, transactionId);
    }
  }

  void _showSuccessDialog(String message, String transactionId) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 8),
            Text('تم الدفع بنجاح'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message),
            if (transactionId.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'معرف المعاملة: $transactionId',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Navigate to profile or home page
              Navigator.of(context).pushReplacementNamed('/profile');
            },
            child: const Text('عرض الملف الشخصي'),
          ),
        ],
      ),
    );
  }

  void _showErrorDialog(String message, String transactionId) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.error, color: Colors.red),
            SizedBox(width: 8),
            Text('فشل في الدفع'),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(message),
            if (transactionId.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'معرف المعاملة: $transactionId',
                style: const TextStyle(
                  fontSize: 12,
                  color: Colors.grey,
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('حسناً'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    PaymentMessageHandler.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الدفع'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: const Center(
        child: Text('هذا مثال على شاشة الدفع الحقيقية'),
      ),
    );
  }
} 