import 'package:flutter/material.dart';

// ألوان التطبيق - النسخة الجديدة
const Color kPrimaryColor = Color(0xFF22c55e); // الأخضر الأساسي
const Color kSecondaryColor = Color(0xFF16a34a); // الأخضر الداكن
const Color kAccentColor = Color(0xFF22c55e); // الأخضر الأساسي
const Color kBackgroundColor = Color(0xFFF5F5F5); // الرمادي الفاتح
const Color kSurfaceColor = Color(0xFFFFFFFF); // الأبيض
const Color kTextPrimary = Color(0xFF333333); // الرمادي الداكن
const Color kTextSecondary = Color(0xFF6B7280); // الرمادي المتوسط
const Color kErrorColor = Color(0xFFEF4444); // الأحمر
const Color kSuccessColor = Color(0xFF22c55e); // الأخضر الأساسي
const Color kWarningColor = Color(0xFFFBBF24); // الأصفر
const Color kInfoColor = Color(0xFF3B82F6); // الأزرق

// أحجام التطبيق
const double kDefaultPadding = 16.0;
const double kDefaultMargin = 16.0;
const double kBorderRadius = 12.0;
const double kButtonHeight = 48.0;
const double kIconSize = 24.0;
const double kLargeIconSize = 48.0;

// نصوص التطبيق
const String kAppName = 'PayPass';
const String kAppSlogan = 'كل شيء أصبح أسهل وأنظف!';
const String kLogin = 'تسجيل الدخول';
const String kRegister = 'إنشاء حساب';
const String kContinue = 'استمر';
const String kCancel = 'إلغاء';
const String kConfirm = 'تأكيد';
const String kSave = 'حفظ';
const String kDelete = 'حذف';
const String kEdit = 'تعديل';
const String kAdd = 'إضافة';
const String kSearch = 'بحث';
const String kFilter = 'تصفية';
const String kSort = 'ترتيب';
const String kRefresh = 'تحديث';
const String kLoading = 'جاري التحميل...';
const String kNoData = 'لا توجد بيانات';
const String kError = 'حدث خطأ';
const String kSuccess = 'تم بنجاح';
const String kWarning = 'تحذير';
const String kInfo = 'معلومات';

// مدة الانتقالات
const Duration kAnimationDuration = Duration(milliseconds: 300);
const Duration kSplashDuration = Duration(seconds: 3);

// أنواع السيارات مع معامل السعر (مطابقة مع userPackage.model.js)
final List<Map<String, dynamic>> kCarSizes = [
  {
    'key': 'sedan',
    'name': 'صغيرة',
    'priceFactor': 1.0,
    'icon': Icons.directions_car,
    'color': Color(0xFF22c55e), // Green
  },
  {
    'key': 'suv',
    'name': 'متوسطة',
    'priceFactor': 1.2,
    'icon': Icons.sports_motorsports, // Different icon for SUV
    'color': Color(0xFF3B82F6), // Blue
  },
  {
    'key': 'truck',
    'name': 'كبيرة',
    'priceFactor': 1.5,
    'icon': Icons.local_shipping,
    'color': Color(0xFFF59E42), // Orange
  },
 
];

// حالة الباقة (مطابقة مع userPackage.model.js)
const String kPackageStatusActive = 'active';
const String kPackageStatusExpired = 'expired';
const String kPackageStatusUsed = 'used';

// نصوص الباقات
const String kBasicPackage = 'الباقة الأساسية';
const String kAdvancedPackage = 'الباقة المتقدمة';
const String kComprehensivePackage = 'الباقة الشاملة';

// نصوص الأزرار
const String kWashStationsText = 'محطات الغسيل';
const String kCurrentPackages = 'الباقات الحالية';
const String kSelectCar = 'اختيار السيارة';
const String kSelectPackage = 'اختيار الباقة';
const String kPayment = 'الدفع';

// نصوص الرسائل
const String kPaymentSuccess = 'تم الدفع بنجاح';
const String kPaymentSuccessMessage =
    'الآن لديك رمز QR للباقة الخاصة بك ويمكنك استخدامه في أي من محطات الغسيل المعتمدة';

// روابط ثابتة أو نصوص ثابتة أخرى يمكن إضافتها هنا
