import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';
import 'models.dart';
import 'config.dart';
import 'error_handler.dart';

class ApiService {
  static const String baseUrl = AppConfig.apiBaseUrl;
  static const String tokenKey = 'auth_token';
  static const String userDataKey = 'user_data';

  // Get stored token
  static Future<String?> _getToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(tokenKey);
    } catch (e) {
      print('Error getting token: $e');
      return null;
    }
  }

  // Store token
  static Future<void> _storeToken(String token) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(tokenKey, token);
    } catch (e) {
      print('Error storing token: $e');
    }
  }

  // Clear token
  static Future<void> _clearToken() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(tokenKey);
      await prefs.remove(userDataKey);
    } catch (e) {
      print('Error clearing token: $e');
    }
  }

  // Store user data locally for offline access
  static Future<void> _storeUserData(User user) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(userDataKey, jsonEncode(user.toMap()));
    } catch (e) {
      print('Error storing user data: $e');
    }
  }

  // Get stored user data
  static Future<User?> _getStoredUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userData = prefs.getString(userDataKey);
      if (userData != null) {
        return User.fromMap(jsonDecode(userData));
      }
      return null;
    } catch (e) {
      print('Error getting stored user data: $e');
      return null;
    }
  }

  // Check if user is authenticated (works for both web and mobile)
  static Future<bool> isAuthenticated() async {
    try {
      final token = await _getToken();
      if (token == null) {
        print('No token found');
        return false;
      }

      // For web, we might want to validate the token with the server
      if (kIsWeb) {
        try {
          final response = await http.get(
            Uri.parse('$baseUrl/users/profile'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
          ).timeout(const Duration(seconds: 5));

          return response.statusCode == 200;
        } catch (e) {
          print('Web token validation failed: $e');
          return false;
        }
      } else {
        // For mobile, we can rely on stored token
        return token.isNotEmpty;
      }
    } catch (e) {
      print('Error checking authentication: $e');
      return false;
    }
  }

  // Generic HTTP request helper
  static Future<http.Response> _makeRequest(
    String method,
    String endpoint, {
    Map<String, dynamic>? body,
    Map<String, String>? headers,
    bool sendToken = true,
  }) async {
    final token = sendToken ? await _getToken() : null;
    final defaultHeaders = {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };

    if (headers != null) {
      defaultHeaders.addAll(headers);
    }

    final uri = Uri.parse('$baseUrl$endpoint');

    switch (method.toUpperCase()) {
      case 'GET':
        return await http.get(uri, headers: defaultHeaders).timeout(
              const Duration(milliseconds: AppConfig.connectionTimeout),
            );
      case 'POST':
        return await http
            .post(
              uri,
              headers: defaultHeaders,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(
              const Duration(milliseconds: AppConfig.connectionTimeout),
            );
      case 'PUT':
        return await http
            .put(
              uri,
              headers: defaultHeaders,
              body: body != null ? jsonEncode(body) : null,
            )
            .timeout(
              const Duration(milliseconds: AppConfig.connectionTimeout),
            );
      case 'DELETE':
        return await http.delete(uri, headers: defaultHeaders).timeout(
              const Duration(milliseconds: AppConfig.connectionTimeout),
            );
      default:
        throw Exception('Unsupported HTTP method: $method');
    }
  }

  // Handle response
  static dynamic _handleResponse(http.Response response) {
    print('API Response Status: ${response.statusCode}');
    print('API Response URL: ${response.request?.url}');
    print('API Response Headers: ${response.headers}');
    print('API Response Body: ${response.body}');

    if (response.statusCode >= 200 && response.statusCode < 300) {
      if (response.body.isEmpty) return null;
      try {
        return jsonDecode(response.body);
      } catch (e) {
        print('Error parsing JSON response: $e');
        print('Response body: ${response.body}');
        throw Exception('Invalid JSON response from server');
      }
    } else {
      print('HTTP Error: ${response.statusCode} - ${response.body}');
      throw ErrorHandler.handleHttpError(
        response.statusCode,
        response.body,
        response.request?.url.toString() ?? '',
      );
    }
  }

  // Test API connection
  static Future<bool> testConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/packages'),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      print('Connection test status: ${response.statusCode}');
      print('Connection test body: ${response.body}');

      return response.statusCode >= 200 && response.statusCode < 300;
    } catch (e) {
      print('Connection test failed: $e');
      return false;
    }
  }

  // Auth Services
  static Future<User> login(String email, String password) async {
    try {
      final response = await _makeRequest('POST', '/users/login',
          body: {
            'email': email,
            'password': password,
          },
          sendToken: false);

      final data = _handleResponse(response);
      await _storeToken(data['token']);
      final user = User.fromMap(data['user']);
      await _storeUserData(user);
      return user;
    } catch (e) {
      if (e is ApiException) {
        rethrow;
      }
      throw ErrorHandler.handleNetworkError(e.toString(), '/users/login');
    }
  }

  static Future<User> register(
      String name, String email, String phone, String password,
      {String? referralCode}) async {
    try {
      final body = {
        'name': name,
        'email': email,
        'phone': phone,
        'password': password,
      };
      if (referralCode != null && referralCode.isNotEmpty) {
        body['referralCode'] = referralCode;
      }

      final response = await _makeRequest('POST', '/users/register',
          body: body, sendToken: false);
      final data = _handleResponse(response);

      if (data['token'] == null) {
        throw Exception('Registration successful but no token received');
      }

      await _storeToken(data['token']);
      final user = User.fromMap(data['user']);
      await _storeUserData(user);
      return user;
    } catch (e) {
      print('Registration error: $e');
      rethrow;
    }
  }

  static Future<void> logout() async {
    await _clearToken();
  }

  static Future<User?> getCurrentUser() async {
    try {
      // First try to get user from server
      final response = await _makeRequest('GET', '/users/profile');
      final data = _handleResponse(response);
      final user = User.fromMap(data);
      await _storeUserData(user);
      return user;
    } catch (e) {
      print('Failed to get user from server: $e');

      // Fallback to stored user data
      final storedUser = await _getStoredUserData();
      if (storedUser != null) {
        print('Using stored user data');
        return storedUser;
      }

      return null;
    }
  }

  static Future<User> updateProfile(String name, String email) async {
    final response = await _makeRequest('PUT', '/users/profile', body: {
      'name': name,
      'email': email,
    });
    final data = _handleResponse(response);
    return User.fromMap(data);
  }

  static Future<Map<String, dynamic>> getReferralStatus() async {
    final response = await _makeRequest('GET', '/users/referral-status');
    final data = _handleResponse(response);
    return data;
  }

  // Car Services
  static Future<List<Car>> getCars() async {
    try {
      final response = await _makeRequest('GET', '/cars');
      final data = _handleResponse(response);
      return (data as List).map((item) => Car.fromMap(item)).toList();
    } catch (e) {
      if (e is ApiException) {
        rethrow;
      }
      throw ErrorHandler.handleNetworkError(e.toString(), '/cars');
    }
  }

  static Future<Car> createCar(Car car) async {
    final response = await _makeRequest('POST', '/cars', body: car.toMap());
    final data = _handleResponse(response);
    return Car.fromMap(data);
  }

  static Future<Car> updateCar(Car car) async {
    final response =
        await _makeRequest('PUT', '/cars/${car.id}', body: car.toMap());
    final data = _handleResponse(response);
    return Car.fromMap(data);
  }

  static Future<void> deleteCar(String carId) async {
    await _makeRequest('DELETE', '/cars/$carId');
  }

  // Package Services
  static Future<List<Package>> getPackages() async {
    try {
      final response = await _makeRequest('GET', '/packages', sendToken: false);
      final data = _handleResponse(response);
      return (data as List).map((item) => Package.fromMap(item)).toList();
    } catch (e) {
      if (e is ApiException) {
        rethrow;
      }
      throw ErrorHandler.handleNetworkError(e.toString(), '/packages');
    }
  }

  static Future<Package?> getPackageById(String id) async {
    try {
      final response =
          await _makeRequest('GET', '/packages/$id', sendToken: false);
      final data = _handleResponse(response);
      return Package.fromMap(data);
    } catch (e) {
      return null;
    }
  }

  static Future<Map<String, dynamic>> scanOwnerQR(String barcode) async {
    final response = await _makeRequest('POST', '/packages/scan-qr', body: {
      'barcode': barcode,
      // Optionally, add washingPlaceId if needed
    });
    final data = _handleResponse(response);
    return data;
  }

  // Washing Place Services
  static Future<List<WashStation>> getStations() async {
    try {
      final response =
          await _makeRequest('GET', '/washing-places', sendToken: false);
      final data = _handleResponse(response);
      return (data as List).map((item) => WashStation.fromMap(item)).toList();
    } catch (e) {
      if (e is ApiException) {
        rethrow;
      }
      throw ErrorHandler.handleNetworkError(e.toString(), '/washing-places');
    }
  }

  static Future<WashStation?> getStationById(String id) async {
    try {
      final response =
          await _makeRequest('GET', '/washing-places/$id', sendToken: false);
      final data = _handleResponse(response);
      return WashStation.fromMap(data);
    } catch (e) {
      return null;
    }
  }

  // Order/Wash Services
  static Future<List<Order>> getOrders() async {
    final response = await _makeRequest('GET', '/washes');
    final data = _handleResponse(response);
    return (data as List).map((item) => Order.fromMap(item)).toList();
  }

  static Future<Order> createOrder(Order order) async {
    final response = await _makeRequest('POST', '/washes', body: order.toMap());
    final data = _handleResponse(response);
    return Order.fromMap(data);
  }

  static Future<Order> updateOrder(Order order) async {
    final response =
        await _makeRequest('PUT', '/washes/${order.id}', body: order.toMap());
    final data = _handleResponse(response);
    return Order.fromMap(data);
  }

  static Future<void> deleteOrder(String orderId) async {
    await _makeRequest('DELETE', '/washes/$orderId');
  }

  static Future<List<Map<String, dynamic>>> getWashHistory() async {
    final response = await _makeRequest('GET', '/washes');
    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data);
  }

  static Future<List<Map<String, dynamic>>> getOwnerScans() async {
    final response = await _makeRequest('GET', '/washes/by-owner');
    final data = _handleResponse(response);
    return List<Map<String, dynamic>>.from(data);
  }

  // Payment Services
  static Future<Payment> createPayment(Payment payment) async {
    final response =
        await _makeRequest('POST', '/payments', body: payment.toMap());
    final data = _handleResponse(response);
    return Payment.fromMap(data);
  }

  static Future<List<Payment>> getPayments() async {
    final response = await _makeRequest('GET', '/payments');
    final data = _handleResponse(response);
    return (data as List).map((item) => Payment.fromMap(item)).toList();
  }

  // Feedback Services
  static Future<Feedback> createFeedback(Feedback feedback) async {
    final response =
        await _makeRequest('POST', '/feedbacks', body: feedback.toMap());
    final data = _handleResponse(response);
    return Feedback.fromMap(data);
  }

  static Future<List<Feedback>> getFeedbacksForStation(String stationId) async {
    final response = await _makeRequest(
        'GET', '/washing-places/$stationId/feedbacks',
        sendToken: false);
    final data = _handleResponse(response);
    return (data as List).map((item) => Feedback.fromMap(item)).toList();
  }

  static Future<List<Notification>> getNotifications() async {
    final response = await _makeRequest('GET', '/notifications');
    final data = _handleResponse(response);
    return (data as List).map((item) => Notification.fromMap(item)).toList();
  }

  static Future<void> createFeedbackRaw(Map<String, dynamic> data) async {
    await _makeRequest('POST', '/feedbacks', body: data);
  }

  static Future<List<UserPackage>> getUserPackages() async {
    final response = await _makeRequest('GET', '/user-packages');
    final data = _handleResponse(response);
    return (data as List).map((item) => UserPackage.fromMap(item)).toList();
  }

  static Future<UserPackage?> getUserPackageById(String id) async {
    try {
      final response = await _makeRequest('GET', '/user-packages/$id');
      final data = _handleResponse(response);
      return UserPackage.fromMap(data);
    } catch (e) {
      return null;
    }
  }

  static Future<List<UserPackage>> getUserPackagesByUserId(
      String userId) async {
    try {
      print('API: Calling getUserPackagesByUserId with userId: $userId');
      final response = await _makeRequest(
          'GET', '/user-packages/by-user/$userId',
          sendToken: false);
      print('API: Response received');
      final data = _handleResponse(response);
      print('API: Data parsed, length: ${data.length}');
      final packages =
          (data as List).map((item) => UserPackage.fromMap(item)).toList();
      print('API: Packages created, count: ${packages.length}');
      return packages;
    } catch (e) {
      print('Error getting user packages by user ID: $e');
      return [];
    }
  }

  static Future<List<Map<String, dynamic>>> getRawUserPackagesByUserId(
      String userId) async {
    try {
      print('API: Calling getRawUserPackagesByUserId with userId: $userId');
      final response = await _makeRequest(
          'GET', '/user-packages/by-user/$userId',
          sendToken: false);
      print('API: Raw response received');
      final data = _handleResponse(response);
      print('API: Raw data parsed, length: ${data.length}');
      return List<Map<String, dynamic>>.from(data);
    } catch (e) {
      print('Error getting raw user packages by user ID: $e');
      return [];
    }
  }

  // Fetch user/package info by barcode (no wash started)
  static Future<Map<String, dynamic>> scanOwnerInfo(String barcode) async {
    final response = await _makeRequest('POST', '/packages/scan-info', body: {
      'barcode': barcode,
    });
    final data = _handleResponse(response);
    return data;
  }

  // Start a wash (after confirmation)
  static Future<Map<String, dynamic>> startOwnerWash(
      String barcode, String washingPlaceId) async {
    final response = await _makeRequest('POST', '/packages/start-wash', body: {
      'barcode': barcode,
      'washingPlaceId': washingPlaceId,
    });
    final data = _handleResponse(response);
    return data;
  }

  // HyperPay: Create checkout session
  static Future<Map<String, dynamic>> createHyperpayCheckout({
    required double amount,
    required String currency,
    required String merchantTransactionId,
    required String customerEmail,
    required String billingStreet1,
    required String billingCity,
    required String billingState,
    required String billingCountry,
    required String billingPostcode,
    required String customerGivenName,
    required String customerSurname,
  }) async {
    final response = await _makeRequest(
      'POST',
      '/payments/hyperpay-checkout',
      body: {
        'amount': amount.toStringAsFixed(2),
        'currency': currency,
        'merchantTransactionId': merchantTransactionId,
        'customerEmail': customerEmail,
        'billingStreet1': billingStreet1,
        'billingCity': billingCity,
        'billingState': billingState,
        'billingCountry': billingCountry,
        'billingPostcode': billingPostcode,
        'customerGivenName': customerGivenName,
        'customerSurname': customerSurname,
      },
    );
    return _handleResponse(response);
  }

  // Handle HyperPay payment result
  static Future<Map<String, dynamic>> handlePaymentResult(
      String transactionId, String resourcePath) async {
    try {
      final response = await _makeRequest(
        'GET',
        '/payments/result?id=$transactionId&resourcePath=$resourcePath',
        sendToken: false, // No auth required for HyperPay callback
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error handling payment result: $e');
    }
  }

  // Create payment from HyperPay result
  static Future<Map<String, dynamic>> createPaymentFromHyperPay({
    required String transactionId,
    required String packageId,
    required String carSize,
    required double amount,
    String method = 'hyperpay',
  }) async {
    try {
      print('Sending carSize to backend: $carSize'); // Debug print
      final response = await _makeRequest(
        'POST',
        '/payments/create-from-hyperpay',
        body: {
          'transactionId': transactionId,
          'package': packageId,
          'carSize': carSize, // Must be key: sedan, suv, truck, van, luxury
          'amount': amount,
          'method': method,
        },
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error creating payment: $e');
    }
  }

  // Create tip payment from HyperPay result
  static Future<Map<String, dynamic>> createTipPaymentFromHyperPay({
    required String transactionId,
    required String stationId,
    required double amount,
    String method = 'hyperpay',
  }) async {
    try {
      final response = await _makeRequest(
        'POST',
        '/payments/create-tip-from-hyperpay',
        body: {
          'transactionId': transactionId,
          'station': stationId,
          'amount': amount,
          'method': method,
        },
      );
      return _handleResponse(response);
    } catch (e) {
      throw Exception('Error creating tip payment: $e');
    }
  }

  static Future<bool> phoneLoginInitiate(String phone) async {
    final response = await _makeRequest('POST', '/users/phone-login-initiate', body: {'phone': phone}, sendToken: false);
    final data = _handleResponse(response);
    return data['exists'] == true;
  }

  static Future<Map<String, dynamic>> phoneLoginVerify(String phone, String firebaseIdToken) async {
    final response = await _makeRequest('POST', '/users/phone-login-verify', body: {'phone': phone, 'firebaseIdToken': firebaseIdToken}, sendToken: false);
    return _handleResponse(response);
  }

  static Future<bool> phoneSignupInitiate(String phone) async {
    final response = await _makeRequest('POST', '/users/phone-signup-initiate', body: {'phone': phone}, sendToken: false);
    final data = _handleResponse(response);
    return data['canRegister'] == true;
  }

  static Future<Map<String, dynamic>> phoneSignupVerify(Map<String, dynamic> userData, String firebaseIdToken) async {
    final body = {...userData, 'firebaseIdToken': firebaseIdToken};
    final response = await _makeRequest('POST', '/users/phone-signup-verify', body: body, sendToken: false);
    return _handleResponse(response);
  }
}
