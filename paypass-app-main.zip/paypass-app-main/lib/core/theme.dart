import 'package:flutter/material.dart';
import 'constants.dart';

// ثيم التطبيق المخصص - النسخة الجديدة
final ThemeData appTheme = ThemeData(
  // الألوان الأساسية
  primarySwatch: Colors.green,
  primaryColor: kPrimaryColor,
  scaffoldBackgroundColor: kBackgroundColor,
  
  // الخطوط
  fontFamily: 'Cairo',
  textTheme: const TextTheme(
    displayLarge: TextStyle(
      fontSize: 32,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    displayMedium: TextStyle(
      fontSize: 28,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    displaySmall: TextStyle(
      fontSize: 24,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    headlineLarge: TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    headlineMedium: TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.w600,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    headlineSmall: TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.w600,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    titleLarge: TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.w600,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    titleMedium: TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w500,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    titleSmall: TextStyle(
      fontSize: 12,
      fontWeight: FontWeight.w500,
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
    bodyLarge: TextStyle(
      fontSize: 16, 
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    bodyMedium: TextStyle(
      fontSize: 14, 
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    bodySmall: TextStyle(
      fontSize: 12, 
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
    labelLarge: TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.w500,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    labelMedium: TextStyle(
      fontSize: 12,
      fontWeight: FontWeight.w500,
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
    labelSmall: TextStyle(
      fontSize: 10,
      fontWeight: FontWeight.w500,
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
  ),

  // ثيم AppBar
  appBarTheme: const AppBarTheme(
    backgroundColor: kPrimaryColor,
    foregroundColor: Colors.white,
    elevation: 0,
    centerTitle: true,
    titleTextStyle: TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: Colors.white,
      fontFamily: 'Cairo',
    ),
  ),

  // ثيم الأزرار
  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: kPrimaryColor,
      foregroundColor: Colors.white,
      minimumSize: const Size(double.infinity, kButtonHeight),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kBorderRadius),
      ),
      textStyle: const TextStyle(
        fontSize: 16, 
        fontWeight: FontWeight.w600,
        fontFamily: 'Cairo',
      ),
    ),
  ),

  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: kPrimaryColor,
      side: const BorderSide(color: kPrimaryColor),
      minimumSize: const Size(double.infinity, kButtonHeight),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(kBorderRadius),
      ),
      textStyle: const TextStyle(
        fontSize: 16, 
        fontWeight: FontWeight.w600,
        fontFamily: 'Cairo',
      ),
    ),
  ),

  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: kPrimaryColor,
      textStyle: const TextStyle(
        fontSize: 14, 
        fontWeight: FontWeight.w500,
        fontFamily: 'Cairo',
      ),
    ),
  ),

  // ثيم حقول النص
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: kSurfaceColor,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
      borderSide: const BorderSide(color: kTextSecondary),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
      borderSide: BorderSide(color: kTextSecondary.withOpacity(0.3)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
      borderSide: const BorderSide(color: kPrimaryColor, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
      borderSide: const BorderSide(color: kErrorColor),
    ),
    contentPadding: const EdgeInsets.symmetric(
      horizontal: kDefaultPadding,
      vertical: kDefaultPadding,
    ),
    labelStyle: const TextStyle(
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
    hintStyle: TextStyle(
      color: kTextSecondary.withOpacity(0.7),
      fontFamily: 'Cairo',
    ),
  ),

  // ثيم البطاقات
  cardTheme: CardThemeData(
    color: kSurfaceColor,
    elevation: 2,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
    ),
    margin: const EdgeInsets.symmetric(
      horizontal: kDefaultMargin,
      vertical: kDefaultMargin / 2,
    ),
  ),

  // ثيم BottomNavigationBar
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: kSurfaceColor,
    selectedItemColor: kPrimaryColor,
    unselectedItemColor: kTextSecondary,
    type: BottomNavigationBarType.fixed,
    elevation: 8,
    selectedLabelStyle: TextStyle(
      fontFamily: 'Cairo',
      fontWeight: FontWeight.w600,
    ),
    unselectedLabelStyle: TextStyle(
      fontFamily: 'Cairo',
    ),
  ),

  // ثيم FloatingActionButton
  floatingActionButtonTheme: const FloatingActionButtonThemeData(
    backgroundColor: kPrimaryColor,
    foregroundColor: Colors.white,
    elevation: 4,
  ),

  // ثيم Divider
  dividerTheme: const DividerThemeData(
    color: kTextSecondary,
    thickness: 1,
    space: 1,
  ),

  // ثيم Icon
  iconTheme: const IconThemeData(color: kTextSecondary, size: kIconSize),

  // ثيم ListTile
  listTileTheme: const ListTileThemeData(
    contentPadding: EdgeInsets.symmetric(
      horizontal: kDefaultPadding,
      vertical: kDefaultPadding / 2,
    ),
    titleTextStyle: TextStyle(
      fontSize: 16,
      fontWeight: FontWeight.w500,
      color: kTextPrimary,
      fontFamily: 'Cairo',
    ),
    subtitleTextStyle: TextStyle(
      fontSize: 14, 
      color: kTextSecondary,
      fontFamily: 'Cairo',
    ),
  ),

  // ثيم Chip
  chipTheme: ChipThemeData(
    backgroundColor: kBackgroundColor,
    selectedColor: kPrimaryColor.withOpacity(0.1),
    labelStyle: const TextStyle(color: kTextPrimary),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
  ),

  // ثيم Switch
  switchTheme: SwitchThemeData(
    thumbColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return kPrimaryColor;
      }
      return kTextSecondary;
    }),
    trackColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return kPrimaryColor.withOpacity(0.5);
      }
      return kTextSecondary.withOpacity(0.3);
    }),
  ),

  // ثيم Checkbox
  checkboxTheme: CheckboxThemeData(
    fillColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return kPrimaryColor;
      }
      return Colors.transparent;
    }),
    checkColor: MaterialStateProperty.all(Colors.white),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
  ),

  // ثيم Radio
  radioTheme: RadioThemeData(
    fillColor: MaterialStateProperty.resolveWith((states) {
      if (states.contains(MaterialState.selected)) {
        return kPrimaryColor;
      }
      return kTextSecondary;
    }),
  ),

  // ثيم Slider
  sliderTheme: SliderThemeData(
    activeTrackColor: kPrimaryColor,
    inactiveTrackColor: kTextSecondary.withOpacity(0.3),
    thumbColor: kPrimaryColor,
    overlayColor: kPrimaryColor.withOpacity(0.2),
  ),

  // ثيم ProgressIndicator
  progressIndicatorTheme: const ProgressIndicatorThemeData(
    color: kPrimaryColor,
    linearTrackColor: kTextSecondary,
  ),

  // ثيم Tooltip
  tooltipTheme: TooltipThemeData(
    decoration: BoxDecoration(
      color: kTextPrimary,
      borderRadius: BorderRadius.circular(kBorderRadius),
    ),
    textStyle: const TextStyle(color: Colors.white, fontSize: 12),
  ),

  // ثيم SnackBar
  snackBarTheme: SnackBarThemeData(
    backgroundColor: kTextPrimary,
    contentTextStyle: const TextStyle(color: Colors.white),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
    ),
    behavior: SnackBarBehavior.floating,
  ),

  // ثيم Dialog
  dialogTheme: DialogThemeData(
    backgroundColor: kSurfaceColor,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(kBorderRadius),
    ),
    titleTextStyle: const TextStyle(
      fontSize: 18,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
    ),
    contentTextStyle: const TextStyle(fontSize: 14, color: kTextPrimary),
  ),

  // ثيم BottomSheet
  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: kSurfaceColor,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(kBorderRadius)),
    ),
  ),

  // ثيم NavigationRail
  navigationRailTheme: const NavigationRailThemeData(
    backgroundColor: kSurfaceColor,
    selectedIconTheme: IconThemeData(color: kPrimaryColor),
    unselectedIconTheme: IconThemeData(color: kTextSecondary),
    selectedLabelTextStyle: TextStyle(color: kPrimaryColor),
    unselectedLabelTextStyle: TextStyle(color: kTextSecondary),
  ),

  // ثيم TabBar
  tabBarTheme: const TabBarThemeData(
    labelColor: kPrimaryColor,
    unselectedLabelColor: kTextSecondary,
    indicatorColor: kPrimaryColor,
    labelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
    unselectedLabelStyle: TextStyle(fontSize: 14, fontWeight: FontWeight.w400),
  ),

  // ثيم ExpansionTile
  expansionTileTheme: const ExpansionTileThemeData(
    backgroundColor: kSurfaceColor,
    collapsedBackgroundColor: kBackgroundColor,
    textColor: kTextPrimary,
    iconColor: kTextSecondary,
    collapsedTextColor: kTextSecondary,
    collapsedIconColor: kTextSecondary,
  ),

  // ثيم DataTable
  dataTableTheme: const DataTableThemeData(
    headingTextStyle: TextStyle(
      fontSize: 14,
      fontWeight: FontWeight.bold,
      color: kTextPrimary,
    ),
    dataTextStyle: TextStyle(fontSize: 14, color: kTextPrimary),
    headingRowColor: MaterialStatePropertyAll(kBackgroundColor),
    dataRowColor: MaterialStatePropertyAll(kSurfaceColor),
  ),
);
