import 'package:flutter/material.dart';
import '../core/models.dart';
import '../core/services.dart';
import '../core/api_service.dart';

class AppProvider extends ChangeNotifier {
  // حالة التحميل
  bool _isLoading = false;
  bool get isLoading => _isLoading;

  // المستخدم الحالي
  User? _currentUser;
  User? get currentUser => _currentUser;

  // الباقات
  List<Package> _packages = [];
  List<Package> get packages => _packages;

  // السيارات
  List<Car> _cars = [];
  List<Car> get cars => _cars;

  // محطات الغسيل
  List<WashStation> _stations = [];
  List<WashStation> get stations => _stations;

  // الطلبات
  List<Order> _orders = [];
  List<Order> get orders => _orders;

  // السيارة المختارة
  Car? _selectedCar;
  Car? get selectedCar => _selectedCar;

  // الباقة المختارة
  Package? _selectedPackage;
  Package? get selectedPackage => _selectedPackage;
  void selectPackage(Package package) {
    _selectedPackage = package;
    notifyListeners();
  }

  void clearPackageSelection() {
    _selectedPackage = null;
    notifyListeners();
  }

  // محطة الغسيل المختارة
  WashStation? _selectedStation;
  WashStation? get selectedStation => _selectedStation;

  // الطلب الحالي
  Order? _currentOrder;
  Order? get currentOrder => _currentOrder;
  set currentOrder(Order? order) {
    _currentOrder = order;
    notifyListeners();
  }

  // Generated QR code (in-memory, for now)
  String? _generatedQrCode;
  String? get generatedQrCode => _generatedQrCode;
  void setGeneratedQrCode(String code) {
    _generatedQrCode = code;
    notifyListeners();
  }

  void clearGeneratedQrCode() {
    _generatedQrCode = null;
    notifyListeners();
  }

  // حجم السيارة المختار
  String? _selectedCarSize;
  String? get selectedCarSize => _selectedCarSize;
  void selectCarSize(String carSize) {
    _selectedCarSize = carSize;
    notifyListeners();
  }

  void clearCarSizeSelection() {
    _selectedCarSize = null;
    notifyListeners();
  }

  // هل تم اختيار الباقة وحجم السيارة؟
  bool get isReadyForPayment =>
      _selectedPackage != null && _selectedCarSize != null;

  // مسح جميع الاختيارات
  void clearSelections() {
    _selectedPackage = null;
    _selectedCarSize = null;
    notifyListeners();
  }

  // تهيئة التطبيق
  Future<void> initializeApp() async {
    _setLoading(true);
    try {
      await Future.wait([
        loadPackages(),
        loadCars(),
        loadStations(),
        loadOrders(),
        loadCurrentUser(),
      ]);
    } catch (e) {
      print('Error initializing app: $e');
    } finally {
      _setLoading(false);
    }
  }

  // تعيين حالة التحميل
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  // تحميل الباقات
  Future<void> loadPackages() async {
    try {
      _packages = await PackageService.getPackages();
      notifyListeners();
    } catch (e) {
      print('Error loading packages: $e');
    }
  }

  // تحميل السيارات
  Future<void> loadCars() async {
    try {
      _cars = await CarService.getCars();
      notifyListeners();
    } catch (e) {
      print('Error loading cars: $e');
    }
  }

  // تحميل محطات الغسيل
  Future<void> loadStations() async {
    try {
      _stations = await WashStationService.getStations();
      notifyListeners();
    } catch (e) {
      print('Error loading stations: $e');
    }
  }

  // تحميل الطلبات
  Future<void> loadOrders() async {
    try {
      _orders = await OrderService.getOrders();
      notifyListeners();
    } catch (e) {
      print('Error loading orders: $e');
    }
  }

  // تحميل المستخدم الحالي
  Future<void> loadCurrentUser() async {
    try {
      _currentUser = await UserService.getCurrentUser();
      notifyListeners();
    } catch (e) {
      print('Error loading current user: $e');
    }
  }

  // اختيار سيارة
  void selectCar(Car car) {
    _selectedCar = car;
    notifyListeners();
  }

  // اختيار محطة غسيل
  void selectStation(WashStation station) {
    _selectedStation = station;
    notifyListeners();
  }

  // إضافة سيارة جديدة
  Future<void> addCar(Car car) async {
    try {
      await CarService.saveCar(car);
      await loadCars();
    } catch (e) {
      print('Error adding car: $e');
      rethrow;
    }
  }

  // حذف سيارة
  Future<void> deleteCar(String carId) async {
    try {
      await CarService.deleteCar(carId);
      if (_selectedCar?.id == carId) {
        _selectedCar = null;
      }
      await loadCars();
    } catch (e) {
      print('Error deleting car: $e');
      rethrow;
    }
  }

  // Add a method to set the current user and token
  void setCurrentUser(User user) {
    _currentUser = user;
    notifyListeners();
  }

  // تسجيل الدخول
  Future<bool> login(String email, String password) async {
    try {
      final user = await ApiService.login(email, password);
      setCurrentUser(user);
      return true;
    } catch (e) {
      print('Error logging in: $e');
      return false;
    }
  }

  // Robust logout method
  Future<void> logout() async {
    try {
      await ApiService.logout(); // Clear token from storage
      _currentUser = null;
      notifyListeners();
    } catch (e) {
      print('Error logging out: $e');
    }
  }

  // Update user profile (name and email)
  Future<void> updateProfile(String name, String email) async {
    if (_currentUser == null) return;
    try {
      final updatedUser = await ApiService.updateProfile(name, email);
      _currentUser = updatedUser;
      notifyListeners();
    } catch (e) {
      print('Error updating profile: $e');
    }
  }

  // مسح جميع البيانات
  Future<void> clearAllData() async {
    try {
      await LocalDataService.clearAllData();
      _currentUser = null;
      _selectedCar = null;
      _selectedPackage = null;
      _selectedStation = null;
      _packages = [];
      _cars = [];
      _stations = [];
      _orders = [];
      notifyListeners();
    } catch (e) {
      print('Error clearing data: $e');
    }
  }

  // التحقق من كونها المرة الأولى
  Future<bool> isFirstTime() async {
    return await LocalDataService.isFirstTime();
  }

  // تعيين أنها ليست المرة الأولى
  Future<void> setNotFirstTime() async {
    await LocalDataService.setNotFirstTime();
  }

  // مسح الطلب الحالي
  void clearCurrentOrder() {
    _currentOrder = null;
    notifyListeners();
  }

  // Clear only car selection
  void clearCarSelection() {
    _selectedCar = null;
    notifyListeners();
  }

  // Hotel info for VIP flow
  Map<String, String>? _hotelInfo;
  Map<String, String>? get hotelInfo => _hotelInfo;
  void setHotelInfo(Map<String, String> info) {
    _hotelInfo = info;
    notifyListeners();
  }

  void clearHotelInfo() {
    _hotelInfo = null;
    notifyListeners();
  }

  // دفع بقشيش لمحطة الغسيل بعد الدفع عبر HyperPay
  Future<Map<String, dynamic>> createTipPaymentFromHyperPay({
    required String transactionId,
    required String stationId,
    required double amount,
    String method = 'hyperpay',
  }) async {
    return await ApiService.createTipPaymentFromHyperPay(
      transactionId: transactionId,
      stationId: stationId,
      amount: amount,
      method: method,
    );
  }
}
