import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:newapp/screens/auth/register_screen.dart';
import 'package:newapp/screens/hotel_selection_screen.dart';
import 'package:newapp/screens/qr_screen.dart';

import 'package:provider/provider.dart';

import 'core/constants.dart';
import 'core/models.dart';
import 'core/theme.dart';
import 'providers/app_provider.dart';
import 'screens/auth/login_screen.dart';
import 'screens/cars/car_selection_screen.dart';
import 'screens/main_navigation_screen.dart';
import 'screens/packages/package_details_screen.dart';
import 'screens/packages/package_selection_screen.dart';
import 'screens/payment_screen.dart';
import 'screens/splash_screen.dart';
import 'screens/washing places/washing_place_details_screen.dart';
import 'screens/washing places/washing_place_map_screen.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/owner_qr_scan_screen.dart';
import 'screens/washing places/washing_places_screen.dart';
import 'screens/user/user_profile_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/maps_test_screen.dart';
import 'screens/home_screen.dart';
import 'screens/cars/cars_screen.dart';
import 'screens/checkout_screen.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
  );

  // Add error handling for initialization
  try {
    // Initialize app provider
    final appProvider = AppProvider();
    await appProvider.initializeApp();

    // Initialize platform-specific services
    if (!kIsWeb) {
      // Add platform-specific initialization here
    }

    runApp(const PayPassApp());
  } catch (e) {
    print('Error during app initialization: $e');
    // Still try to run the app even if initialization fails
    runApp(const PayPassApp());
  }
}

class PayPassApp extends StatelessWidget {
  const PayPassApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => MultiProvider(
        providers: [ChangeNotifierProvider(create: (_) => AppProvider())],
        child: Consumer<AppProvider>(
          builder: (context, provider, _) {
            print(
              'AppProvider state - isLoading: ${provider.isLoading}, currentUser: ${provider.currentUser}',
            );

            // Show splash screen while loading
            if (provider.isLoading) {
              print('Showing splash screen');
              return MaterialApp(
                title: kAppName,
                debugShowCheckedModeBanner: false,
                theme: appTheme,
                home: const SplashScreen(),
                locale: const Locale('ar', 'SA'),
                supportedLocales: const [
                  Locale('ar', 'SA'),
                  Locale('en', 'US')
                ],
                localizationsDelegates: const [
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],
              );
            }

            // Always start with SplashScreen, let it handle navigation
            return MaterialApp(
              title: kAppName,
              debugShowCheckedModeBanner: false,
              theme: appTheme,
              home: const SplashScreen(),
              locale: const Locale('ar', 'SA'),
              supportedLocales: const [Locale('ar', 'SA'), Locale('en', 'US')],
              localizationsDelegates: const [
                GlobalMaterialLocalizations.delegate,
                GlobalWidgetsLocalizations.delegate,
                GlobalCupertinoLocalizations.delegate,
              ],
              onGenerateRoute: (settings) {
                try {
                  switch (settings.name) {
                    case '/':
                      return MaterialPageRoute(
                        builder: (context) => const SplashScreen(),
                      );
                    case '/login':
                      return MaterialPageRoute(
                        builder: (context) => const LoginScreen(),
                      );
                    case '/package-selection':
                      return MaterialPageRoute(
                        builder: (context) => const PackageSelectionScreen(),
                      );
                    case '/package-details':
                      final args = settings.arguments as Map<String, dynamic>?;
                      if (args != null && args['package'] != null) {
                        final package = args['package'] as Package;
                        final selectedCarId = args['selectedCarId'] as String?;
                        return MaterialPageRoute(
                          builder: (context) => PackageDetailsScreen(
                            package: package,
                            selectedCarId: selectedCarId,
                          ),
                        );
                      }
                      // Return to main navigation if no valid package data
                      return MaterialPageRoute(
                        builder: (context) => const MainNavigationScreen(),
                      );
                    case '/washing-place-details':
                      final args = settings.arguments as Map<String, dynamic>?;
                      if (args != null && args['station'] != null) {
                        final station = args['station'] as WashStation;
                        return MaterialPageRoute(
                          builder: (context) =>
                              WashingPlaceDetailsScreen(station: station),
                        );
                      }
                      return MaterialPageRoute(
                        builder: (context) => const MainNavigationScreen(),
                      );

                    case '/register':
                      return MaterialPageRoute(
                        builder: (context) => const RegisterScreen(),
                      );
                    case '/washing-place-map':
                      final args = settings.arguments as Map<String, dynamic>?;
                      if (args != null && args['station'] != null) {
                        final station = args['station'] as WashStation;
                        return MaterialPageRoute(
                          builder: (context) =>
                              WashingPlaceMapScreen(station: station),
                        );
                      }
                      return MaterialPageRoute(
                        builder: (context) => const MainNavigationScreen(),
                      );
                    case '/payment':
                      // السماح بالوصول لصفحة الدفع بدون تحقق من تسجيل الدخول
                      return MaterialPageRoute(
                        builder: (context) => const PaymentScreen(),
                      );
                    case '/checkout':
                      return MaterialPageRoute(
                        builder: (context) => const CheckoutScreen(),
                      );
                    case '/car-selection':
                      return MaterialPageRoute(
                        builder: (context) => const CarSelectionScreen(),
                      );

                    case '/qr':
                      return MaterialPageRoute(
                        builder: (context) => const QRScreen(),
                      );
                    case '/washing-places':
                      return MaterialPageRoute(
                        builder: (context) => const WashingPlacesScreen(),
                      );
                    case '/profile':
                      return MaterialPageRoute(
                        builder: (context) => const UserProfileScreen(),
                      );
                    case '/notifications':
                      return MaterialPageRoute(
                        builder: (context) => const NotificationsScreen(),
                      );
                    case '/maps-test':
                      return MaterialPageRoute(
                        builder: (context) => const MapsTestScreen(),
                      );
                    case '/home':
                      return MaterialPageRoute(
                        builder: (context) => const HomeScreen(),
                      );

                    case '/hotel-selection':
                      return MaterialPageRoute(
                        builder: (context) =>  HotelSelectionScreen(),
                      );
                    case '/cars':
                      return MaterialPageRoute(
                        builder: (context) => const CarsScreen(),
                      );
                    default:
                      return MaterialPageRoute(
                        builder: (context) => const MainNavigationScreen(),
                      );
                  }
                } catch (e) {
                  print('Route generation error: $e');
                  return MaterialPageRoute(
                    builder: (context) => const MainNavigationScreen(),
                  );
                }
              },
            );
          },
        ),
      );
}

// Custom animated loading widget
class AnimatedAppLoading extends StatefulWidget {
  const AnimatedAppLoading({Key? key}) : super(key: key);

  @override
  State<AnimatedAppLoading> createState() => _AnimatedAppLoadingState();
}

class _AnimatedAppLoadingState extends State<AnimatedAppLoading>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);
    final curve = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _scaleAnimation = Tween<double>(begin: 0.85, end: 1.15).animate(curve);
    _fadeAnimation = Tween<double>(begin: 0.5, end: 1.0).animate(curve);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ScaleTransition(
          scale: _scaleAnimation,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              FadeTransition(
                opacity: _fadeAnimation,
                child: ScaleTransition(
                  scale: _scaleAnimation,
                  child: Image.asset(
                    'assets/images/logo.png',
                    width: 80,
                    height: 80,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                kAppName,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: kPrimaryColor,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'جاري تحميل الصفحة',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'برجاء الإنتظار',
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
