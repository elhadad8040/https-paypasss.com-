import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../core/constants.dart';
import '../core/services.dart';
import '../core/models.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<Package>> _packagesFuture;
  late Future<User?> _userFuture;
  late Future<List<WashStation>> _stationsFuture;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _packagesFuture = PackageService.getPackages();
      _userFuture = UserService.getCurrentUser();
      _stationsFuture = WashStationService.getStations();
    });
  }

  @override
  // ignore: prefer_expression_function_bodies
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final appProvider = Provider.of<AppProvider>(context);
    final userName = appProvider.currentUser?.name ?? 'زائر';

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: const Text('الرئيسية'),
        ),
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _loadData,
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                // الشريط العلوي
                Container(
                  color: theme.scaffoldBackgroundColor,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: theme.cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: theme.dividerColor),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.directions_car,
                                size: 20, color: theme.iconTheme.color),
                            const SizedBox(width: 4),
                            Text('٣',
                                style: (theme.textTheme.titleMedium ??
                                        theme.textTheme.bodyMedium)
                                    ?.copyWith(fontWeight: FontWeight.bold)),
                            const SizedBox(width: 4),
                            Text('الباقة الأساسية',
                                style: theme.textTheme.bodySmall ??
                                    const TextStyle()),
                          ],
                        ),
                      ),
                      const Spacer(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('مرحباً',
                              style: theme.textTheme.bodyMedium ??
                                  const TextStyle()),
                          Text(userName,
                              style: (theme.textTheme.titleMedium ??
                                          theme.textTheme.bodyMedium)
                                      ?.copyWith(fontWeight: FontWeight.bold) ??
                                  const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(width: 8),
                      CircleAvatar(
                        backgroundColor: theme.iconTheme.color,
                        radius: 18,
                      ),
                    ],
                  ),
                ),
                // دعوة الأصدقاء
                // Container(
                //   decoration: BoxDecoration(
                //     color: theme.cardColor,
                //     borderRadius: const BorderRadius.vertical(
                //         bottom: Radius.circular(24)),
                //   ),
                //   padding:
                //       const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                //   child: Column(
                //     children: [
                //       Container(
                //         decoration: BoxDecoration(
                //           color: theme.scaffoldBackgroundColor,
                //           borderRadius: BorderRadius.circular(16),
                //         ),
                //         padding: const EdgeInsets.all(12),
                //         child: Column(
                //           children: [
                //             Text(
                //               'ادعُ أصدقائك واربح خصمًا!',
                //               style: (theme.textTheme.titleLarge ??
                //                           theme.textTheme.titleMedium)
                //                       ?.copyWith(fontWeight: FontWeight.bold) ??
                //                   const TextStyle(fontWeight: FontWeight.bold),
                //             ),
                //             const SizedBox(height: 4),
                //             Text(
                //               'شارك تطبيق PAYPASS مع أصدقائك، وكل واحد منكم يحصل على خصم عند أول غسلة!',
                //               style: theme.textTheme.bodyMedium ??
                //                   const TextStyle(),
                //               textAlign: TextAlign.center,
                //             ),
                //             const SizedBox(height: 10),
                //             const SizedBox(
                //               width: double.infinity,
                //               child: ElevatedButton(
                //                 onPressed: null,
                //                 child: Text('أرسل رابط الدعوة'),
                //               ),
                //             ),
                //           ],
                //         ),
                //       ),
                //     ],
                //   ),
                // ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Text(
                    'مرحباً بك في PAYPASS! استمتع بخدماتنا.',
                    style: (theme.textTheme.headlineSmall ?? theme.textTheme.titleLarge)
                            ?.copyWith(fontWeight: FontWeight.bold, color: theme.primaryColor)
                        ?? const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 20),
                    textAlign: TextAlign.center,
                  ),
                ),
               
               
                // الباقات
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      Text(
                        'الباقات',
                        style: (theme.textTheme.headlineSmall ??
                                    theme.textTheme.titleLarge)
                                ?.copyWith(fontWeight: FontWeight.bold) ??
                            const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 220,
                  child: FutureBuilder<List<Package>>(
                    future: _packagesFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(
                            child: CircularProgressIndicator(
                                color: theme.primaryColor));
                      }
                      if (snapshot.hasError) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.error_outline,
                                  color: theme.colorScheme.error, size: 48),
                              const SizedBox(height: 8),
                              Text(
                                'حدث خطأ أثناء تحميل الباقات',
                                style: theme.textTheme.bodyMedium ??
                                    const TextStyle(),
                              ),
                              const SizedBox(height: 8),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _loadData();
                                  });
                                },
                                child: const Text('إعادة المحاولة'),
                              ),
                            ],
                          ),
                        );
                      }
                      final packages = snapshot.data ?? [];
                      if (packages.isEmpty) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.inbox_outlined,
                                  color: theme.iconTheme.color, size: 48),
                              const SizedBox(height: 8),
                              Text(
                                'لا توجد باقات متاحة',
                                style: theme.textTheme.bodyMedium ??
                                    const TextStyle(),
                              ),
                            ],
                          ),
                        );
                      }
                      return ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: packages.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final pkg = packages[index];
                          final savings = pkg.originalPrice != null
                              ? (pkg.originalPrice! - pkg.price)
                                  .toStringAsFixed(0)
                              : (pkg.price * 0.3).toStringAsFixed(0);

                          return _packageCard(
                            title: pkg.name,
                            washes: '${pkg.washes} غسلة',
                            price: '${pkg.price.toStringAsFixed(0)} ريال',
                            extra: 'صالحة لمدة ${pkg.validityDays} يوم',
                            save: 'وفر $savings ريال',
                            rating: pkg.isPopular ? 'الأكثر شعبية' : '4.8',
                            isPopular: pkg.isPopular,
                            onTap: () {
                              // Add haptic feedback
                              HapticFeedback.lightImpact();

                              Navigator.pushNamed(
                                context,
                                '/package-details',
                                arguments: {
                                  'package': pkg,
                                },
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
                // عروض مميزة
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Text(
                    'عروض مميزة',
                    style: (theme.textTheme.headlineSmall ??
                                theme.textTheme.titleLarge)
                            ?.copyWith(fontWeight: FontWeight.bold) ??
                        const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 16),
                  height: 100,
                  decoration: BoxDecoration(
                    color: theme.scaffoldBackgroundColor,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.local_offer_outlined,
                          size: 32,
                          color: theme.iconTheme.color?.withOpacity(0.5),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'لا توجد عروض متاحة حالياً',
                          style:
                              (theme.textTheme.bodyMedium ?? const TextStyle())
                                  ?.copyWith(
                            color:
                                (theme.textTheme.bodySmall ?? const TextStyle())
                                    .color
                                    ?.withOpacity(0.7),
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
                ),
                // محطات غسيل السيارات
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'محطات غسيل السيارات',
                        style: (theme.textTheme.headlineSmall ??
                                    theme.textTheme.titleLarge)
                                ?.copyWith(fontWeight: FontWeight.bold) ??
                            const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/washing-places');
                        },
                        child: Text(
                          'عرض الكل',
                          style: (theme.textTheme.labelLarge ??
                                      theme.textTheme.bodyMedium)
                                  ?.copyWith(
                                color: theme.primaryColor,
                                fontWeight: FontWeight.bold,
                              ) ??
                              TextStyle(
                                color: theme.primaryColor,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 220,
                  child: FutureBuilder<List<WashStation>>(
                    future: _stationsFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return Center(
                            child: CircularProgressIndicator(
                                color: theme.primaryColor));
                      }
                      if (snapshot.hasError) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.error_outline,
                                  color: theme.colorScheme.error, size: 48),
                              const SizedBox(height: 8),
                              Text(
                                'حدث خطأ أثناء تحميل محطات الغسيل',
                                style: theme.textTheme.bodyMedium ??
                                    const TextStyle(),
                              ),
                              const SizedBox(height: 8),
                              ElevatedButton(
                                onPressed: () {
                                  setState(() {
                                    _loadData();
                                  });
                                },
                                child: const Text('إعادة المحاولة'),
                              ),
                            ],
                          ),
                        );
                      }
                      final stations = snapshot.data ?? [];
                      if (stations.isEmpty) {
                        return Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.location_off,
                                  color: theme.iconTheme.color, size: 48),
                              const SizedBox(height: 8),
                              Text(
                                'لا توجد محطات متاحة',
                                style: theme.textTheme.bodyMedium ??
                                    const TextStyle(),
                              ),
                            ],
                          ),
                        );
                      }
                      return ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: stations.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemBuilder: (context, index) {
                          final station = stations[index];
                          return _stationCard(
                            name: station.name,
                            location: station.location,
                            distance: station.distance,
                            rating: station.rating.toStringAsFixed(1),
                            isOpen: station.isOpen,
                            onTap: () {
                              // Add haptic feedback
                              HapticFeedback.lightImpact();

                              Navigator.pushNamed(
                                context,
                                '/washing-place-details',
                                arguments: {
                                  'station': station,
                                },
                              );
                            },
                          );
                        },
                      );
                    },
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _packageCard({
    required String title,
    required String washes,
    required String price,
    required String extra,
    required String save,
    required String rating,
    bool isPopular = false,
    VoidCallback? onTap,
  }) {
    final theme = Theme.of(context);

    return GestureDetector(
        onTap: onTap,
        child: Container(
          width: 180,
          height: 250,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: theme.cardColor,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: theme.dividerColor),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  if (isPopular)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: theme.primaryColor,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'الأكثر شعبية',
                        style: (theme.textTheme.labelSmall ??
                                    theme.textTheme.bodySmall)
                                ?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ) ??
                            const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                      ),
                    )
                  else
                    Row(
                      children: [
                        Text(
                          rating,
                          style: (theme.textTheme.bodyMedium ??
                                      theme.textTheme.bodySmall)
                                  ?.copyWith(fontWeight: FontWeight.bold) ??
                              const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const Icon(Icons.star, color: kWarningColor, size: 16),
                      ],
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                title,
                style:
                    (theme.textTheme.titleMedium ?? theme.textTheme.bodyLarge)
                            ?.copyWith(fontWeight: FontWeight.bold) ??
                        const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                washes,
                style: theme.textTheme.bodyMedium ?? const TextStyle(),
              ),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: theme.primaryColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  save,
                  style:
                      (theme.textTheme.labelSmall ?? theme.textTheme.bodySmall)
                              ?.copyWith(color: Colors.white) ??
                          const TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                price,
                style:
                    (theme.textTheme.titleLarge ?? theme.textTheme.titleMedium)
                            ?.copyWith(fontWeight: FontWeight.bold) ??
                        const TextStyle(fontWeight: FontWeight.bold),
              ),
              Text(
                extra,
                style: theme.textTheme.bodySmall ?? const TextStyle(),
              ),
              const Spacer(),
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.add, color: Colors.white),
                    onPressed: () {
                      // Add haptic feedback
                      HapticFeedback.lightImpact();

                      // Get the app provider
                      final appProvider = Provider.of<AppProvider>(
                        context,
                        listen: false,
                      );

                      // Select the package
                      if (onTap != null) {
                        // Extract the package from the onTap callback
                        // This is a workaround since we don't have direct access to the package object here
                        // The onTap callback navigates to package details, so we need to get the package first
                        final pkg = appProvider.packages.firstWhere(
                          (p) =>
                              p.name == title &&
                              p.washes.toString() + ' غسلة' == washes,
                          orElse: () => appProvider.packages.first,
                        );

                        // Select the package
                        appProvider.selectPackage(pkg);

                        // Navigate to car selection
                        Navigator.of(context).pushNamed('/car-selection');
                      }
                    },
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  Widget _stationCard({
    required String name,
    required String location,
    required String distance,
    required String rating,
    required bool isOpen,
    VoidCallback? onTap,
  }) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 220,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: theme.dividerColor),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isOpen ? Colors.green : Colors.red,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    isOpen ? 'مفتوح' : 'مغلق',
                    style: (theme.textTheme.labelSmall ??
                                theme.textTheme.bodySmall)
                            ?.copyWith(color: Colors.white) ??
                        const TextStyle(color: Colors.white),
                  ),
                ),
                Row(
                  children: [
                    Text(
                      rating,
                      style: (theme.textTheme.bodyMedium ??
                                  theme.textTheme.bodySmall)
                              ?.copyWith(fontWeight: FontWeight.bold) ??
                          const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const Icon(Icons.star, color: kWarningColor, size: 16),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              name,
              style: (theme.textTheme.titleLarge ?? theme.textTheme.titleMedium)
                      ?.copyWith(fontWeight: FontWeight.bold) ??
                  const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.location_on, size: 14, color: theme.iconTheme.color),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    location,
                    style: theme.textTheme.bodySmall ?? const TextStyle(),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.directions_car,
                    size: 14, color: theme.iconTheme.color),
                const SizedBox(width: 4),
                Text(
                  distance,
                  style: theme.textTheme.bodySmall ?? const TextStyle(),
                ),
              ],
            ),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onTap,
                child: const Text('احجز الآن'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
