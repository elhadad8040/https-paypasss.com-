import 'package:flutter/material.dart';
import 'package:newapp/core/models.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/services.dart';
import '../../providers/app_provider.dart';
import '../../main.dart';

class CarSelectionScreen extends StatefulWidget {
  const CarSelectionScreen({Key? key}) : super(key: key);

  @override
  State<CarSelectionScreen> createState() => _CarSelectionScreenState();
}

class _CarSelectionScreenState extends State<CarSelectionScreen> {
  String? _selectedCarSizeKey;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final appProvider = Provider.of<AppProvider>(context);
    final selectedPackage = appProvider.selectedPackage;
    
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text('اختر حجم السيارة', style: theme.appBarTheme.titleTextStyle),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ...kCarSizes.map((carSize) {
              final isSelected = _selectedCarSizeKey == carSize['key'];
              // حساب السعر الإجمالي إذا كانت هناك باقة مختارة
              final double totalPrice = selectedPackage != null 
                  ? selectedPackage.price * (carSize['priceFactor'] as double)
                  : 0.0;
              
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: isSelected ? (carSize['color'] as Color).withOpacity(0.12) : theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: isSelected
                      ? Border.all(
                         color: carSize['color'] as Color,
                         width: 2,
                       )
                      : null,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: RadioListTile<String>(
                  value: carSize['key'],
                  groupValue: _selectedCarSizeKey,
                  onChanged: (value) {
                    setState(() {
                      _selectedCarSizeKey = value;
                    });
                  },
                  activeColor: carSize['color'] as Color,
                  title: Row(
                    children: [
                      Icon(carSize['icon'] as IconData, color: carSize['color'] as Color, size: 32),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          carSize['name'],
                          style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold, color: carSize['color'] as Color),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('معامل السعر: ${carSize['priceFactor']}'),
                      if (selectedPackage != null)
                        Text(
                          'السعر الإجمالي: ${totalPrice.toStringAsFixed(2)} ريال',
                          style: TextStyle(color: carSize['color'] as Color, fontWeight: FontWeight.bold),
                        ),
                    ],
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                ),
              );
            }).toList(),
            const SizedBox(height: 32),
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _selectedCarSizeKey != null
                    ? () => _confirmSelection(context)
                    : null,
                child: Text(
                  'تأكيد الاختيار',
                  style: theme.textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: theme.colorScheme.onPrimary,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmSelection(BuildContext context) async {
    if (_selectedCarSizeKey != null) {
      final appProvider = Provider.of<AppProvider>(context, listen: false);
      // Save the English key to the provider (for backend)
      print('Selected car size key for backend: $_selectedCarSizeKey');
      appProvider.selectCarSize(_selectedCarSizeKey!);
      // التوجه مباشرة إلى صفحة الدفع إذا كانت الباقة مختارة
      if (appProvider.selectedPackage != null) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => const AnimatedAppLoading(),
        );
        await Future.delayed(const Duration(seconds: 2));
        if (Navigator.of(context).canPop()) Navigator.of(context).pop();
        Navigator.of(context).pushNamed('/checkout');
      } else {
        // إذا لم تكن الباقة مختارة، توجيه المستخدم إلى اختيار الباقة أولاً
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('يرجى اختيار الباقة أولاً')),
        );
        Navigator.of(context).pushReplacementNamed('/package-selection');
      }
    }
  }
}
