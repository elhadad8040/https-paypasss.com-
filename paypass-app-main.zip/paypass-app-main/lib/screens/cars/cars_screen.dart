import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../core/services.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';

class CarsScreen extends StatefulWidget {
  const CarsScreen({Key? key}) : super(key: key);

  @override
  State<CarsScreen> createState() => _CarsScreenState();
}

class _CarsScreenState extends State<CarsScreen> {
  List<Car> _cars = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadCars();
  }

  Future<void> _loadCars() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final allCars = await CarService.getCars();
      final provider = mounted ? Provider.of<AppProvider>(context, listen: false) : null;
      final userCarIds = provider?.currentUser?.cars ?? [];
      List<Car> userCars = allCars.where((car) => userCarIds.contains(car.id)).toList();
      if (userCars.isEmpty) {
        userCars = allCars;
      }
      setState(() {
        _cars = userCars;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'حدث خطأ في تحميل البيانات';
      });
      print('Error loading cars: $e');
    }
  }

  void _addNewCar() {
    Navigator.of(context).pushNamed('/car-selection');
  }

  void _selectCar(Car car) {
    Navigator.of(context).pushNamed('/package-selection');
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          appBar: AppBar(
            title: Text('سياراتي', style: Theme.of(context).appBarTheme.titleTextStyle),
            actions: [
              IconButton(
                icon: Icon(Icons.add, color: Theme.of(context).iconTheme.color),
                onPressed: _addNewCar,
              ),
            ],
          ),
          body: _isLoading
              ? Center(
                  child: CircularProgressIndicator(color: Theme.of(context).primaryColor),
                )
              : _errorMessage != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _errorMessage!,
                            style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Theme.of(context).colorScheme.error),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadCars,
                            child: Text('إعادة المحاولة', style: Theme.of(context).textTheme.labelLarge),
                          ),
                        ],
                      ),
                    )
                  : _cars.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.directions_car,
                                size: 64,
                                color: Theme.of(context).iconTheme.color,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                'لا توجد سيارات مسجلة',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                'أضف سيارتك الأولى للبدء',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                              const SizedBox(height: 24),
                              ElevatedButton(
                                onPressed: _addNewCar,
                                child: Text('إضافة سيارة', style: Theme.of(context).textTheme.labelLarge),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: _cars.length,
                          itemBuilder: (context, index) {
                            final car = _cars[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: _buildCarCard(context, car),
                            );
                          },
                        ),
          floatingActionButton: _cars.isNotEmpty
              ? FloatingActionButton(
                  onPressed: _addNewCar,
                  backgroundColor: Theme.of(context).primaryColor,
                  child: Icon(Icons.add, color: Theme.of(context).colorScheme.onPrimary),
                )
              : null,
        ),
      );

  Widget _buildCarCard(BuildContext context, Car car) => DecoratedBox(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ListTile(
          contentPadding: const EdgeInsets.all(20),
          leading: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.directions_car,
              color: Theme.of(context).primaryColor,
              size: 32,
            ),
          ),
          title: Text(
            car.name,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 8),
              Text(
                'النوع: ${car.type}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              Text(
                'اللون: ${car.color}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              Text(
                'رقم اللوحة: ${car.plateNumber}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
          trailing: IconButton(
            icon: Icon(Icons.arrow_forward_ios, color: Theme.of(context).iconTheme.color),
            onPressed: () => _selectCar(car),
          ),
          onTap: () => _selectCar(car),
        ),
      );
}
