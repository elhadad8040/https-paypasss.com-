import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/models.dart';

import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../core/api_service.dart';
import 'package:flutter/foundation.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter/services.dart' show rootBundle;
import '../main.dart';

class PaymentScreen extends StatefulWidget {
  const PaymentScreen({Key? key}) : super(key: key);

  @override
  State<PaymentScreen> createState() => _PaymentScreenState();
}

class _PaymentScreenState extends State<PaymentScreen> {
  String _selectedPaymentMethod = 'mada'; // Default to MADA
  bool _isLoading = false;
  Map<String, dynamic>? _orderData;
  Order? _order;
  Car? _car;
  Package? _package;
  User? _user;
  Map<String, dynamic>? _hotelArgs;

  // Billing form controllers
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _streetController = TextEditingController();
  final TextEditingController _cityController = TextEditingController();
  final TextEditingController _stateController = TextEditingController();
  final TextEditingController _postcodeController = TextEditingController();
  final TextEditingController _givenNameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  final TextEditingController _phoneController =
      TextEditingController(); // New phone controller

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final provider = Provider.of<AppProvider>(context, listen: false);
    _order = provider.currentOrder;
    _car = provider.selectedCar;
    _package = provider.selectedPackage;
    _user = provider.currentUser;

    // Get hotel info from arguments if present
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    if (args != null && args['hotelName'] != null) {
      _hotelArgs = args;
    }

    // Pre-fill billing form if user data exists
    if (_user != null) {
      _givenNameController.text = _user!.name?.split(' ').first ?? '';
      _surnameController.text = _user!.name?.split(' ').length == 1
          ? ''
          : _user!.name?.split(' ').last ?? '';
      _phoneController.text = _user!.phone ?? '';
    }

    // Check what's missing and redirect accordingly
    _checkRequiredSelections();
  }

  void _checkRequiredSelections() {
    final provider = Provider.of<AppProvider>(context, listen: false);
    final package = provider.selectedPackage;
    final carSizeKey = provider.selectedCarSize;

    if (package == null && carSizeKey == null) {
      // Both missing - go to package selection first
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showErrorAndNavigate(
            'يرجى اختيار الباقة وحجم السيارة أولاً', '/package-selection');
      });
    } else if (package == null) {
      // Only package missing
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showErrorAndNavigate('يرجى اختيار الباقة أولاً', '/package-selection');
      });
    } else if (carSizeKey == null) {
      // Only car size missing
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showErrorAndNavigate(
            'يرجى اختيار حجم السيارة أولاً', '/car-selection');
      });
    }
  }

  void _showErrorAndNavigate(String message, String route) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
      ),
    );
    Navigator.of(context).pushReplacementNamed(route);
  }

  @override
  void dispose() {
    _streetController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _postcodeController.dispose();
    _givenNameController.dispose();
    _surnameController.dispose();
    _phoneController.dispose(); // Dispose phone controller
    super.dispose();
  }

  Future<void> _processPayment() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final provider = Provider.of<AppProvider>(context, listen: false);
      _car = provider.selectedCar;
      _package = provider.selectedPackage;
      _user = provider.currentUser;
      if (_car == null || _package == null || _user == null) {
        throw Exception('الرجاء اختيار السيارة والباقة');
      }
      final amount = (_package?.price ?? 0) * (_car?.priceMultiplier ?? 1);
      // Generate a QR code string (simulate backend)
      final qrCode = 'QR_${_user!.id}_${DateTime.now().millisecondsSinceEpoch}';
      provider.setGeneratedQrCode(qrCode);
      // Optionally, you can still call PaymentService.createPayment(payment) if needed
      // Navigate to profile page to show QR code
      if (mounted) {
        Navigator.of(context).pushReplacementNamed('/profile');
      }
      // Optionally, schedule feedback notification as before
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('حدث خطأ: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _startHyperpayPayment() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _isLoading = true;
    });
    try {
      final provider = Provider.of<AppProvider>(context, listen: false);
      final user = provider.currentUser;
      final package = provider.selectedPackage;
      final carSizeKey = provider.selectedCarSize;

      if (user == null || package == null || carSizeKey == null) {
        throw Exception('الرجاء اختيار حجم السيارة والباقة');
      }

      // Get price factor from kCarSizes
      final carSize = kCarSizes.firstWhere((e) => e['key'] == carSizeKey);
      final double priceFactor = carSize['priceFactor'] ?? 1.0;
      final isVip =
          package.name.contains('VIP') || package.name.contains('فاخرة');
      final double price =
          isVip ? (package.price ?? 0) : (package.price ?? 0) * priceFactor;
      final double vat = price * 0.15;
      double total = price + vat;
      total = total.ceilToDouble();

      final merchantTransactionId =
          'TXN_${DateTime.now().millisecondsSinceEpoch}';
      final response = await ApiService.createHyperpayCheckout(
        amount: total, // Send total with VAT
        currency: 'SAR',
        merchantTransactionId: merchantTransactionId,
        customerEmail: user.email,
        billingStreet1: 'Riyadh', // Static
        billingCity: 'Riyadh', // Static
        billingState: 'Riyadh', // Static
        billingCountry: 'SA',
        billingPostcode: '12211', // Static zip code for Riyadh
        customerGivenName: _givenNameController.text,
        customerSurname: _surnameController.text,
        // Do not send customerPhone here
      );

      final checkoutId = response['id'];
      if (checkoutId == null) throw Exception('فشل في الحصول على checkoutId');
      if (!mounted) return;

      if (kIsWeb) {
        final params = [
          'checkoutId=$checkoutId',
          'userId=${user.id}',
          'packageId=${package.id}',
          'carSize=$carSizeKey',
          'billingStreet1=Riyadh',
          'billingCity=Riyadh',
          'billingState=Riyadh',
          'billingCountry=SA',
          'billingPostcode=12211',
          'customerGivenName=${Uri.encodeComponent(_givenNameController.text)}',
          'customerSurname=${Uri.encodeComponent(_surnameController.text)}',
          'customerPhone=${Uri.encodeComponent(_phoneController.text)}',
          'total=${total.toStringAsFixed(2)}',
        ].join('&');
        final paymentUrl =
            'https://mellifluous-eclair-f3f079.netlify.app/?$params';
        await _launchPaymentUrl(paymentUrl);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'تم فتح صفحة الدفع في نافذة جديدة. بعد إتمام الدفع، عد إلى التطبيق.')),
        );
      } else {
        // Build params for mobile just like web
        final params = [
          'checkoutId=$checkoutId',
          'userId=${user.id}',
          'packageId=${package.id}',
          'carSize=$carSizeKey',
          'billingStreet1=Riyadh',
          'billingCity=Riyadh',
          'billingState=Riyadh',
          'billingCountry=SA',
          'billingPostcode=12211',
          'customerGivenName=${Uri.encodeComponent(_givenNameController.text)}',
          'customerSurname=${Uri.encodeComponent(_surnameController.text)}',
          'customerPhone=${Uri.encodeComponent(_phoneController.text)}',
          'total=${total.toStringAsFixed(2)}',
        ].join('&');
        final paymentUrl =
            'https://mellifluous-eclair-f3f079.netlify.app/?$params';
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => const AnimatedAppLoading(),
        );
        await Future.delayed(const Duration(seconds: 1));
        if (Navigator.of(context).canPop()) Navigator.of(context).pop();
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => HyperPayWebViewScreen(
              checkoutId: checkoutId,
              paymentUrl: paymentUrl,
            ),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('خطأ في الدفع: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted)
        setState(() {
          _isLoading = false;
        });
    }
  }

  Future<void> _launchPaymentUrl(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, webOnlyWindowName: '_blank');
    } else {
      throw Exception('لا يمكن فتح رابط الدفع');
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context, listen: false);
    final package = provider.selectedPackage;
    final carSizeKey = provider.selectedCarSize;

    // If we don't have the required selections, show loading while redirecting
    if (package == null || carSizeKey == null) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final carSize = kCarSizes.firstWhere((e) => e['key'] == carSizeKey,
        orElse: () => <String, dynamic>{});
    final bool isVip = (package?.name.contains('VIP') ?? false) ||
        (package?.name.contains('فاخرة') ?? false);
    final double price = isVip
        ? (package?.price ?? 0)
        : (package?.price ?? 0) * (carSize['priceFactor'] ?? 1.0);
    final double vat = price * 0.15;
    double total = price + vat;
    total = total.ceilToDouble();
    final double? originalPrice = (package?.originalPrice != null &&
            package?.originalPrice != package?.price)
        ? (isVip
            ? package!.originalPrice!
            : package!.originalPrice! * (carSize['priceFactor'] ?? 1.0))
        : null;

    // Get hotel info from arguments if present, else from provider
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    final hotelInfo = (args != null && args['hotelName'] != null)
        ? args
        : (provider.hotelInfo ?? {});
    final hotelName = hotelInfo['hotelName'] ?? '';
    final guestName = hotelInfo['guestName'] ?? '';
    final guestEmail = hotelInfo['guestEmail'] ?? '';
    final roomNumber = hotelInfo['roomNumber'] ?? '';
    final hasHotel = hotelName.isNotEmpty;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey[100],
        appBar: AppBar(
          title: const Text('الدفع'),
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context).pop();
            },
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ملخص الطلب
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'ملخص الطلب',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: kPrimaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildOrderItem('اسم المستخدم', _user?.name ?? ''),
                      _buildOrderItem('الباقة', package.name),
                      _buildOrderItem('حجم السيارة', carSize['name'] ?? ''),
                      if (originalPrice != null)
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('السعر الأساسي:',
                                style: TextStyle(
                                    fontSize: 16, color: Colors.grey)),
                            Text(
                              '${originalPrice.toStringAsFixed(2)} ريال',
                              style: const TextStyle(
                                decoration: TextDecoration.lineThrough,
                                color: Colors.grey,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      _buildOrderItem(
                          'سعر الباقة', '${price.toStringAsFixed(2)} ريال'),
                      const Divider(),
                      _buildOrderItem('ضريبة القيمة المضافة',
                          '${vat.toStringAsFixed(2)} ريال'),
                      const Divider(),
                      _buildOrderItem(
                          'المجموع', '${total.toStringAsFixed(2)} ريال',
                          isTotal: true),
                    ],
                  ),
                ),

                if (hasHotel) ...[
                  const SizedBox(height: 24),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('معلومات الفندق', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: kPrimaryColor)),
                        const SizedBox(height: 12),
                        _buildOrderItem('اسم الفندق', hotelName),
                        _buildOrderItem('اسم النزيل', guestName),
                        if (guestEmail.isNotEmpty) _buildOrderItem('البريد الإلكتروني', guestEmail),
                        if (roomNumber.isNotEmpty) _buildOrderItem('رقم الغرفة', roomNumber),
                      ],
                    ),
                  ),
                ],

                const SizedBox(height: 24),

                // طرق الدفع
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'طريقة الدفع',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: kPrimaryColor,
                        ),
                      ),
                      const SizedBox(height: 16),
                      _buildPaymentOption(
                        'credit',
                        'بطاقة ائتمان',
                        [
                          'assets/payment logos/visa.png',
                          'assets/payment logos/mada.png'
                        ],
                        'Visa, Mada',
                      ),
                      const SizedBox(height: 12),
                      _buildPaymentOption(
                        'applepay',
                        'Apple Pay',
                        ['assets/payment logos/applePay.png'],
                        'ادفع عبر Apple Pay',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                // Billing form
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('معلومات الفاتورة',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 16),
                      _buildTextField(_givenNameController, 'الاسم الأول',
                          'أدخل الاسم الأول',
                          validator: (v) =>
                              v == null || v.isEmpty ? 'مطلوب' : null),
                      const SizedBox(height: 12),
                      _buildTextField(
                          _surnameController, 'اسم العائلة', 'أدخل اسم العائلة',
                          validator: (v) =>
                              v == null || v.isEmpty ? 'مطلوب' : null),
                      const SizedBox(height: 12),
                      _buildTextField(
                        _phoneController,
                        'رقم الجوال',
                        '05xxxxxxxx',
                        validator: (v) {
                          if (v == null || v.isEmpty) return 'مطلوب';
                          // final pattern = RegExp(r'^05\\d{8}\$');
                          // if (!pattern.hasMatch(v))
                          //   return 'أدخل رقم سعودي صحيح';
                          // return null;
                        },
                        keyboardType: TextInputType.phone,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
                // زر الدفع
                SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _startHyperpayPayment,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: _isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : Text(
                            'إتمام الدفع - ${total.toStringAsFixed(2)} ريال',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildOrderItem(String title, String price, {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: isTotal ? 18 : 16,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        Text(
          price,
          style: TextStyle(
            fontSize: isTotal ? 18 : 16,
            fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            color: isTotal ? kPrimaryColor : null,
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentOption(
    String value,
    String title,
    List<String> imageAssets,
    String subtitle,
  ) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: _selectedPaymentMethod == value
              ? kPrimaryColor
              : Colors.grey.shade300,
          width: _selectedPaymentMethod == value ? 2 : 1,
        ),
        borderRadius: BorderRadius.circular(12),
        color: _selectedPaymentMethod == value
            ? kPrimaryColor.withOpacity(0.1)
            : Colors.transparent,
      ),
      child: RadioListTile<String>(
        value: value,
        groupValue: _selectedPaymentMethod,
        onChanged: (newValue) {
          setState(() {
            _selectedPaymentMethod = newValue!;
          });
        },
        title: Row(
          children: [
            if (imageAssets.length == 1)
              Image.asset(
                imageAssets[0],
                width: 36,
                height: 36,
                fit: BoxFit.contain,
              )
            else
              Row(
                children: [
                  Image.asset(
                    imageAssets[0],
                    width: 36,
                    height: 36,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: 8),
                  Image.asset(
                    imageAssets[1],
                    width: 36,
                    height: 36,
                    fit: BoxFit.contain,
                  ),
                ],
              ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  Widget _buildTextField(
      TextEditingController controller, String label, String hint,
      {String? Function(String?)? validator, TextInputType? keyboardType}) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
      validator: validator,
      keyboardType: keyboardType,
    );
  }
}

class HyperPayWebViewScreen extends StatefulWidget {
  final String checkoutId;
  final String paymentUrl; // Added paymentUrl parameter
  const HyperPayWebViewScreen(
      {Key? key, required this.checkoutId, this.paymentUrl = ''})
      : super(key: key);

  @override
  State<HyperPayWebViewScreen> createState() => _HyperPayWebViewScreenState();
}

class _HyperPayWebViewScreenState extends State<HyperPayWebViewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;
  String? _paymentStatus;

  @override
  void initState() {
    super.initState();
    _initializeWebView();
  }

  void _initializeWebView() async {
    _controller = WebViewController();

    // Always load the remote payment page from the new Netlify deployment
    final paymentUrl = widget.paymentUrl.isNotEmpty
        ? widget.paymentUrl
        : 'https://mellifluous-eclair-f3f079.netlify.app/?checkoutId=${widget.checkoutId}';
    _controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() {
              _isLoading = true;
            });
          },
          onPageFinished: (url) {
            setState(() {
              _isLoading = false;
            });
            _checkPaymentResult(url);
          },
          onWebResourceError: (error) {
            print('WebView error: ${error.description}');
          },
        ),
      )
      ..loadRequest(Uri.parse(paymentUrl));
  }

  void _checkPaymentResult(String url) {
    // Listen for navigation to payment-result.html and handle result
    if (url.contains('payment-result.html')) {
      final uri = Uri.parse(url);
      final status = uri.queryParameters['status'];
      setState(() {
        _paymentStatus = status == 'success' ? 'success' : 'fail';
        _isLoading = false;
      });
      // Show result dialog with icon after returning from payment-result.html
      Future.delayed(const Duration(seconds: 2), () {
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  status == 'success' ? Icons.check_circle : Icons.error,
                  color: status == 'success' ? Colors.green : Colors.red,
                  size: 32,
                ),
                const SizedBox(width: 8),
                Text(status == 'success' ? 'تم الدفع بنجاح' : 'فشل الدفع'),
              ],
            ),
            content: Text(
              status == 'success'
                  ? 'تمت عملية الدفع بنجاح. يمكنك الآن عرض رمز QR.'
                  : 'فشلت عملية الدفع. يرجى المحاولة مرة أخرى.',
              textAlign: TextAlign.center,
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  if (status == 'success') {
                    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
                    final provider = Provider.of<AppProvider>(context, listen: false);
                    final hotelInfo = (args != null && args['hotelName'] != null)
                        ? args
                        : (provider.hotelInfo ?? {});
                    Navigator.of(context).pushReplacementNamed(
                      '/qr',
                      arguments: hotelInfo,
                    );
                  }
                },
                child: Text(status == 'success' ? 'عرض ال QR Code' : 'حسناً'),
              ),
            ],
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إتمام الدفع عبر HyperPay'),
        backgroundColor: kPrimaryColor,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          // Always use WebView for payment page
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('جاري المعالجة', style: TextStyle(fontSize: 18)),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildWebPaymentView() {
    return Container(
      width: double.infinity,
      height: double.infinity,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(
            Icons.credit_card,
            size: 80,
            color: Colors.blue,
          ),
          const SizedBox(height: 20),
          const Text(
            'صفحة الدفع الآمنة',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            'جاري تحميل صفحة الدفع...',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () {
              // Simulate payment completion for web
              setState(() {
                _paymentStatus = 'success';
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            child: const Text(
              'محاكاة الدفع الناجح',
              style: TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {
              // Simulate payment failure for web
              setState(() {
                _paymentStatus = 'fail';
              });
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 15),
            ),
            child: const Text(
              'محاكاة فشل الدفع',
              style: TextStyle(color: Colors.white),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            'Checkout ID: ${widget.checkoutId}',
            style: const TextStyle(fontSize: 12, color: Colors.grey),
          ),
        ],
      ),
    );
  }
}
