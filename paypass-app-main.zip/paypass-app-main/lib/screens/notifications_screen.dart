import 'package:flutter/material.dart';
import '../core/services.dart';
import '../core/models.dart' as app_models;

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({Key? key}) : super(key: key);

  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  late Future<List<app_models.Notification>> _notificationsFuture;

  @override
  void initState() {
    super.initState();
    _notificationsFuture = NotificationService.getNotifications();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الإشعارات'),
        ),
        body: FutureBuilder<List<app_models.Notification>>(
          future: _notificationsFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(child: Text('حدث خطأ أثناء تحميل الإشعارات'));
            }
            final notifications = snapshot.data ?? [];
            if (notifications.isEmpty) {
              return Center(child: Text('لا توجد إشعارات حالياً'));
            }
            return ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: notifications.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final notif = notifications[index];
                return ListTile(
                  leading: Icon(Icons.notifications, color: theme.primaryColor),
                  title: Text(notif.title.isNotEmpty ? notif.title : 'إشعار'),
                  subtitle: Text(notif.message),
                  trailing: Text(
                    '${notif.createdAt.year}/${notif.createdAt.month.toString().padLeft(2, '0')}/${notif.createdAt.day.toString().padLeft(2, '0')}',
                    style: theme.textTheme.bodySmall,
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
} 