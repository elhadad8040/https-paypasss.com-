import 'package:flutter/material.dart';

class Hotel {
  final String name;
  final double rating;
  final String address;
  final String phone;
  final bool isVip;
  final String imageAsset;

  Hotel({
    required this.name,
    required this.rating,
    required this.address,
    required this.phone,
    this.isVip = true,
    required this.imageAsset,
  });
}

final List<Hotel> hotels = [
  Hotel(
    name: 'كارلتون الرياض',
    rating: 4.8,
    address: 'طريق الملك فهد، العليا، الرياض',
    phone: '966 5000 443 11',
    imageAsset: 'assets/images/hotels/carleton.jpg',
  ),
  Hotel(
    name: 'فندق سانت ريجيس الرياض',
    rating: 4.9,
    address: 'طريق الملك عبد الله، الرياض',
    phone: '966 11 7777 211',
    imageAsset: 'assets/images/hotels/stRegis.jpg',
  ),
  Hotel(
    name: 'فندق الفتون الرياض',
    rating: 4.7,
    address: 'طريق الملك عبد الله، الرياض',
    phone: '966 11 1234 488',
    imageAsset: 'assets/images/hotels/hilton.jpg',
  ),
];

class HotelSelectionScreen extends StatefulWidget {
  final String? userName;
  final String? userEmail;
  const HotelSelectionScreen({Key? key, this.userName, this.userEmail}) : super(key: key);

  @override
  State<HotelSelectionScreen> createState() => _HotelSelectionScreenState();
}

class _HotelSelectionScreenState extends State<HotelSelectionScreen> {
  Hotel? selectedHotel;
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _emailController;
  late TextEditingController _roomController;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.userName ?? '');
    _emailController = TextEditingController(text: widget.userEmail ?? '');
    _roomController = TextEditingController();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _roomController.dispose();
    super.dispose();
  }

  void _onHotelSelected(Hotel hotel) {
    setState(() {
      selectedHotel = hotel;
    });
  }

  void _onSubmit() {
    if (_formKey.currentState!.validate() && selectedHotel != null) {
      Navigator.of(context).pop({
        'hotelName': selectedHotel!.name,
        'guestName': _nameController.text,
        'guestEmail': _emailController.text,
        'roomNumber': _roomController.text,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('اختر الفندق'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: hotels.length,
                  itemBuilder: (context, index) {
                    final hotel = hotels[index];
                    return GestureDetector(
                      onTap: () => _onHotelSelected(hotel),
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.08),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                          border: Border.all(
                            color: selectedHotel == hotel ? Colors.blue : Colors.grey.shade200,
                            width: 2,
                          ),
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(
                                topRight: Radius.circular(16),
                                bottomRight: Radius.circular(16),
                              ),
                              child: Image.asset(
                                hotel.imageAsset,
                                width: 110,
                                height: 110,
                                fit: BoxFit.cover,
                              ),
                            ),
                            Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text(hotel.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                                        const SizedBox(width: 6),
                                        if (hotel.isVip)
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                            decoration: BoxDecoration(
                                              color: Colors.orange.shade100,
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: const Text('VIP', style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold, fontSize: 12)),
                                          ),
                                      ],
                                    ),
                                    const SizedBox(height: 6),
                                    Row(
                                      children: [
                                        const Icon(Icons.star, color: Colors.amber, size: 18),
                                        const SizedBox(width: 4),
                                        Text(hotel.rating.toString()),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(hotel.address, style: const TextStyle(fontSize: 13, color: Colors.black54)),
                                    const SizedBox(height: 2),
                                    Text('هاتف: ${hotel.phone}', style: const TextStyle(fontSize: 13, color: Colors.black54)),
                                  ],
                                ),
                              ),
                            ),
                            if (selectedHotel == hotel)
                              const Padding(
                                padding: EdgeInsets.only(left: 12.0),
                                child: Icon(Icons.check_circle, color: Colors.blue),
                              ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              if (selectedHotel != null)
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _nameController,
                        decoration: const InputDecoration(labelText: 'الاسم الكامل'),
                        validator: (value) => value == null || value.isEmpty ? 'يرجى إدخال الاسم الكامل' : null,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(labelText: 'البريد الإلكتروني (اختياري)'),
                        keyboardType: TextInputType.emailAddress,
                      ),
                      const SizedBox(height: 8),
                      TextFormField(
                        controller: _roomController,
                        decoration: const InputDecoration(labelText: 'رقم الغرفة (اختياري)'),
                        keyboardType: TextInputType.number,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _onSubmit,
                        child: const Text('تأكيد الفندق'),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
} 