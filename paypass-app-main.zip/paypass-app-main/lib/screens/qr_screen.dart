import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../core/models.dart';
import '../providers/app_provider.dart';

class QRScreen extends StatefulWidget {
  const QRScreen({Key? key}) : super(key: key);

  @override
  State<QRScreen> createState() => _QRScreenState();
}

class _QRScreenState extends State<QRScreen> {
  Map<String, dynamic>? _orderData;
  String _qrData = '';
  Order? _order;

  @override
  void initState() {
    super.initState();
    _generateQRData();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Use provider for order
    final provider = Provider.of<AppProvider>(context, listen: false);
    _order = provider.currentOrder;
    if (_order != null) {
      _orderData = {
        'orderId': _order!.id,
        'packageId': _order!.packageId,
        'carSize': _order!.carSize,
        'totalPrice': _order!.totalPrice,
        'orderDate': _order!.orderDate.toIso8601String(),
        'status': _order!.status,
        'qrCode': _order!.qrCode,
      };

      // إضافة معرف المحطة فقط إذا كان موجودًا
      if (_order!.stationId != null) {
        _orderData!['stationId'] = _order!.stationId;
      }
      _qrData = jsonEncode(_orderData);
    }
  }

  void _generateQRData() {
    final random = Random();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final randomNumber = random.nextInt(999999);
    final orderId = 'ORD-${timestamp.toString().substring(7)}-$randomNumber';

    _orderData = {
      'orderId': orderId,
      'stationName': 'محطة غسيل السيارات الذكية',
      'packagePrice': 25.0 + (random.nextDouble() * 75.0),
      'vehicleType': 'سيارة',
      'packageType': 'غسيل شامل',
      'timestamp': timestamp,
      'paymentMethod': 'بطاقة ائتمان',
      'status': 'مدفوع',
    };

    _qrData = jsonEncode(_orderData);
  }

  // // After successful wash start (QR scan), schedule notification
  // void scheduleFeedbackReminderNotification() {
  //   AwesomeNotifications().createNotification(
  //     content: NotificationContent(
  //       id: DateTime.now().millisecondsSinceEpoch.remainder(100000),
  //       channelKey: 'basic_channel',
  //       title: 'تذكير بالتقييم',
  //       body: 'يرجى تقييم تجربتك مع محطة الغسيل وإضافة صورة لسيارتك بعد الغسيل!',
  //       notificationLayout: NotificationLayout.Default,
  //     ),
  //     schedule: NotificationCalendar.fromDate(
  //       date: DateTime.now().add(const Duration(minutes: 30)),
  //       preciseAlarm: true,
  //     ),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context, listen: false);
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    // Get hotel info from args or provider
    final hotelInfo = (args != null && args['hotelName'] != null)
        ? args
        : (provider.hotelInfo ?? {});
    final hotelName = hotelInfo['hotelName'] ?? '';
    final guestName = hotelInfo['guestName'] ?? '';
    final guestEmail = hotelInfo['guestEmail'] ?? '';
    final roomNumber = hotelInfo['roomNumber'] ?? '';
    final hasHotel = hotelName.isNotEmpty;

    final package = provider.selectedPackage;
    final car = provider.selectedCar;
    final carSizeKey = provider.selectedCarSize;
    final carSize = kCarSizes.firstWhere((e) => e['key'] == carSizeKey, orElse: () => <String, dynamic>{});
    final isVip = (package?.name.contains('VIP') ?? false) || (package?.name.contains('فاخرة') ?? false);
    // Calculate total price (with VAT)
    double price = isVip
        ? (package?.price ?? 0)
        : (package?.price ?? 0) * (carSize['priceFactor'] ?? 1.0);
    double vat = price * 0.15;
    double total = price + vat;
    total = total.ceilToDouble();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF6F8FA),
        appBar: AppBar(
          title: const Text('رمز QR'),
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // QR Code
                Container(
                  width: 250,
                  height: 250,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [kPrimaryColor.withOpacity(0.12), Colors.white],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Center(
                    child: SizedBox(
                      width: 180,
                      height: 180,
                      child: QrImageView(
                        data: _qrData,
                        size: 180,
                        errorStateBuilder: (context, error) => const Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              Icons.error_outline,
                              size: 48,
                              color: Colors.red,
                            ),
                            SizedBox(height: 8),
                            Text(
                              'خطأ في QR Code',
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 32),

                // Instructions
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 18,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Column(
                    children: [
                      Text(
                        'عرض هذا الرمز في المحطة',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: kPrimaryColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 10),
                      Text(
                        'قم بتوجيه الكاميرا نحو هذا الرمز في محطة غسيل السيارات لبدء الغسيل',
                        style: TextStyle(fontSize: 16, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 32),

                // Order Info Card
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.06),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'معلومات الطلب',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: kPrimaryColor,
                        ),
                      ),
                      const SizedBox(height: 14),
                      _infoRow('رقم الطلب', _orderData?['orderId'] ?? ''),
                      _infoRow('الباقة', package?.name ?? ''),
                      if (car != null) _infoRow('السيارة', '${car.name} - ${car.plateNumber}'),
                      _infoRow('حجم السيارة', carSize['name'] ?? _order?.carSize ?? ''),
                      _infoRow('المبلغ المدفوع (شامل الضريبة)', '${total.toStringAsFixed(0)} ريال'),
                      _infoRow('حالة الدفع', _orderData?['status'] ?? 'مدفوع'),
                      if (hasHotel) ...[
                        const Divider(height: 24),
                        const Text('معلومات الفندق', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: kPrimaryColor)),
                        const SizedBox(height: 8),
                        _infoRow('اسم الفندق', hotelName),
                        _infoRow('اسم النزيل', guestName),
                        if (guestEmail.isNotEmpty) _infoRow('البريد الإلكتروني', guestEmail),
                        if (roomNumber.isNotEmpty) _infoRow('رقم الغرفة', roomNumber),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.of(context).pushNamed('/profile');
                  },
                  icon: const Icon(Icons.person),
                  label: const Text('الملف الشخصي'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kPrimaryColor,
                  ),
                ),
                const SizedBox(height: 16),
                if (!isVip)
                  ElevatedButton.icon(
                    onPressed: () {
                      Navigator.of(context).pushNamed('/washing-places');
                    },
                    icon: const Icon(Icons.local_car_wash),
                    label: const Text('عرض المحطات المتاحة'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blueGrey,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String value) => Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      );
}
