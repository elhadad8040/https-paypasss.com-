import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../providers/app_provider.dart';
import '../../screens/main_navigation_screen.dart'; // Added import for MainNavigationScreen
import '../../screens/auth/otp_demo_screen.dart'; // Added import for OtpDemoScreen
import '../../core/api_service.dart'; // Add this import for ApiService
import '../owner/owner_profile_screen.dart'; // Import OwnerProfileScreen
import 'otp_verification_screen.dart'; // Add this import

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _phoneController = TextEditingController();
  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _usePhoneLogin = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final provider = context.read<AppProvider>();
      final success = await provider.login(
        _emailController.text,
        _passwordController.text,
      );

      if (success && mounted) {
        final user = provider.currentUser;
        if (user != null && user.role == 'owner') {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(
              builder: (context) => const OwnerProfileScreen(),
            ),
          );
        } else {
          Navigator.of(context).pushReplacement(
            PageRouteBuilder(
              pageBuilder: (context, animation, secondaryAnimation) =>
                  const MainNavigationScreen(),
              transitionsBuilder:
                  (context, animation, secondaryAnimation, child) {
                return FadeTransition(opacity: animation, child: child);
              },
              transitionDuration: const Duration(milliseconds: 300),
            ),
          );
        }
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('فشل تسجيل الدخول. يرجى التحقق من البيانات'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('حدث خطأ: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _loginWithPhone() async {
    if (_phoneController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال رقم الهاتف'), backgroundColor: Colors.red),
      );
      return;
    }
    // Demo: skip backend check, go directly to OtpDemoScreen
    final result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => OtpDemoScreen(phone: _phoneController.text.trim(), isLogin: true),
      ),
    );
    // Navigation to main app is handled in OtpDemoScreen
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isLargeScreen = size.width > 600;
    final horizontalPadding = isLargeScreen ? size.width * 0.2 : 24.0;
    final verticalSpacing = size.height * 0.02;
    final maxFormWidth = 450.0;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                  horizontal: horizontalPadding, vertical: verticalSpacing),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: maxFormWidth),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo
                      Container(
                        padding: EdgeInsets.all(isLargeScreen ? 32 : 20),
                        child: Image.asset(
                          'assets/images/logo.png',
                          width: 80,
                          height: 80,
                          fit: BoxFit.contain,
                        ),
                      ),
                      SizedBox(height: verticalSpacing),
                      // Subtitle
                      Text(
                        'غسيل السيارات الذكي',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: kPrimaryColor,
                              fontWeight: FontWeight.bold,
                              fontSize: isLargeScreen ? 28 : 22,
                            ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: verticalSpacing * 1.5),
                      // App Name
                      Text(
                        kAppName,
                        style:
                            Theme.of(context).textTheme.displaySmall?.copyWith(
                                  color: Theme.of(context).primaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: isLargeScreen ? 32 : 24,
                                ),
                      ),
                      SizedBox(height: verticalSpacing * 0.5),
                      Text(
                        kAppSlogan,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color:
                                  Theme.of(context).textTheme.bodySmall?.color,
                              fontSize: isLargeScreen ? 18 : 14,
                            ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: verticalSpacing * 2.5),
                      // Login Form
                      Container(
                        padding: EdgeInsets.all(isLargeScreen ? 32 : 24),
                        decoration: BoxDecoration(
                          color: Theme.of(context).cardColor,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              'تسجيل الدخول',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      fontSize: isLargeScreen ? 26 : 20),
                            ),
                            SizedBox(height: verticalSpacing * 1.5),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text('تسجيل الدخول عبر:'),
                                SizedBox(width: 8),
                                ChoiceChip(
                                  label: Text('البريد الإلكتروني'),
                                  selected: !_usePhoneLogin,
                                  onSelected: (v) => setState(() => _usePhoneLogin = false),
                                ),
                                SizedBox(width: 8),
                                ChoiceChip(
                                  label: Text('رقم الهاتف'),
                                  selected: _usePhoneLogin,
                                  onSelected: (v) => setState(() => _usePhoneLogin = true),
                                ),
                              ],
                            ),
                            SizedBox(height: verticalSpacing),
                            if (!_usePhoneLogin) ...[
                              // Email Field
                              TextFormField(
                                controller: _emailController,
                                keyboardType: TextInputType.emailAddress,
                                decoration: InputDecoration(
                                  labelText: 'البريد الإلكتروني',
                                  prefixIcon: Icon(
                                    Icons.email,
                                    color: Theme.of(context).iconTheme.color,
                                  ),
                                ),
                                validator: (value) {
                                  if (!_usePhoneLogin && (value == null || value.isEmpty)) {
                                    return 'يرجى إدخال البريد الإلكتروني';
                                  }
                                  if (!_usePhoneLogin && !value!.contains('@')) {
                                    return 'يرجى إدخال بريد إلكتروني صحيح';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: verticalSpacing),
                              // Password Field
                              TextFormField(
                                controller: _passwordController,
                                obscureText: _obscurePassword,
                                decoration: InputDecoration(
                                  labelText: 'كلمة المرور',
                                  prefixIcon: Icon(
                                    Icons.lock,
                                    color: Theme.of(context).iconTheme.color,
                                  ),
                                  suffixIcon: IconButton(
                                    icon: Icon(
                                      _obscurePassword ? Icons.visibility : Icons.visibility_off,
                                    ),
                                    onPressed: () {
                                      setState(() {
                                        _obscurePassword = !_obscurePassword;
                                      });
                                    },
                                  ),
                                ),
                                validator: (value) {
                                  if (!_usePhoneLogin && (value == null || value.isEmpty)) {
                                    return 'يرجى إدخال كلمة المرور';
                                  }
                                  if (!_usePhoneLogin && value!.length < 6) {
                                    return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: verticalSpacing * 1.5),
                              // Login Button
                              SizedBox(
                                width: double.infinity,
                                height: isLargeScreen ? 56 : 50,
                                child: ElevatedButton(
                                  onPressed: _isLoading ? null : _login,
                                  child: _isLoading
                                      ? SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                              Theme.of(context)
                                                  .colorScheme
                                                  .onPrimary,
                                            ),
                                          ),
                                        )
                                      : Text(
                                          'تسجيل الدخول',
                                          style: Theme.of(context)
                                              .textTheme
                                              .labelLarge
                                              ?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize:
                                                      isLargeScreen ? 22 : 16),
                                        ),
                                ),
                              ),
                            ] else ...[
                              // Phone Field
                              TextFormField(
                                controller: _phoneController,
                                keyboardType: TextInputType.phone,
                                decoration: InputDecoration(
                                  labelText: 'رقم الهاتف',
                                  prefixIcon: Icon(
                                    Icons.phone,
                                    color: Theme.of(context).iconTheme.color,
                                  ),
                                ),
                              ),
                              SizedBox(height: verticalSpacing * 1.5),
                              SizedBox(
                                width: double.infinity,
                                height: isLargeScreen ? 56 : 50,
                                child: ElevatedButton(
                                  onPressed: _isLoading ? null : _loginWithPhone,
                                  child: _isLoading
                                      ? SizedBox(
                                          width: 20,
                                          height: 20,
                                          child: CircularProgressIndicator(
                                            strokeWidth: 2,
                                            valueColor:
                                                AlwaysStoppedAnimation<Color>(
                                              Theme.of(context)
                                                  .colorScheme
                                                  .onPrimary,
                                            ),
                                          ),
                                        )
                                      : Text(
                                          'إرسال رمز التحقق',
                                          style: Theme.of(context)
                                              .textTheme
                                              .labelLarge
                                              ?.copyWith(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize:
                                                      isLargeScreen ? 22 : 16),
                                        ),
                                ),
                              ),
                            ],
                            SizedBox(height: verticalSpacing),
                            // Register Link
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  'ليس لديك حساب؟',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                          fontSize: isLargeScreen ? 18 : 14),
                                ),
                                TextButton(
                                  onPressed: () {
                                    // Navigate to register screen
                                    Navigator.of(context)
                                        .pushNamed('/register');
                                  },
                                  child: Text(
                                    'إنشاء حساب جديد',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodyMedium
                                        ?.copyWith(
                                          color: Theme.of(context).primaryColor,
                                          fontWeight: FontWeight.bold,
                                          fontSize: isLargeScreen ? 18 : 14,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
