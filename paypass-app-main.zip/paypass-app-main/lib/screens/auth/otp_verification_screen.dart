import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import '../../core/api_service.dart';
import '../../providers/app_provider.dart';
import '../main_navigation_screen.dart';

class OtpVerificationScreen extends StatefulWidget {
  final String phone;
  final bool isLogin;
  final Map<String, dynamic>? signupData;
  const OtpVerificationScreen({Key? key, required this.phone, required this.isLogin, this.signupData}) : super(key: key);

  @override
  State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}

class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final _otpController = TextEditingController();
  String? _verificationId;
  bool _isLoading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _startPhoneVerification();
  }

  Future<void> _startPhoneVerification() async {
    setState(() { _isLoading = true; });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: widget.phone,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (PhoneAuthCredential credential) async {
        // Auto-retrieval or instant verification
        await _signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        setState(() {
          _isLoading = false;
          _error = e.message;
        });
      },
      codeSent: (String verificationId, int? resendToken) {
        setState(() {
          _verificationId = verificationId;
          _isLoading = false;
        });
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        setState(() {
          _verificationId = verificationId;
        });
      },
    );
  }

  Future<void> _verifyOtp() async {
    if (_otpController.text.length < 6 || _verificationId == null) {
      setState(() { _error = 'يرجى إدخال رمز صحيح'; });
      return;
    }
    setState(() { _isLoading = true; _error = null; });
    try {
      final verificationId = _verificationId;
      if (verificationId == null) {
        setState(() { _isLoading = false; _error = 'حدث خطأ في التحقق من الرمز. حاول مرة أخرى.'; });
        return;
      }
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: _otpController.text.trim(),
      );
      await _signInWithCredential(credential);
    } catch (e) {
      setState(() { _isLoading = false; _error = 'رمز التحقق غير صحيح'; });
    }
  }

  Future<void> _signInWithCredential(PhoneAuthCredential credential) async {
    try {
      final userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
      final firebaseUser = userCredential.user;
      if (firebaseUser == null) throw Exception('تعذر التحقق من المستخدم');
      final idToken = await firebaseUser.getIdToken();
      final appProvider = Provider.of<AppProvider>(context, listen: false);
      Map<String, dynamic> backendResponse;
      if (widget.isLogin) {
        backendResponse = await ApiService.phoneLoginVerify(widget.phone, idToken!);
      } else {
        final data = widget.signupData ?? {};
        backendResponse = await ApiService.phoneSignupVerify(data, idToken!);
      }
      if (backendResponse['token'] != null && backendResponse['user'] != null) {
        appProvider.setCurrentUser(backendResponse['user']);
        if (mounted) {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
            (route) => false,
          );
        }
      } else {
        setState(() { _error = 'فشل التحقق من الخادم'; });
      }
    } catch (e) {
      setState(() { _error = 'فشل التحقق: $e'; });
    } finally {
      setState(() { _isLoading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('التحقق من رقم الهاتف')),
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('أدخل رمز التحقق المرسل إلى رقم هاتفك'),
              const SizedBox(height: 16),
              TextField(
                controller: _otpController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: InputDecoration(
                  labelText: 'رمز التحقق',
                  border: OutlineInputBorder(),
                  errorText: _error,
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _verifyOtp,
                  child: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('تأكيد'),
                ),
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: _isLoading ? null : _startPhoneVerification,
                child: const Text('إعادة إرسال الرمز'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
