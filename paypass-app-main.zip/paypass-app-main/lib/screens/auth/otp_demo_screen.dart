import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../main_navigation_screen.dart';

class OtpDemoScreen extends StatefulWidget {
  final String phone;
  final bool isLogin;
  const OtpDemoScreen({Key? key, required this.phone, required this.isLogin})
      : super(key: key);

  @override
  State<OtpDemoScreen> createState() => _OtpDemoScreenState();
}

class _OtpDemoScreenState extends State<OtpDemoScreen> {
  final _otpController = TextEditingController();
  bool _isLoading = false;
  String? _error;

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _verifyOtp() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    if (_otpController.text.trim() == '123456') {
      // Demo: log in with fixed credentials
      final provider = Provider.of<AppProvider>(context, listen: false);
      final success =
          await provider.login('ahmed@example.com', 'yourPassword123');
      setState(() {
        _isLoading = false;
      });
      if (success && mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const MainNavigationScreen()),
          (route) => false,
        );
      } else {
        setState(() {
          _error = 'فشل تسجيل الدخول التجريبي';
        });
      }
    } else {
      setState(() {
        _isLoading = false;
        _error = 'رمز التحقق غير صحيح';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التحقق من OTP (تجريبي)')),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // const Text('أدخل رمز التحقق التجريبي: 123456'),
            const SizedBox(height: 16),
            TextFormField(
              controller: _otpController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'رمز التحقق'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, style: const TextStyle(color: Colors.red)),
            ],
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _verifyOtp,
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Text('تحقق'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
