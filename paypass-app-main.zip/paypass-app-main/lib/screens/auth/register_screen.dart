import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/utils.dart';
import '../../core/models.dart';
import '../../core/services.dart';
import '../../providers/app_provider.dart';
import '../home_screen.dart';
import 'otp_demo_screen.dart';
import '../../core/api_service.dart'; // Add this import for ApiService
import 'otp_verification_screen.dart'; // Add this import

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _referralCodeController = TextEditingController();
  final _phoneOnlyController = TextEditingController();
  final _namePhoneController = TextEditingController();
  bool _usePhoneRegister = false;

  bool _isLoading = false;
  bool _obscurePassword = true;
  bool _obscureConfirmPassword = true;

  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    _referralCodeController.dispose();
    _phoneOnlyController.dispose();
    _namePhoneController.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final user = await UserService.register(
        _nameController.text.trim(),
        _emailController.text.trim(),
        _phoneController.text.trim(),
        _passwordController.text,
        referralCode: _referralCodeController.text.trim().isEmpty
            ? null
            : _referralCodeController.text.trim(),
      );

      if (mounted) {
        // Update the app provider with the new user
        final appProvider = Provider.of<AppProvider>(context, listen: false);
        appProvider.setCurrentUser(user);

        AppUtils.showSuccessSnackBar(context, 'تم التسجيل بنجاح');
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => const HomeScreen()),
        );
      }
    } catch (e) {
      if (mounted) {
        String errorMessage = 'حدث خطأ أثناء التسجيل';
        if (e.toString().contains('Email already in use')) {
          errorMessage = 'البريد الإلكتروني مستخدم بالفعل';
        } else if (e.toString().contains('Phone number already in use')) {
          errorMessage = 'رقم الهاتف مستخدم بالفعل';
        }

        AppUtils.showErrorSnackBar(context, errorMessage);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _registerWithPhone() async {
    if (_namePhoneController.text.isEmpty || _phoneOnlyController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يرجى إدخال الاسم ورقم الهاتف'), backgroundColor: Colors.red),
      );
      return;
    }
    // Demo: skip backend check, go directly to OtpDemoScreen
    final result = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => OtpDemoScreen(phone: _phoneOnlyController.text.trim(), isLogin: false),
      ),
    );
    // Navigation to main app is handled in OtpDemoScreen
  }

  String? _validateName(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'يرجى إدخال الاسم';
    }
    if (value.trim().length < 3) {
      return 'يجب أن يكون الاسم 3 أحرف على الأقل';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'يرجى إدخال البريد الإلكتروني';
    }
    
    // Simple email validation regex
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value.trim())) {
      return 'يرجى إدخال بريد إلكتروني صحيح';
    }
    
    return null;
  }

  String? _validatePhone(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'يرجى إدخال رقم الهاتف';
    }
    if (!AppUtils.isValidPhoneNumber(value.trim())) {
      return 'يرجى إدخال رقم هاتف صحيح (05xxxxxxxx)';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'يرجى إدخال كلمة المرور';
    }
    if (value.length < 6) {
      return 'يجب أن تكون كلمة المرور 6 أحرف على الأقل';
    }
    return null;
  }

  String? _validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'يرجى تأكيد كلمة المرور';
    }
    if (value != _passwordController.text) {
      return 'كلمة المرور غير متطابقة';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isLargeScreen = size.width > 600;
    final horizontalPadding =
        isLargeScreen ? size.width * 0.2 : kDefaultPadding;
    final verticalSpacing = size.height * 0.02;
    final maxFormWidth = 500.0;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text(kRegister,
              style: Theme.of(context).appBarTheme.titleTextStyle),
          centerTitle: true,
          elevation: 0,
        ),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                  horizontal: horizontalPadding, vertical: verticalSpacing),
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: maxFormWidth),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('التسجيل عبر:'),
                        SizedBox(width: 8),
                        ChoiceChip(
                          label: Text('البريد الإلكتروني'),
                          selected: !_usePhoneRegister,
                          onSelected: (v) => setState(() => _usePhoneRegister = false),
                        ),
                        SizedBox(width: 8),
                        ChoiceChip(
                          label: Text('رقم الهاتف'),
                          selected: _usePhoneRegister,
                          onSelected: (v) => setState(() => _usePhoneRegister = true),
                        ),
                      ],
                    ),
                    SizedBox(height: verticalSpacing),
                    if (!_usePhoneRegister) ...[
                      // شعار التسجيل
                      Container(
                        padding: EdgeInsets.all(isLargeScreen ? 32 : 20),
                        child: Image.asset(
                          'assets/images/logo.png',
                          width: 80,
                          height: 80,
                          fit: BoxFit.contain,
                        ),
                      ),
                      SizedBox(height: verticalSpacing),
                      // Subtitle
                      Text(
                        'غسيل السيارات الذكي',
                        style: Theme.of(context).textTheme.titleLarge?.copyWith(
                              color: kPrimaryColor,
                              fontWeight: FontWeight.bold,
                              fontSize: isLargeScreen ? 28 : 22,
                            ),
                        textAlign: TextAlign.center,
                      ),

                      SizedBox(height: verticalSpacing * 1.5),

                      Text(
                        'إنشاء حساب جديد',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(
                              fontWeight: FontWeight.bold,
                              fontSize: isLargeScreen ? 26 : 20,
                            ),
                        textAlign: TextAlign.center,
                      ),

                      SizedBox(height: verticalSpacing * 0.5),

                      Text(
                        'أدخل بياناتك لإنشاء حساب جديد',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color:
                                  Theme.of(context).textTheme.bodySmall?.color,
                              fontSize: isLargeScreen ? 18 : 14,
                            ),
                        textAlign: TextAlign.center,
                      ),

                      SizedBox(height: verticalSpacing * 2),

                      // حقل الاسم
                      TextFormField(
                        controller: _nameController,
                        keyboardType: TextInputType.name,
                        decoration: InputDecoration(
                          labelText: 'الاسم الكامل',
                          hintText: 'أدخل اسمك الكامل',
                          prefixIcon: Icon(Icons.person,
                              color: Theme.of(context).iconTheme.color),
                        ),
                        validator: _validateName,
                      ),

                      SizedBox(height: verticalSpacing),

                      // حقل البريد الإلكتروني
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: InputDecoration(
                          labelText: 'البريد الإلكتروني',
                          hintText: 'example@email.com',
                          prefixIcon: Icon(Icons.email,
                              color: Theme.of(context).iconTheme.color),
                        ),
                        validator: _validateEmail,
                      ),

                      SizedBox(height: verticalSpacing),

                      // حقل رقم الهاتف
                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          labelText: 'رقم الهاتف',
                          hintText: '05xxxxxxxx',
                          prefixIcon: Icon(Icons.phone,
                              color: Theme.of(context).iconTheme.color),
                        ),
                        validator: _validatePhone,
                      ),

                      SizedBox(height: verticalSpacing),

                      // حقل كلمة المرور
                      TextFormField(
                        controller: _passwordController,
                        obscureText: _obscurePassword,
                        decoration: InputDecoration(
                          labelText: 'كلمة المرور',
                          hintText: 'أدخل كلمة المرور',
                          prefixIcon: Icon(Icons.lock,
                              color: Theme.of(context).iconTheme.color),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscurePassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Theme.of(context).iconTheme.color,
                            ),
                            onPressed: () {
                              setState(() {
                                _obscurePassword = !_obscurePassword;
                              });
                            },
                          ),
                        ),
                        validator: _validatePassword,
                      ),

                      SizedBox(height: verticalSpacing),

                      // حقل تأكيد كلمة المرور
                      TextFormField(
                        controller: _confirmPasswordController,
                        obscureText: _obscureConfirmPassword,
                        decoration: InputDecoration(
                          labelText: 'تأكيد كلمة المرور',
                          hintText: 'أعد إدخال كلمة المرور',
                          prefixIcon: Icon(Icons.lock_outline,
                              color: Theme.of(context).iconTheme.color),
                          suffixIcon: IconButton(
                            icon: Icon(
                              _obscureConfirmPassword
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                              color: Theme.of(context).iconTheme.color,
                            ),
                            onPressed: () {
                              setState(() {
                                _obscureConfirmPassword =
                                    !_obscureConfirmPassword;
                              });
                            },
                          ),
                        ),
                        validator: _validateConfirmPassword,
                      ),

                      SizedBox(height: verticalSpacing),
                      // Referral Code Field
                      TextFormField(
                        controller: _referralCodeController,
                        decoration: InputDecoration(
                          labelText: 'كود الإحالة (اختياري)',
                          hintText: 'أدخل كود الإحالة إذا كان لديك',
                          prefixIcon: Icon(Icons.card_giftcard,
                              color: Theme.of(context).iconTheme.color),
                        ),
                      ),

                      SizedBox(height: verticalSpacing * 2),

                      // زر التسجيل
                      SizedBox(
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _register,
                          child: _isLoading
                              ? CircularProgressIndicator(
                                  color:
                                      Theme.of(context).colorScheme.onPrimary)
                              : Text(
                                  kRegister,
                                  style: Theme.of(context)
                                      .textTheme
                                      .labelLarge
                                      ?.copyWith(
                                          fontWeight: FontWeight.bold,
                                          fontSize: isLargeScreen ? 22 : 16),
                                ),
                        ),
                      ),

                      SizedBox(height: verticalSpacing),

                      // رابط تسجيل الدخول
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'لديك حساب بالفعل؟ ',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(fontSize: isLargeScreen ? 18 : 14),
                          ),
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text(
                              kLogin,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: Theme.of(context).primaryColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: isLargeScreen ? 18 : 14,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ] else ...[
                      // Phone registration form
                      SizedBox(height: verticalSpacing * 2),
                      TextFormField(
                        controller: _namePhoneController,
                        keyboardType: TextInputType.name,
                        decoration: InputDecoration(
                          labelText: 'الاسم الكامل',
                          hintText: 'أدخل اسمك الكامل',
                          prefixIcon: Icon(Icons.person, color: Theme.of(context).iconTheme.color),
                        ),
                      ),
                      SizedBox(height: verticalSpacing),
                      TextFormField(
                        controller: _phoneOnlyController,
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          labelText: 'رقم الهاتف',
                          hintText: '05xxxxxxxx',
                          prefixIcon: Icon(Icons.phone, color: Theme.of(context).iconTheme.color),
                        ),
                      ),
                      SizedBox(height: verticalSpacing * 2),
                      SizedBox(
                        height: 56,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _registerWithPhone,
                          child: _isLoading
                              ? CircularProgressIndicator(color: Theme.of(context).colorScheme.onPrimary)
                              : Text('إرسال رمز التحقق', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.bold, fontSize: isLargeScreen ? 22 : 16)),
                        ),
                      ),
                      SizedBox(height: verticalSpacing),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('لديك حساب بالفعل؟ ', style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: isLargeScreen ? 18 : 14)),
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text(kLogin, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).primaryColor, fontWeight: FontWeight.bold, fontSize: isLargeScreen ? 18 : 14)),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
