import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../providers/app_provider.dart';
import '../auth/login_screen.dart';
import '../hotel_selection_screen.dart';

class PackageDetailsScreen extends StatefulWidget {
  final Package package;
  final String? selectedCarId;

  const PackageDetailsScreen({
    Key? key,
    required this.package,
    this.selectedCarId,
  }) : super(key: key);

  @override
  State<PackageDetailsScreen> createState() => _PackageDetailsScreenState();
}

class _PackageDetailsScreenState extends State<PackageDetailsScreen> {
  String? selectedCarSizeKey;

  @override
  Widget build(BuildContext context) {
    final package = widget.package;
    final theme = Theme.of(context);

    // إخفاء شريط الحالة
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);

    // جلب السيارة المختارة من provider
    final appProvider = Provider.of<AppProvider>(context, listen: false);
    Car? selectedCar;
    for (final car in appProvider.cars) {
      if (car.id == widget.selectedCarId) {
        selectedCar = car;
        break;
      }
    }
    selectedCar ??= appProvider.selectedCar;

    double finalPrice = package.price;
    String carSize = '';
    if (selectedCar != null) {
      finalPrice = package.price * selectedCar.priceMultiplier;
      carSize = selectedCar.size;
    }

    // حساب السعر المخفض إذا كان هناك خصم
    final originalPrice = package.originalPrice != null && selectedCar != null
        ? package.originalPrice! * selectedCar.priceMultiplier
        : package.originalPrice ?? package.price;
    final hasDiscount =
        package.originalPrice != null && package.originalPrice! > package.price;
    final savings = hasDiscount && selectedCar != null
        ? originalPrice - finalPrice
        : (hasDiscount ? (originalPrice - package.price) : 0.0);

    // Car size selection state
    bool isVip = package.name.contains('VIP') || package.name.contains('فاخرة');
    double getCarSizePriceFactor(String? key) {
      if (key == null) return 1.0;
      final carSize = kCarSizes.firstWhere((e) => e['key'] == key, orElse: () => <String, dynamic>{});
      return carSize.isNotEmpty ? (carSize['priceFactor'] as double) : 1.0;
    }
    double displayedPrice = isVip
      ? package.price
      : package.price * getCarSizePriceFactor(selectedCarSizeKey);

    // التأكد من أن البيانات صحيحة
    if (package.name.isEmpty) {
      return Scaffold(
        body: Center(
          child: Text(
            'بيانات الباقة غير صحيحة',
            style: theme.textTheme.bodyLarge,
          ),
        ),
      );
    }

    final Color packageColor = _getPackageColor(package.name);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text(package.name, style: theme.appBarTheme.titleTextStyle),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // بطاقة الباقة
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: _getPackageColor(package.name).withOpacity(0.15),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                  border: Border.all(color: _getPackageColor(package.name), width: 2),
                ),
                child: Column(
                  children: [
                    // شعار الباقة
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: _getPackageColor(package.name).withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        package.isPopular ? Icons.star : Icons.local_car_wash,
                        size: 48,
                        color: _getPackageColor(package.name),
                      ),
                    ),

                    const SizedBox(height: 20),

                    Text(
                      package.name,
                      style: theme.textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      package.description,
                      style: theme.textTheme.bodyLarge?.copyWith(
                        color: theme.textTheme.bodySmall?.color,
                      ),
                    ),

                    const SizedBox(height: 24),

                    // السعر
                    // Car size dropdown
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: DropdownButtonFormField<String>(
                        value: selectedCarSizeKey,
                        decoration: InputDecoration(
                          labelText: 'اختر حجم السيارة',
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: packageColor)),
                          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: packageColor)),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: packageColor, width: 2)),
                        ),
                        items: kCarSizes.map((carSize) {
                          return DropdownMenuItem<String>(
                            value: carSize['key'],
                            child: Row(
                              children: [
                                Icon(carSize['icon'] as IconData, color: carSize['color'] as Color, size: 24),
                                const SizedBox(width: 8),
                                Text(carSize['name'], style: TextStyle(color: carSize['color'] as Color)),
                              ],
                            ),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            selectedCarSizeKey = value;
                          });
                        },
                      ),
                    ),
                    if (selectedCar != null) ...[
                      // ORIGINAL PRICE
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (hasDiscount)
                            Text(
                              '${originalPrice.toStringAsFixed(0)} ريال',
                              style: theme.textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Colors.grey,
                                decoration: TextDecoration.lineThrough,
                              ),
                            ),
                          if (hasDiscount) const SizedBox(width: 8),
                          Text(
                            '${displayedPrice.toStringAsFixed(0)} ريال',
                            style: theme.textTheme.displayLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: _getPackageColor(package.name),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            hasDiscount ? 'السعر بعد الخصم' : 'السعر الأساسي',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: _getPackageColor(package.name),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'السعر النهائي يعتمد على حجم السيارة',
                        style: theme.textTheme.bodyMedium,
                      ),
                    ] else ...[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${displayedPrice.toStringAsFixed(0)} ريال',
                            style: theme.textTheme.displayLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: _getPackageColor(package.name),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'السعر الأساسي',
                            style: theme.textTheme.bodyMedium?.copyWith(
                              color: _getPackageColor(package.name),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'السعر النهائي يعتمد على حجم السيارة',
                        style: theme.textTheme.bodyMedium,
                      ),
                    ],

                    if (hasDiscount && selectedCar != null) ...[
                      const SizedBox(height: 8),
                      Text(
                        'بدلاً من ${originalPrice.toStringAsFixed(0)} ريال',
                        style: theme.textTheme.bodyLarge?.copyWith(
                          decoration: TextDecoration.lineThrough,
                          color: theme.textTheme.bodySmall?.color,
                        ),
                      ),
                    ],
                    const SizedBox(height: 8),
                    if (selectedCar != null)
                      Text(
                        selectedCarSizeKey != null ? 'حجم السيارة: ' + (kCarSizes.firstWhere((e) => e['key'] == selectedCarSizeKey, orElse: () => <String, dynamic>{})['name'] ?? '') : '',
                        style: theme.textTheme.bodyMedium,
                      ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // تفاصيل الباقة
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'تفاصيل الباقة',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // عدد الغسلات
                    if (package.washes > 0)
                      _buildDetail(
                        context,
                        'عدد الغسلات',
                        '${package.washes} غسلة',
                        Icons.local_car_wash,
                        _getPackageColor(package.name),
                      ),

                    // مدة الصلاحية
                    if (package.validityDays > 0)
                      _buildDetail(
                        context,
                        'مدة الصلاحية',
                        '${package.validityDays} يوم',
                        Icons.schedule,
                        _getPackageColor(package.name),
                      ),

                    // المميزات
                    if (package.features.isNotEmpty) ...[
                      const SizedBox(height: 16),
                      Text(
                        'المميزات',
                        style: theme.textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      ...package.features.map(
                        (feature) => _buildFeature(context, feature),
                      ),
                    ],
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // الشروط والأحكام
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'الشروط والأحكام',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildTerm(
                      context,
                      'صالح لمدة ${package.validityDays} يوم من تاريخ الشراء',
                      _getPackageColor(package.name),
                    ),
                    _buildTerm(
                      context,
                      'يمكن استخدامه في جميع المحطات الشريكة',
                      _getPackageColor(package.name),
                    ),
                    _buildTerm(context, 'غير قابل للاسترداد أو التحويل', _getPackageColor(package.name)),
                    _buildTerm(context, 'يجب إظهار رمز QR عند كل استخدام', _getPackageColor(package.name)),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // زر اختيار الباقة
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  onPressed: selectedCarSizeKey != null ? () async {
                    final appProvider = Provider.of<AppProvider>(
                      context,
                      listen: false,
                    );
                    appProvider.selectPackage(package);
                    appProvider.selectCarSize(selectedCarSizeKey!);
                    bool isVip = package.name.contains('VIP') || package.name.contains('فاخرة');
                    if (isVip) {
                      final hotelInfo = await Navigator.of(context).push<Map<String, String>>(
                        MaterialPageRoute(
                          builder: (context) => HotelSelectionScreen(
                            userName: appProvider.currentUser?.name,
                            userEmail: appProvider.currentUser?.email,
                          ),
                        ),
                      );
                      if (hotelInfo != null) {
                        appProvider.setHotelInfo(hotelInfo);
                        Navigator.of(context).pushNamed(
                          '/checkout',
                          arguments: hotelInfo,
                        );
                      }
                    } else {
                      appProvider.clearHotelInfo();
                      Navigator.of(context).pushNamed('/checkout');
                    }
                  } : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _getPackageColor(package.name),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    'شراء هذه الباقة',
                    style: theme.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetail(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: theme.textTheme.bodySmall),
                Text(
                  value,
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFeature(BuildContext context, String title) {
    final theme = Theme.of(context);
    final color = _getPackageColor(widget.package.name);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              Icons.check_circle,
              color: color,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: theme.textTheme.bodyLarge)),
        ],
      ),
    );
  }

  Widget _buildTerm(BuildContext context, String text, Color color) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, color: color, size: 16),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: theme.textTheme.bodySmall)),
        ],
      ),
    );
  }
}

Color _getPackageColor(String name) {
  if (name.contains('فاخرة') || name.contains('VIP')) return const Color(0xFF8920BB);
  if (name.contains('الشاملة')) return const Color(0xFFC2410C);
  if (name.contains('المتقدمة')) return const Color(0xFF16A34A);
  if (name.contains('الأساسية')) return const Color(0xFF0D9488);
  return const Color(0xFF22c55e);
}
