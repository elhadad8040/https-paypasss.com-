import 'package:flutter/material.dart';

import '../../core/constants.dart';
import '../../core/models.dart';
import '../../core/services.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../../main.dart';
import '../../screens/hotel_selection_screen.dart';

class PackageSelectionScreen extends StatefulWidget {
  const PackageSelectionScreen({Key? key}) : super(key: key);

  @override
  State<PackageSelectionScreen> createState() => _PackageSelectionScreenState();
}

class _PackageSelectionScreenState extends State<PackageSelectionScreen> {
  List<Package> _packages = [];
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _loadPackages();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // تعليق أو إزالة السطر التالي لمنع مسح الاختيارات السابقة
    // final provider = Provider.of<AppProvider>(context, listen: false);
    // provider.clearSelections();
  }

  Future<void> _loadPackages() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      final packages = await PackageService.getPackages();
      setState(() {
        _packages = packages;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'حدث خطأ في تحميل البيانات';
      });
      print('Error loading packages: $e');
    }
  }

  void _selectPackage(Package package) {
    final provider = Provider.of<AppProvider>(context, listen: false);
    provider.selectPackage(package);
    // Navigate to package details screen first
    Navigator.of(context).pushNamed(
      '/package-details',
      arguments: {'package': package},
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text('اختر الباقة', style: theme.appBarTheme.titleTextStyle),
          actions: [
            IconButton(
              icon: Icon(Icons.refresh, color: theme.iconTheme.color),
              onPressed: _loadPackages,
            ),
          ],
        ),
        body: _isLoading
            ? Center(
                child: CircularProgressIndicator(color: theme.primaryColor),
              )
            : _errorMessage != null
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          _errorMessage!,
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: theme.colorScheme.error,
                          ),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _loadPackages,
                          child: Text(
                            'إعادة المحاولة',
                            style: theme.textTheme.labelLarge,
                          ),
                        ),
                      ],
                    ),
                  )
                : _packages.isEmpty
                    ? Center(
                        child: Text(
                          'لا توجد باقات متاحة',
                          style: theme.textTheme.bodyLarge,
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _packages.length,
                        itemBuilder: (context, index) {
                          final package = _packages[index];
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: _buildPackageCard(context, package),
                          );
                        },
                      ),
      ),
    );
  }

  Widget _buildPackageCard(BuildContext context, Package package) {
    final theme = Theme.of(context);
    final originalPrice = package.originalPrice ?? package.price;
    final hasDiscount =
        package.originalPrice != null && package.originalPrice! > package.price;
    final savings = hasDiscount ? originalPrice - package.price : 0.0;

    // Car size selection state for this card
    String? selectedCarSizeKey;
    double getCarSizePriceFactor(String? key) {
      if (key == null) return 1.0;
      final carSize = kCarSizes.firstWhere((e) => e['key'] == key,
          orElse: () => <String, dynamic>{});
      return carSize.isNotEmpty ? (carSize['priceFactor'] as double) : 1.0;
    }

    bool isVip = package.name.contains('VIP') || package.name.contains('فاخرة');
    double displayedPrice = isVip
        ? package.price
        : package.price * getCarSizePriceFactor(selectedCarSizeKey);

    return StatefulBuilder(
      builder: (context, setState) {
        return GestureDetector(
          onTap: () {
            Navigator.of(context).pushNamed(
              '/package-details',
              arguments: {'package': package},
            );
          },
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border:
                  Border.all(color: _getPackageColor(package.name), width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.1),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                if (package.isPopular)
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(
                      color: theme.primaryColor,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(14),
                      ),
                    ),
                    child: Text(
                      'الأكثر شعبية',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.onPrimary,
                        fontWeight: FontWeight.bold,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  package.name,
                                  style:
                                      theme.textTheme.headlineSmall?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: _getPackageColor(package.name),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  package.description,
                                  style: theme.textTheme.bodySmall,
                                ),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    '${displayedPrice.toStringAsFixed(0)} ريال',
                                    style: theme.textTheme.headlineMedium
                                        ?.copyWith(
                                      fontWeight: FontWeight.bold,
                                      color: _getPackageColor(package.name),
                                    ),
                                  ),
                                  if (hasDiscount) ...[
                                    const SizedBox(width: 6),
                                    Text(
                                      '${originalPrice.toStringAsFixed(0)} ريال',
                                      style:
                                          theme.textTheme.bodyMedium?.copyWith(
                                        decoration: TextDecoration.lineThrough,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      // Car size dropdown
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: DropdownButtonFormField<String>(
                          value: selectedCarSizeKey,
                          decoration: InputDecoration(
                            labelText: 'اختر حجم السيارة',
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8)),
                          ),
                          items: kCarSizes.map((carSize) {
                            return DropdownMenuItem<String>(
                              value: carSize['key'],
                              child: Row(
                                children: [
                                  Icon(carSize['icon'] as IconData,
                                      color: carSize['color'] as Color,
                                      size: 24),
                                  const SizedBox(width: 8),
                                  Text(carSize['name'],
                                      style: TextStyle(
                                          color: carSize['color'] as Color)),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              selectedCarSizeKey = value;
                              if (!isVip) {
                                displayedPrice = package.price *
                                    getCarSizePriceFactor(value);
                              }
                            });
                          },
                        ),
                      ),
                      if (hasDiscount)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: theme.primaryColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(
                            'وفر ${savings.toStringAsFixed(0)} ريال',
                            style: theme.textTheme.labelMedium?.copyWith(
                              color: _getPackageColor(package.name),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      if (hasDiscount) const SizedBox(height: 16),
                      if (package.washes > 0) ...[
                        Row(
                          children: [
                            Icon(
                              Icons.local_car_wash,
                              color: _getPackageColor(package.name),
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'عدد الغسلات: ${package.washes}',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                      ],
                      if (package.validityDays > 0) ...[
                        Row(
                          children: [
                            Icon(Icons.schedule,
                                color: _getPackageColor(package.name),
                                size: 20),
                            const SizedBox(width: 8),
                            Text(
                              'صالحة لمدة: ${package.validityDays} يوم',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                      ],
                      Text(
                        'المميزات:',
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ...package.features.map(
                        (feature) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Row(
                            children: [
                              Icon(
                                Icons.check_circle,
                                color: _getPackageColor(package.name),
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  feature,
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: selectedCarSizeKey == null
                              ? null
                              : () async {
                                  showDialog(
                                    context: context,
                                    barrierDismissible: false,
                                    builder: (_) => const AnimatedAppLoading(),
                                  );
                                  await Future.delayed(const Duration(seconds: 2));
                                  if (Navigator.of(context).canPop())
                                    Navigator.of(context).pop();
                                  final provider = Provider.of<AppProvider>(context, listen: false);
                                  provider.selectPackage(package);
                                  provider.selectCarSize(selectedCarSizeKey!);
                                  bool isVip = package.name.contains('VIP') || package.name.contains('فاخرة');
                                  if (isVip) {
                                    // Navigate to hotel selection first
                                    final hotelInfo = await Navigator.of(context).push<Map<String, String>>(
                                      MaterialPageRoute(
                                        builder: (context) => HotelSelectionScreen(
                                          userName: provider.currentUser?.name,
                                          userEmail: provider.currentUser?.email,
                                        ),
                                      ),
                                    );
                                    if (hotelInfo != null) {
                                      provider.setHotelInfo(hotelInfo);
                                      Navigator.of(context).pushNamed(
                                        '/checkout',
                                        arguments: hotelInfo,
                                      );
                                    }
                                  } else {
                                    provider.clearHotelInfo();
                                    Navigator.of(context).pushNamed('/checkout');
                                  }
                                },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: _getPackageColor(package.name),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          child: Text(
                            'اختيار هذه الباقة',
                            style: theme.textTheme.labelLarge?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

Color _getPackageColor(String name) {
  if (name.contains('فاخرة') || name.contains('VIP'))
    return const Color(0xFF8920BB);
  if (name.contains('الشاملة')) return const Color(0xFFC2410C);
  if (name.contains('المتقدمة')) return const Color(0xFF16A34A);
  if (name.contains('الأساسية')) return const Color(0xFF0D9488);
  return const Color(0xFF22c55e);
}
