import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import '../owner_qr_scan_screen.dart';
import '../../core/api_service.dart';

class OwnerProfileScreen extends StatefulWidget {
  const OwnerProfileScreen({Key? key}) : super(key: key);

  @override
  State<OwnerProfileScreen> createState() => _OwnerProfileScreenState();
}

class _OwnerProfileScreenState extends State<OwnerProfileScreen> {
  bool _isLoading = true;
  String? _error;
  List<Map<String, dynamic>> _scans = [];

  @override
  void initState() {
    super.initState();
    _fetchScans();
  }

  Future<void> _fetchScans() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final scans = await ApiService.getOwnerScans();
      setState(() {
        _scans = scans;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _error = 'حدث خطأ أثناء تحميل الإحصائيات';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final user = provider.currentUser;
    final theme = Theme.of(context);

    // Calculate stats
    final totalScans = _scans.length;
    final uniqueUsers = _scans.map((s) => s['user']?['_id'] ?? '').toSet().length;
    final uniquePackages = _scans.map((s) => s['package']?['_id'] ?? '').toSet().length;
    final lastStation = _scans.isNotEmpty ? (_scans.last['washingPlace']?['name'] ?? '') : '';

    if (user == null) {
      return const Center(child: CircularProgressIndicator());
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(title: const Text('الملف الشخصي للمالك')),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _error != null
                ? Center(child: Text(_error!, style: const TextStyle(color: Colors.red)))
                : RefreshIndicator(
                    onRefresh: _fetchScans,
                    child: ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        // Profile Header
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                          elevation: 2,
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              children: [
                                Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    color: theme.primaryColor.withOpacity(0.1),
                                    shape: BoxShape.circle,
                                  ),
                                  child: Icon(
                                    Icons.person,
                                    size: 50,
                                    color: theme.primaryColor,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Text(
                                  user.name,
                                  style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  user.email,
                                  style: theme.textTheme.bodyLarge?.copyWith(color: theme.textTheme.bodySmall?.color),
                                ),
                                if (user.phone != null) ...[
                                  const SizedBox(height: 8),
                                  Text(
                                    user.phone,
                                    style: theme.textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        // Stats Section
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 1,
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('إحصائيات المالك', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                                const SizedBox(height: 16),
                                Row(
                                  children: [
                                    Expanded(
                                      child: _buildStatCard(context, 'عدد الأكواد التي تم مسحها', totalScans.toString(), Icons.qr_code_scanner),
                                    ),
                                    Expanded(
                                      child: _buildStatCard(context, 'عدد العملاء', uniqueUsers.toString(), Icons.person),
                                    ),
                                    Expanded(
                                      child: _buildStatCard(context, 'عدد الباقات', uniquePackages.toString(), Icons.card_giftcard),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                if (lastStation.isNotEmpty)
                                  Text('آخر محطة تم اختيارها: $lastStation', style: theme.textTheme.bodyMedium),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        // Scan Stats List
                        Card(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          elevation: 1,
                          child: Padding(
                            padding: const EdgeInsets.all(20),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('آخر الأكواد التي تم مسحها', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                                const SizedBox(height: 12),
                                if (_scans.isEmpty)
                                  Text('لا توجد عمليات مسح بعد', style: theme.textTheme.bodyMedium)
                                else
                                  ..._scans.reversed.take(10).map((scan) => ListTile(
                                        leading: const Icon(Icons.qr_code, color: Colors.blue),
                                        title: Text('المستخدم: ${scan['user']?['name'] ?? ''}'),
                                        subtitle: Text('الباقة: ${scan['package']?['name'] ?? ''}\nالمحطة: ${scan['washingPlace']?['name'] ?? ''}'),
                                        trailing: Text(scan['date'] != null ? scan['date'].toString().substring(0, 10) : ''),
                                      )),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(height: 24),
                        // QR Scan Button
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.qr_code_scanner),
                            label: const Text('الانتقال لمسح QR'),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              textStyle: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            ),
                            onPressed: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => const OwnerQRScanScreen(),
                                ),
                              ).then((_) => _fetchScans());
                            },
                          ),
                        ),
                        const SizedBox(height: 24),
                        // Logout Button
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: OutlinedButton(
                            onPressed: () async {
                              final confirmed = await showDialog<bool>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('تأكيد تسجيل الخروج'),
                                  content: const Text('هل أنت متأكد أنك تريد تسجيل الخروج؟'),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.of(context).pop(false),
                                      child: const Text('إلغاء'),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => Navigator.of(context).pop(true),
                                      child: const Text('تسجيل الخروج'),
                                    ),
                                  ],
                                ),
                              );
                              if (confirmed == true) {
                                await provider.logout();
                                Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
                              }
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              side: const BorderSide(color: Colors.red),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(
                              'تسجيل الخروج',
                              style: theme.textTheme.labelLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }

  Widget _buildStatCard(BuildContext context, String title, String value, IconData icon) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: theme.primaryColor,
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.primaryColor,
            ),
          ),
          Text(
            title,
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
} 