import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/constants.dart';
import '../providers/app_provider.dart';
import 'home_screen.dart';
import 'packages/package_selection_screen.dart';
import 'washing places/washing_places_screen.dart';

import 'user/user_profile_screen.dart';
import 'auth/login_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({Key? key}) : super(key: key);

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 0;

  List<Widget> _getScreens(BuildContext context) {
    final provider = context.read<AppProvider>();
    final isLoggedIn = provider.currentUser != null;

    return [
      const HomeScreen(),
      const PackageSelectionScreen(),
      const WashingPlacesScreen(),

      isLoggedIn ? const UserProfileScreen() : const LoginScreen(),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final screens = _getScreens(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: screens[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            // التحقق من تسجيل الدخول عند الضغط على تبويب الملف الشخصي
            if (index == 4) {
              // Profile tab index
              final provider = context.read<AppProvider>();
              if (provider.currentUser == null) {
                // إذا لم يكن مسجل دخول، انتقل إلى صفحة تسجيل الدخول
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const LoginScreen()),
                );
                return;
              }
            }

            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: kPrimaryColor,
          unselectedItemColor: Colors.grey,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.normal),
          items: const [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'الرئيسية'),
            BottomNavigationBarItem(
              icon: Icon(Icons.local_offer),
              label: 'الباقات',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.local_car_wash),
              label: 'محطات الغسيل',
            ),

            BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'الملف الشخصي',
            ),
          ],
        ),
      ),
    );
  }
}
