import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../core/config.dart';
import '../../core/services.dart';
import 'washing_place_map_screen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';

class WashingPlaceDetailsScreen extends StatefulWidget {
  final WashStation station;

  const WashingPlaceDetailsScreen({
    Key? key,
    required this.station,
  }) : super(key: key);

  @override
  State<WashingPlaceDetailsScreen> createState() =>
      _WashingPlaceDetailsScreenState();
}

class _WashingPlaceDetailsScreenState extends State<WashingPlaceDetailsScreen> {
  GoogleMapController? _mapController;
  bool _isMapReady = false;
  
  // Default coordinates (Riyadh, Saudi Arabia) - fallback if no coordinates from API
  static const LatLng _defaultLocation = LatLng(24.7136, 46.6753);

  @override
  void initState() {
    super.initState();
    // Initialize map after a short delay to ensure proper loading
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) {
        setState(() {
          _isMapReady = true;
        });
      }
    });
  }
  
  Future<LatLng> _getCoordinatesFromAddress(String address) async {
    try {
      // Use Google Geocoding API to convert address to coordinates
      const apiKey = MapsConfig.googleMapsApiKey;
      final encodedAddress = Uri.encodeComponent(address);
      final url = 'https://maps.googleapis.com/maps/api/geocode/json?address=$encodedAddress&key=$apiKey';
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          final location = data['results'][0]['geometry']['location'];
          return LatLng(location['lat'], location['lng']);
        }
      }
      
      // Fallback to default location if geocoding fails
      return _getStationCoordinates();
    } catch (e) {
      print('Geocoding error: $e');
      // Fallback to default location
      return _getStationCoordinates();
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final station = widget.station;
    final hasActivePackage = Provider.of<AppProvider>(context).selectedPackage != null;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text(station.name, style: theme.appBarTheme.titleTextStyle),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // بطاقة المحطة
              Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // شعار المحطة
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: theme.primaryColor.withOpacity(0.1),
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        station.isOpen ? Icons.local_car_wash : Icons.block,
                        size: 48,
                        color: station.isOpen
                            ? theme.primaryColor
                            : theme.iconTheme.color,
                      ),
                    ),

                    const SizedBox(height: 20),

                    Text(
                      station.name,
                      style: theme.textTheme.headlineMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      station.location,
                      style: theme.textTheme.bodyLarge
                          ?.copyWith(color: theme.textTheme.bodySmall?.color),
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 16),

                    // حالة المحطة
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: station.isOpen
                            ? Colors.green.withOpacity(0.1)
                            : Colors.red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        station.isOpen ? 'مفتوح الآن' : 'مغلق',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: station.isOpen ? Colors.green : Colors.red,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // خريطة الموقع
              Container(
                height: 200,
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    children: [
                      // Actual map widget with fallback for all platforms
                      _isMapReady
                          ? FutureBuilder<LatLng>(
                              future: _getCoordinatesFromAddress(station.location),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return Center(
                                    child: CircularProgressIndicator(color: theme.primaryColor),
                                  );
                                }
                                
                                final position = snapshot.data ?? const LatLng(24.7136, 46.6753);
                                
                                return GoogleMap(
                                  initialCameraPosition: CameraPosition(
                                    target: position,
                                    zoom: 15,
                                  ),
                                  markers: {
                                    Marker(
                                      markerId: MarkerId(station.id),
                                      position: position,
                                      infoWindow: InfoWindow(
                                        title: station.name,
                                        snippet: station.location,
                                      ),
                                    ),
                                  },
                                  onMapCreated: (controller) {
                                    _mapController = controller;
                                  },
                                  zoomControlsEnabled: false,
                                  mapToolbarEnabled: false,
                                  myLocationButtonEnabled: false,
                                );
                              },
                            )
                          : Container(
                              width: double.infinity,
                              height: double.infinity,
                              color: theme.primaryColor.withOpacity(0.1),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.map,
                                      size: 48,
                                      color: theme.primaryColor,
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'موقع المحطة',
                                      style: theme.textTheme.titleMedium?.copyWith(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      station.location,
                                      style: theme.textTheme.bodySmall,
                                      textAlign: TextAlign.center,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                      // Map overlay button
                      Positioned(
                        bottom: 12,
                        right: 12,
                        child: FloatingActionButton.small(
                          onPressed: () {
                            Navigator.pushNamed(
                              context,
                              '/washing-place-map',
                              arguments: {'station': station},
                            );
                          },
                          backgroundColor: theme.primaryColor,
                          child: const Icon(
                            Icons.fullscreen,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 24),

              // تفاصيل المحطة
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'تفاصيل المحطة',
                      style: theme.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildDetail(context, 'المسافة', station.distance,
                        Icons.location_on),
                    _buildDetail(
                        context, 'التقييم', '${station.rating}/5', Icons.star),
                    if (station.isNearest)
                      _buildDetail(
                          context, 'الحالة', 'الأقرب لك', Icons.near_me),
                    const SizedBox(height: 16),
                    Text(
                      'الخدمات المتاحة',
                      style: theme.textTheme.titleLarge
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 12),
                    ...station.availableServices
                        .map((service) => _buildService(context, service)),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // معلومات إضافية
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: theme.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'معلومات إضافية',
                      style: theme.textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 16),
                    _buildInfo(context, 'ساعات العمل: 24/7'),
                    _buildInfo(context, 'خدمة عملاء متاحة'),
                    _buildInfo(context, 'موقف سيارات مجاني'),
                    _buildInfo(context, 'مرافق نظافة متاحة'),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // أزرار الإجراءات
              if (station.isOpen) ...[
                if (!hasActivePackage) ...[
                  SizedBox(
                    height: 56,
                    child: ElevatedButton(
                      onPressed: () {
                        // التنقل إلى صفحة اختيار الباقة
                        Navigator.of(context).pushNamed('/package-selection');
                      },
                      child: Text(
                        'احجز الآن',
                        style: theme.textTheme.labelLarge
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                SizedBox(
                  height: 56,
                  child: OutlinedButton(
                    onPressed: () {
                      // فتح خريطة كاملة الشاشة
                      Navigator.pushNamed(
                        context,
                        '/washing-place-map',
                        arguments: {'station': station},
                      );
                    },
                    child: Text(
                      'عرض الخريطة كاملة',
                      style: theme.textTheme.labelLarge
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ] else ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey),
                  ),
                  child: Text(
                    'المحطة مغلقة حالياً',
                    style: theme.textTheme.bodyLarge
                        ?.copyWith(color: theme.textTheme.bodySmall?.color),
                    textAlign: TextAlign.center,
                  ),
                ),
              ],

              // Map Preview Section
              Container(
                margin: const EdgeInsets.only(top: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: theme.dividerColor,
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Icon(
                            Icons.map,
                            color: theme.primaryColor,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'الموقع على الخريطة',
                            style: theme.textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      height: 200,
                      decoration: const BoxDecoration(
                        borderRadius: BorderRadius.vertical(
                          bottom: Radius.circular(12),
                        ),
                      ),
                      child: ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          bottom: Radius.circular(12),
                        ),
                        child: _isMapReady
                            ? GoogleMap(
                                onMapCreated: (GoogleMapController controller) {
                                  _mapController = controller;
                                },
                                initialCameraPosition: CameraPosition(
                                  target: _getStationCoordinates(),
                                  zoom: 15,
                                ),
                                markers: {
                                  Marker(
                                    markerId: MarkerId(widget.station.id),
                                    position: _getStationCoordinates(),
                                    infoWindow: InfoWindow(
                                      title: widget.station.name,
                                      snippet: widget.station.location,
                                    ),
                                    icon: BitmapDescriptor.defaultMarkerWithHue(
                                      BitmapDescriptor.hueGreen,
                                    ),
                                  ),
                                },
                                myLocationEnabled: false,
                                myLocationButtonEnabled: false,
                                zoomControlsEnabled: false,
                                mapToolbarEnabled: false,
                                compassEnabled: false,
                                liteModeEnabled: true,
                              )
                            : Container(
                                color: theme.cardColor,
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.map,
                                        size: 48,
                                        color: theme.primaryColor,
                                      ),
                                      const SizedBox(height: 16),
                                      Text(
                                        'جاري تحميل الخريطة...',
                                        style: theme.textTheme.bodyLarge,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            Navigator.pushNamed(
                        context,
                        '/washing-place-map',
                        arguments: {'station': station},
                      );
                          },
                          icon: const Icon(Icons.fullscreen),
                          label: const Text('عرض الخريطة كاملة'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: theme.primaryColor,
                            side: BorderSide(color: theme.primaryColor),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetail(
      BuildContext context, String title, String value, IconData icon) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              icon,
              color: theme.primaryColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: theme.textTheme.bodySmall,
                ),
                Text(
                  value,
                  style: theme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildService(BuildContext context, String service) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: theme.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              Icons.check_circle,
              color: theme.primaryColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              service,
              style: theme.textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfo(BuildContext context, String text) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline,
            color: theme.iconTheme.color,
            size: 16,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: theme.textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }

  LatLng _getStationCoordinates() {
    // Default coordinates for Riyadh, Saudi Arabia
    return const LatLng(24.7136, 46.6753);
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }


}
