import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../core/services.dart';
import '../../core/config.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';

class WashingPlacesScreen extends StatefulWidget {
  const WashingPlacesScreen({Key? key}) : super(key: key);

  @override
  State<WashingPlacesScreen> createState() => _WashingPlacesScreenState();
}

class _WashingPlacesScreenState extends State<WashingPlacesScreen> with SingleTickerProviderStateMixin {
  List<WashStation> _stations = [];
  bool _isLoading = true;
  bool _isRefreshing = false; // For refreshing without full loading screen
  String? _errorMessage;
  late TabController _tabController;
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  bool _isMapReady = false;
  
  // Default coordinates (Riyadh, Saudi Arabia)
  static const LatLng _defaultLocation = LatLng(24.7136, 46.6753);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(_handleTabChange);
    _loadWashStations();
    
    // Initialize map after a short delay to ensure proper loading
    Future.delayed(const Duration(milliseconds: 100), () {
      if (mounted) {
        setState(() {
          _isMapReady = true;
        });
      }
    });
  }
  
  void _handleTabChange() {
    // Force rebuild when tab changes to update the floating action button
    if (mounted) {
      setState(() {});
    }
  }
  
  @override
  void dispose() {
    _tabController.removeListener(_handleTabChange);
    _tabController.dispose();
    _mapController?.dispose();
    super.dispose();
  }

  Future<void> _loadWashStations({bool isRefresh = false}) async {
    try {
      setState(() {
        if (isRefresh) {
          _isRefreshing = true;
        } else {
          _isLoading = true;
        }
        _errorMessage = null;
      });

      // Get actual data from API service
      final stations = await WashStationService.getStations();
      
      // Create markers for each station
      final markers = <Marker>{};
      for (final station in stations) {
        // Get coordinates for the station location
        final coordinates = await _getCoordinatesFromAddress(station.location);
        
        markers.add(
          Marker(
            markerId: MarkerId(station.id),
            position: coordinates,
            infoWindow: InfoWindow(
              title: station.name,
              snippet: station.location,
              onTap: () => _selectStation(station),
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(
              station.isOpen ? BitmapDescriptor.hueGreen : BitmapDescriptor.hueRed
            ),
          ),
        );
      }
      
      setState(() {
        _stations = stations;
        _markers = markers;
        _isLoading = false;
        _isRefreshing = false;
      });
      
      // If this is a refresh and we have a map controller, fit all markers
      if (isRefresh && _mapController != null && _markers.isNotEmpty) {
        _fitAllMarkers();
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _isRefreshing = false;
        _errorMessage = 'حدث خطأ في تحميل البيانات: ${e.toString()}';
      });
      print('Error loading wash stations: $e');
    }
  }
  
  Future<LatLng> _getCoordinatesFromAddress(String address) async {
    try {
      // Use Google Geocoding API to convert address to coordinates
      const apiKey = MapsConfig.googleMapsApiKey;
      final encodedAddress = Uri.encodeComponent(address);
      final url = 'https://maps.googleapis.com/maps/api/geocode/json?address=$encodedAddress&key=$apiKey';
      
      final response = await http.get(Uri.parse(url));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        
        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          final location = data['results'][0]['geometry']['location'];
          return LatLng(location['lat'], location['lng']);
        }
      }
      
      // Fallback to default location if geocoding fails
      return _defaultLocation;
    } catch (e) {
      print('Geocoding error: $e');
      return _defaultLocation;
    }
  }

  void _selectStation(WashStation station) {
    Navigator.of(context).pushNamed(
      '/washing-place-details',
      arguments: {'station': station},
    );
  }
  
  // Method to handle map camera movement to a specific station
  void _moveToStation(WashStation station) async {
    if (_mapController == null) return;
    
    final coordinates = await _getCoordinatesFromAddress(station.location);
    _mapController!.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: coordinates,
          zoom: 15.0,
        ),
      ),
    );
  }
  
  // Method to fit all markers on the map
  void _fitAllMarkers() {
    if (_mapController == null || _markers.isEmpty) return;
    
    // Calculate the bounds of all markers
    double minLat = 90.0;
    double maxLat = -90.0;
    double minLng = 180.0;
    double maxLng = -180.0;
    
    for (final marker in _markers) {
      final lat = marker.position.latitude;
      final lng = marker.position.longitude;
      
      minLat = lat < minLat ? lat : minLat;
      maxLat = lat > maxLat ? lat : maxLat;
      minLng = lng < minLng ? lng : minLng;
      maxLng = lng > maxLng ? lng : maxLng;
    }
    
    // Create a LatLngBounds object
    final bounds = LatLngBounds(
      southwest: LatLng(minLat, minLng),
      northeast: LatLng(maxLat, maxLng),
    );
    
    // Animate camera to show all markers with padding
    _mapController!.animateCamera(
      CameraUpdate.newLatLngBounds(bounds, 50.0),
    );
  }
  
  // Build a bottom sheet with station list for map navigation
  Widget _buildStationListForMap() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                const Icon(Icons.location_on, color: Colors.blue),
                const SizedBox(width: 8),
                Text(
                  'اختر محطة للانتقال إليها على الخريطة',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
          ),
          const Divider(),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: _stations.length,
              itemBuilder: (context, index) {
                final station = _stations[index];
                return ListTile(
                  leading: CircleAvatar(
                    backgroundColor: station.isOpen ? Colors.green.shade100 : Colors.red.shade100,
                    child: Icon(
                      station.isOpen ? Icons.check_circle : Icons.cancel,
                      color: station.isOpen ? Colors.green : Colors.red,
                      size: 20,
                    ),
                  ),
                  title: Text(station.name),
                  subtitle: Text(
                    station.location,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                  onTap: () {
                    _moveToStation(station);
                    Navigator.pop(context);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: Theme.of(context).scaffoldBackgroundColor,
          appBar: AppBar(
            title: Text('محطات الغسيل', style: Theme.of(context).appBarTheme.titleTextStyle),
            actions: [
              IconButton(
                icon: Icon(Icons.refresh, color: Theme.of(context).iconTheme.color),
                onPressed: _loadWashStations,
              ),
            ],
            bottom: TabBar(
              controller: _tabController,
              tabs: const [
                Tab(icon: Icon(Icons.list), text: 'قائمة'),
                Tab(icon: Icon(Icons.map), text: 'خريطة'),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: [
              _buildListView(),
              _buildMapView(),
            ],
          ),
          floatingActionButton: _tabController.index == 1 && _stations.isNotEmpty ? FloatingActionButton(
        onPressed: () {
          // Show a bottom sheet with station list for quick navigation on map
          showModalBottomSheet(
            context: context,
            builder: (context) => _buildStationListForMap(),
          );
        },
        child: const Icon(Icons.location_on),
        tooltip: 'اختر محطة',
      ) : null,
        ),
      );

  Widget _buildListView() {
    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(color: Theme.of(context).primaryColor),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _errorMessage!,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadWashStations,
              child: Text('إعادة المحاولة', style: Theme.of(context).textTheme.labelLarge),
            ),
          ],
        ),
      );
    }

    if (_stations.isEmpty) {
      return Center(
        child: Text(
          'لا توجد محطات غسيل متاحة',
          style: Theme.of(context).textTheme.bodyLarge,
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _stations.length,
      itemBuilder: (context, index) {
        final station = _stations[index];
        return Padding(
          padding: const EdgeInsets.only(bottom: 16),
          child: _buildStationCard(context, station),
        );
      },
    );
  }
  
  Widget _buildMapView() {
    if (_isLoading) {
      return Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor));
    }

    if (_errorMessage != null) {
      return Center(child: Text(_errorMessage!, style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: Colors.red)));
    }

    if (!_isMapReady) {
      return Center(child: CircularProgressIndicator(color: Theme.of(context).primaryColor));
    }
    
    return Stack(
      children: [
        GoogleMap(
          initialCameraPosition: CameraPosition(
            target: _defaultLocation,
            zoom: 10.0,
          ),
          markers: _markers,
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          mapToolbarEnabled: true,
          onMapCreated: (GoogleMapController controller) {
            _mapController = controller;
            // Fit all markers on the map after a short delay
            if (_markers.isNotEmpty) {
              Future.delayed(const Duration(milliseconds: 300), () {
                _fitAllMarkers();
              });
            }
          },
        ),
        Positioned(
          top: 16,
          right: 16,
          child: Column(
            children: [
              FloatingActionButton.small(
                 heroTag: 'refresh_map',
                 onPressed: _isRefreshing ? null : () {
                   _loadWashStations(isRefresh: true);
                 },
                 backgroundColor: Colors.white,
                 child: _isRefreshing 
                   ? SizedBox(
                       height: 20,
                       width: 20,
                       child: CircularProgressIndicator(
                         strokeWidth: 2,
                         color: Theme.of(context).primaryColor,
                       ),
                     )
                   : Icon(Icons.refresh, color: Theme.of(context).primaryColor),
               ),
              const SizedBox(height: 8),
              FloatingActionButton.small(
                heroTag: 'fit_markers',
                onPressed: _fitAllMarkers,
                backgroundColor: Colors.white,
                child: Icon(Icons.fit_screen, color: Theme.of(context).primaryColor),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStationCard(BuildContext context, WashStation station) =>
    InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: () => _selectStation(station),
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(16),
          border: station.isNearest
              ? Border.all(color: Theme.of(context).primaryColor, width: 2)
              : null,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: [
            if (station.isNearest)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(14)),
                ),
                child: Text(
                  'الأقرب لك',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              station.name,
                              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              station.location,
                              style: Theme.of(context).textTheme.bodySmall,
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: station.isOpen
                              ? Colors.green.withOpacity(0.1)
                              : Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          station.isOpen ? 'مفتوح' : 'مغلق',
                          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: station.isOpen ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      // Map icon button
                      IconButton(
                        icon: const Icon(Icons.map, color: Colors.blue),
                        tooltip: 'عرض على الخريطة',
                        onPressed: () {
                          Navigator.pushNamed(
                            context,
                            '/washing-place-map',
                            arguments: {'station': station},
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Theme.of(context).primaryColor,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        station.distance,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(width: 16),
                      const Icon(
                        Icons.star,
                        color: Colors.amber,
                        size: 16,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        station.rating.toString(),
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'الخدمات المتاحة:',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: station.availableServices
                        .map((service) => Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                service,
                                style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                  color: Theme.of(context).primaryColor,
                                ),
                              ),
                            ))
                        .toList(),
                  ),
                  const SizedBox(height: 16),
                  if (Provider.of<AppProvider>(context).selectedPackage == null)
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => _selectStation(station),
                        child: Text(
                          'عرض التفاصيل',
                          style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
}
