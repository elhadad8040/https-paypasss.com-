import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:newapp/core/services.dart';
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../core/config.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';

class WashingPlaceMapScreen extends StatefulWidget {
  final WashStation station;

  const WashingPlaceMapScreen({
    Key? key,
    required this.station,
  }) : super(key: key);

  @override
  State<WashingPlaceMapScreen> createState() => _WashingPlaceMapScreenState();
}

class _WashingPlaceMapScreenState extends State<WashingPlaceMapScreen> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  bool _isLoading = true;
  String? _errorMessage;
  bool _isMapReady = false;

  // Default coordinates (Riyadh, Saudi Arabia) - fallback if no coordinates from API
  static const LatLng _defaultLocation = LatLng(24.7136, 46.6753);

  @override
  void initState() {
    super.initState();
    _initializeMap();
  }

  Future<void> _initializeMap() async {
    try {
      setState(() {
        _isLoading = true;
        _errorMessage = null;
      });

      // Get coordinates for the station location
      final coordinates =
          await _getCoordinatesFromAddress(widget.station.location);

      setState(() {
        _markers = {
          Marker(
            markerId: MarkerId(widget.station.id),
            position: coordinates ?? _defaultLocation,
            infoWindow: InfoWindow(
              title: widget.station.name,
              snippet: widget.station.location,
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueGreen),
          ),
        };
        _isLoading = false;
        _isMapReady = true;
      });

      // Animate to the marker location
      if (_mapController != null && coordinates != null) {
        _mapController!.animateCamera(
          CameraUpdate.newLatLngZoom(coordinates, 15),
        );
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _errorMessage = 'حدث خطأ في تحميل الخريطة: ${e.toString()}';
        _isMapReady = false;
      });
      print('Map initialization error: $e');
    }
  }

  Future<LatLng?> _getCoordinatesFromAddress(String address) async {
    try {
      // Use Google Geocoding API to convert address to coordinates
      const apiKey = MapsConfig.googleMapsApiKey;
      final encodedAddress = Uri.encodeComponent(address);
      final url =
          'https://maps.googleapis.com/maps/api/geocode/json?address=$encodedAddress&key=$apiKey';

      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['status'] == 'OK' && data['results'].isNotEmpty) {
          final location = data['results'][0]['geometry']['location'];
          return LatLng(location['lat'], location['lng']);
        }
      }

      // Fallback to default location if geocoding fails
      return _defaultLocation;
    } catch (e) {
      print('Geocoding error: $e');
      // Fallback to default location
      return _defaultLocation;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final hasActivePackage = Provider.of<AppProvider>(context).selectedPackage != null;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text('موقع المحطة', style: theme.appBarTheme.titleTextStyle),
          actions: [
            IconButton(
              icon: Icon(Icons.my_location, color: theme.iconTheme.color),
              onPressed: _getCurrentLocation,
            ),
            IconButton(
              icon: Icon(Icons.directions, color: theme.iconTheme.color),
              onPressed: _openDirections,
            ),
          ],
        ),
        body: _isLoading
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: theme.primaryColor),
                    const SizedBox(height: 16),
                    Text(
                      'جاري تحميل الخريطة...',
                      style: theme.textTheme.bodyLarge,
                    ),
                  ],
                ),
              )
            : _errorMessage != null
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.error_outline,
                          color: theme.colorScheme.error,
                          size: 48,
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _errorMessage!,
                          style: theme.textTheme.bodyLarge,
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: _initializeMap,
                          child: const Text('إعادة المحاولة'),
                        ),
                      ],
                    ),
                  )
                : Column(
                    children: [
                      // Map Container
                      Expanded(
                        child: _isMapReady
                            ? GoogleMap(
                                onMapCreated: (GoogleMapController controller) {
                                  _mapController = controller;
                                  // Animate to marker after map is created
                                  if (_markers.isNotEmpty) {
                                    final marker = _markers.first;
                                    _mapController!.animateCamera(
                                      CameraUpdate.newLatLngZoom(
                                          marker.position, 15),
                                    );
                                  }
                                },
                                initialCameraPosition: const CameraPosition(
                                  target: _defaultLocation,
                                  zoom: 15,
                                ),
                                markers: _markers,
                                myLocationEnabled: true,
                                myLocationButtonEnabled: false,
                                zoomControlsEnabled: false,
                                mapToolbarEnabled: false,
                                compassEnabled: true,
                              )
                            : Container(
                                color: theme.cardColor,
                                child: Center(
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.map,
                                        size: 48,
                                        color: theme.primaryColor,
                                      ),
                                      const SizedBox(height: 16),
                                      Text(
                                        'جاري تحميل الخريطة...',
                                        style: theme.textTheme.bodyLarge,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                      ),

                      // Station Info Card
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: theme.cardColor,
                          borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(20),
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.1),
                              blurRadius: 10,
                              offset: const Offset(0, -5),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: theme.primaryColor.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(
                                    Icons.location_on,
                                    color: theme.primaryColor,
                                    size: 20,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        widget.station.name,
                                        style: theme.textTheme.titleLarge
                                            ?.copyWith(
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        widget.station.location,
                                        style: theme.textTheme.bodyMedium
                                            ?.copyWith(
                                          color:
                                              theme.textTheme.bodySmall?.color,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 4,
                                  ),
                                  decoration: BoxDecoration(
                                    color: widget.station.isOpen
                                        ? Colors.green.withOpacity(0.1)
                                        : Colors.red.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Text(
                                    widget.station.isOpen ? 'مفتوح' : 'مغلق',
                                    style: theme.textTheme.labelSmall?.copyWith(
                                      color: widget.station.isOpen
                                          ? Colors.green
                                          : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: _openDirections,
                                    icon: const Icon(Icons.directions),
                                    label: const Text('اتجاهات'),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: theme.primaryColor,
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 12),
                                if (!hasActivePackage)
                                  Expanded(
                                    child: ElevatedButton.icon(
                                      onPressed: _bookNow,
                                      icon: const Icon(Icons.book_online),
                                      label: const Text('احجز الآن'),
                                    ),
                                  ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
      ),
    );
  }

  void _getCurrentLocation() {
    // TODO: Implement current location functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('سيتم إضافة هذه الميزة قريباً'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
    );
  }

  void _openDirections() async {
    try {
      // Get the marker position
      if (_markers.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('لا يمكن العثور على موقع المحطة'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
        return;
      }

      final marker = _markers.first;
      final lat = marker.position.latitude;
      final lng = marker.position.longitude;

      // Use MapsService to open directions in Google Maps
      await MapsService.openLocationWithCoordinates(lat, lng,
          title: widget.station.name);
    } catch (e) {
      print('Error opening directions: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('حدث خطأ أثناء فتح الاتجاهات'),
          backgroundColor: Theme.of(context).colorScheme.error,
        ),
      );
    }
  }

  void _bookNow() {
    Navigator.of(context).pushNamed('/package-selection');
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }
}
