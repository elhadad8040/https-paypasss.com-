import 'package:flutter/material.dart';
import '../../core/constants.dart';
import '../../core/models.dart';
import 'package:provider/provider.dart';
import '../../providers/app_provider.dart';
import 'tip_payment_screen.dart';

class WashTrackingScreen extends StatefulWidget {
  final UserPackage userPackage;
  final VoidCallback? onWashCompleted;
  const WashTrackingScreen({Key? key, required this.userPackage, this.onWashCompleted}) : super(key: key);

  @override
  State<WashTrackingScreen> createState() => _WashTrackingScreenState();
}

class _WashTrackingScreenState extends State<WashTrackingScreen> {
  static const int totalSeconds = 30; // 30 minutes
  int secondsLeft = totalSeconds;
  late final Ticker _ticker;
  bool isCompleted = false;
  bool showRating = false;
  int rating = 0;
  String comment = '';
  bool isSubmitting = false;
  WashStation? selectedStation;
  bool isPickingStation = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _pickStation());
  }

  Future<void> _pickStation() async {
    final stations = Provider.of<AppProvider>(context, listen: false).stations;
    final picked = await showDialog<WashStation>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('اختر محطة الغسيل'),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: stations.length,
            itemBuilder: (context, index) {
              final station = stations[index];
              return ListTile(
                title: Text(station.name),
                subtitle: Text(station.location),
                trailing: Text(station.isOpen ? 'مفتوح' : 'مغلق', style: TextStyle(color: station.isOpen ? Colors.green : Colors.red)),
                onTap: () => Navigator.of(context).pop(station),
              );
            },
          ),
        ),
      ),
    );
    if (picked != null) {
      setState(() {
        selectedStation = picked;
        isPickingStation = false;
      });
      _startCountdown();
    } else {
      Navigator.of(context).pop();
    }
  }

  void _startCountdown() {
    _ticker = Ticker(_onTick);
    _ticker.start();
  }

  void _onTick(Duration elapsed) {
    if (!mounted) return;
    setState(() {
      secondsLeft = totalSeconds - elapsed.inSeconds;
      if (secondsLeft <= 0) {
        secondsLeft = 0;
        _ticker.stop();
        isCompleted = true;
        _showCompletionModal();
      }
    });
  }

  @override
  void dispose() {
    if (!isPickingStation) _ticker.dispose();
    super.dispose();
  }

  String _formatTime(int seconds) {
    final m = (seconds ~/ 60).toString().padLeft(2, '0');
    final s = (seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  void _showCompletionModal() async {
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: const Text('انتهى وقت الغسلة'),
          content: const Text('هل تم الانتهاء من الغسيل؟'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                setState(() {
                  showRating = true;
                });
              },
              child: const Text('نعم، أريد التقييم'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _showThankYouDialog();
              },
              child: const Text('لا، فقط إغلاق'),
            ),
          ],
        );
      },
    );
  }

  void _showThankYouDialog() {
    if (widget.onWashCompleted != null) {
      widget.onWashCompleted!();
    }
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('شكرًا لاستخدامك Paypass!'),
        content: const Text('نتمنى أن تكون تجربتك ممتازة.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop();
            },
            child: const Text('حسنًا'),
          ),
        ],
      ),
    );
  }

  void _showTipDialog() async {
    final tip = await showDialog<int>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('هل ترغب في إضافة بقشيش لمحطة الغسيل؟'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _tipOption(50),
            _tipOption(100),
            _tipOption(150),
            _tipOption(200),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('تخطي'),
          ),
        ],
      ),
    );
    if (tip != null && selectedStation != null) {
      // Navigate to TipPaymentScreen and wait for result
      final result = await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => TipPaymentScreen(
            tipAmount: tip,
            station: selectedStation!,
          ),
        ),
      );
      if (result == true) {
        _showThankYouDialog();
      }
    } else {
      _showThankYouDialog();
    }
  }

  Widget _tipOption(int amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: ElevatedButton(
        onPressed: () => Navigator.of(context).pop(amount),
        style: ElevatedButton.styleFrom(
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
        ),
        child: Text('إضافة بقشيش $amount ريال'),
      ),
    );
  }

  void _showTipPaymentDialog(int tipAmount) async {
    bool isPaying = false;
    bool paymentSuccess = false;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('دفع البقشيش'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('سيتم دفع البقشيش لمحطة الغسيل عبر بوابة الدفع.'),
              const SizedBox(height: 16),
              Text('المبلغ: $tipAmount ريال', style: const TextStyle(fontWeight: FontWeight.bold)),
              if (isPaying)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: CircularProgressIndicator(),
                ),
              if (paymentSuccess)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Icon(Icons.check_circle, color: Colors.green, size: 40),
                ),
            ],
          ),
          actions: [
            if (!isPaying && !paymentSuccess)
              ElevatedButton(
                onPressed: () async {
                  setState(() => isPaying = true);
                  await Future.delayed(const Duration(seconds: 2)); // Simulate payment
                  setState(() {
                    isPaying = false;
                    paymentSuccess = true;
                  });
                  await Future.delayed(const Duration(seconds: 1));
                  Navigator.of(context).pop();
                  _showThankYouDialog();
                },
                child: const Text('ادفع الآن'),
              ),
            if (!isPaying && !paymentSuccess)
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('إلغاء'),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRatingDialog() {
    return AlertDialog(
      title: const Text('قيّم تجربتك'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (i) => IconButton(
              icon: Icon(
                i < rating ? Icons.star : Icons.star_border,
                color: Colors.amber,
                size: 32,
              ),
              onPressed: () => setState(() => rating = i + 1),
            )),
          ),
          TextField(
            decoration: const InputDecoration(
              labelText: 'تعليق (اختياري)',
              border: OutlineInputBorder(),
            ),
            minLines: 1,
            maxLines: 3,
            onChanged: (v) => comment = v,
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => setState(() => showRating = false),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: isSubmitting || rating == 0
              ? null
              : () async {
                  setState(() => isSubmitting = true);
                  await Future.delayed(const Duration(seconds: 1)); // Demo submit
                  setState(() => isSubmitting = false);
                  setState(() => showRating = false);
                  _showTipDialog();
                },
          child: isSubmitting
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('إرسال'),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    if (isPickingStation) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('تتبع الغسلة'),
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('تتبع الغسلة'),
        backgroundColor: kPrimaryColor,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          Center(
            child: Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.local_car_wash, size: 64, color: kPrimaryColor),
                  const SizedBox(height: 16),
                  Text(
                    selectedStation != null ? 'المحطة: ${selectedStation!.name}' : '',
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'وقت الغسلة المتبقي',
                    style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _formatTime(secondsLeft),
                    style: theme.textTheme.displayMedium?.copyWith(
                      color: kPrimaryColor,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 24),
                  LinearProgressIndicator(
                    value: secondsLeft / totalSeconds,
                    minHeight: 10,
                    backgroundColor: Colors.grey[200],
                    color: kPrimaryColor,
                  ),
                  const SizedBox(height: 32),
                  Text(
                    'يرجى الانتظار حتى انتهاء الغسلة أو العودة لاحقًا.',
                    style: theme.textTheme.bodyLarge,
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          if (showRating)
            Center(
              child: _buildRatingDialog(),
            ),
        ],
      ),
    );
  }
}

// Simple Ticker class for countdown (since TickerProvider is not available in State)
class Ticker {
  final void Function(Duration) onTick;
  Duration _elapsed = Duration.zero;
  bool _isActive = false;
  late final Stopwatch _stopwatch;
  late final Duration _interval;

  Ticker(this.onTick, {Duration interval = const Duration(seconds: 1)}) {
    _interval = interval;
    _stopwatch = Stopwatch();
  }

  void start() {
    _isActive = true;
    _stopwatch.start();
    _tick();
  }

  void _tick() async {
    while (_isActive) {
      await Future.delayed(_interval);
      if (!_isActive) break;
      _elapsed = _stopwatch.elapsed;
      onTick(_elapsed);
    }
  }

  void stop() {
    _isActive = false;
    _stopwatch.stop();
  }

  void dispose() {
    stop();
  }
} 