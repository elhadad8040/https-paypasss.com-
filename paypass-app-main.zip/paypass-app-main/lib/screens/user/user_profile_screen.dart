import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/models.dart';
import '../../providers/app_provider.dart';
import '../auth/login_screen.dart';
import 'package:barcode_widget/barcode_widget.dart';
import 'package:flutter/services.dart';
import '../notifications_screen.dart';
import '../../core/services.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:convert';
import '../../core/api_service.dart';
import 'package:flutter/foundation.dart';
import 'package:newapp/screens/user/user_packages_screen.dart';

class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({Key? key}) : super(key: key);

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  int _carCount = 0;
  bool _isLoading = true;
  Map<String, dynamic>? _referralStatus;
  List<Map<String, dynamic>> _washHistory = [];
  List<UserPackage> _userPackages = [];

  @override
void initState() {
  super.initState();
  _loadUserData();
}

Future<void> _loadUserData() async {
  setState(() {
    _isLoading = true;
  });
  
  try {
    // Load all data concurrently
    await Future.wait([
      _loadReferralStatus(),
      _loadWashHistory(),
      _loadUserPackages(),
    ]);
  } catch (e) {
    // Handle any errors if needed
    print('Error loading user data: $e');
  } finally {
    // Always set loading to false, whether successful or not
    setState(() {
      _isLoading = false;
    });
  }
}

Future<void> _loadReferralStatus() async {
  try {
    final status = await UserService.getReferralStatus();
    setState(() {
      _referralStatus = status;
    });
  } catch (e) {
    // ignore error
  }
}

Future<void> _loadWashHistory() async {
  try {
    final history = await getWashHistory();
    setState(() {
      _washHistory = history;
    });
  } catch (e) {
    // ignore error
  }
}

Future<void> _loadUserPackages() async {
  try {
    final provider = Provider.of<AppProvider>(context, listen: false);
    final user = provider.currentUser;
    
    print('Loading user packages for user: ${user?.id}');
    print('Current user email: ${user?.email}');
    
    if (user != null) {
      print('Calling getUserPackagesByUserId with user ID: ${user.id}');
      final packages = await UserPackageService.getUserPackagesByUserId(user.id);
      print('Found ${packages.length} packages for user ${user.id}');
      
      for (int i = 0; i < packages.length; i++) {
        final package = packages[i];
        print('Package ${i + 1}: ID=${package.id}, Barcode=${package.barcode}, WashesLeft=${package.washesLeft}');
      }
      
      setState(() {
        _userPackages = packages;
      });
      print('Updated _userPackages state with ${_userPackages.length} packages');
    } else {
      print('No current user found, trying authenticated packages');
      // Fallback to authenticated user packages
    final packages = await UserPackageService.getUserPackages();
      print('Found ${packages.length} authenticated packages');
    setState(() {
      _userPackages = packages;
    });
    }
  } catch (e) {
    // Handle error if needed
    print('Error loading packages: $e');
  }
}

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final user = provider.currentUser;
    final isLoggedIn = user != null;
    final theme = Theme.of(context);

    if (!isLoggedIn) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: theme.scaffoldBackgroundColor,
          appBar: AppBar(
            title: Text('الملف الشخصي', style: theme.appBarTheme.titleTextStyle),
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.person,
                  size: 64,
                  color: theme.iconTheme.color,
                ),
                const SizedBox(height: 16),
                Text(
                  'يرجى تسجيل الدخول',
                  style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  'للعرض والوصول لملفك الشخصي',
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder: (context) => const LoginScreen(),
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kPrimaryColor,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 32,
                      vertical: 12,
                    ),
                  ),
                  child: const Text(
                    'تسجيل الدخول',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text('الملف الشخصي', style: theme.appBarTheme.titleTextStyle),
          actions: [
            IconButton(
              icon: Icon(Icons.notifications, color: theme.iconTheme.color),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (context) => const NotificationsScreen()),
                );
              },
            ),
            IconButton(
              icon: Icon(Icons.edit, color: theme.iconTheme.color),
              onPressed: () async {
                final provider = Provider.of<AppProvider>(context, listen: false);
                final user = provider.currentUser;
                if (user == null) return;
                final nameController = TextEditingController(text: user.name);
                final emailController = TextEditingController(text: user.email);
                final result = await showDialog<bool>(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: const Text('تعديل الملف الشخصي'),
                    content: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextField(
                          controller: nameController,
                          decoration: const InputDecoration(labelText: 'الاسم'),
                        ),
                        TextField(
                          controller: emailController,
                          decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
                        ),
                      ],
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: const Text('إلغاء'),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          await provider.updateProfile(nameController.text, emailController.text);
                          Navigator.of(context).pop(true);
                        },
                        child: const Text('حفظ'),
                      ),
                    ],
                  ),
                );
                if (result == true) {
                  setState(() {}); // Refresh UI
                }
              },
            ),
          ],
        ),
        body: _isLoading
            ? Center(
                child: CircularProgressIndicator(color: theme.primaryColor),
              )
            : user == null
                ? Center(
                    child: Text('حدث خطأ في تحميل البيانات', style: theme.textTheme.bodyLarge),
                  )
                : ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                        // Show generated QR code if exists
                        if (provider.generatedQrCode != null) ...[
                          Container(
                            padding: const EdgeInsets.all(20),
                            margin: const EdgeInsets.only(bottom: 24),
                            decoration: BoxDecoration(
                              color: theme.cardColor,
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.08),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Column(
                              children: [
                                Text('رمز الاستفادة من الباقة', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                                const SizedBox(height: 12),
                                BarcodeWidget(
                                  barcode: Barcode.qrCode(),
                                  data: provider.generatedQrCode!,
                                  width: 180,
                                  height: 180,
                                ),
                                const SizedBox(height: 12),
                                SelectableText(provider.generatedQrCode!, style: theme.textTheme.bodyMedium),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.copy),
                                      onPressed: () {
                                        Clipboard.setData(ClipboardData(text: provider.generatedQrCode!));
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          const SnackBar(content: Text('تم نسخ رمز QR!')),
                                        );
                                      },
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.share),
                                      onPressed: () {
                                        // TODO: Implement share logic if needed
                                      },
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                        // Profile Header
                        Container(
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 20,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: Column(
                            children: [
                              // Profile Picture
                              Container(
                                width: 100,
                                height: 100,
                                decoration: BoxDecoration(
                                  color: theme.primaryColor.withOpacity(0.1),
                                  shape: BoxShape.circle,
                                ),
                                child: Icon(
                                  Icons.person,
                                  size: 50,
                                  color: theme.primaryColor,
                                ),
                              ),
                              const SizedBox(height: 16),
                              Text(
                                user.name,
                                style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 8),
                              Text(
                                user.email,
                                style: theme.textTheme.bodyLarge?.copyWith(color: theme.textTheme.bodySmall?.color),
                              ),
                            ],
                          ),
                        ),
                        // Referral Link Section
                        if (user.referralCode != null) ...[
                          const SizedBox(height: 24),
                          Text(
                            'كود الإحالة الخاص بك',
                            style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          SelectableText(
                            user.referralCode!,
                            style: theme.textTheme.bodyLarge?.copyWith(color: kPrimaryColor, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 8),
                          ElevatedButton.icon(
                            onPressed: () {
                              final link = 'https://paypass-backend-five.vercel.app/register?ref=${user.referralCode}';
                              Clipboard.setData(ClipboardData(text: link));
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('تم نسخ رابط الإحالة!')),
                              );
                            },
                            icon: const Icon(Icons.copy),
                            label: const Text('نسخ رابط الإحالة'),
                            style: ElevatedButton.styleFrom(backgroundColor: kPrimaryColor),
                          ),
                        ],
                        // Referral Status Section
                        if (_referralStatus != null) ...[
                          const SizedBox(height: 24),
                          Text('حالة الإحالات والمكافآت', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          if ((_referralStatus!['sent'] as List).isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('الإحالات التي أرسلتها:', style: theme.textTheme.bodyLarge),
                                ...(_referralStatus!['sent'] as List).map((r) {
                                  final invitee = r['invitee'] != null ? r['invitee']['name'] ?? r['invitee']['email'] ?? '' : '';
                                  return ListTile(
                                    title: Text('إلى: $invitee'),
                                    subtitle: Text('الحالة: ${r['status']} | مكافأة: ${r['rewardGiven'] == true ? 'نعم' : 'لا'}'),
                                  );
                                }).toList(),
                              ],
                            ),
                          if ((_referralStatus!['received'] as List).isNotEmpty)
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('الإحالات التي استلمتها:', style: theme.textTheme.bodyLarge),
                                ...(_referralStatus!['received'] as List).map((r) {
                                  final inviter = r['inviter'] != null ? r['inviter']['name'] ?? r['inviter']['email'] ?? '' : '';
                                  return ListTile(
                                    title: Text('من: $inviter'),
                                    subtitle: Text('الحالة: ${r['status']} | مكافأة: ${r['rewardGiven'] == true ? 'نعم' : 'لا'}'),
                                  );
                                }).toList(),
                              ],
                            ),
                          if ((_referralStatus!['sent'] as List).isEmpty && (_referralStatus!['received'] as List).isEmpty)
                            Text('لا توجد إحالات حتى الآن', style: theme.textTheme.bodyMedium),
                        ],
                        // Wash History Section
                        const SizedBox(height: 24),
                        Text('سجل الغسلات', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                        const SizedBox(height: 8),
                        if (_washHistory.isEmpty)
                          Text('لا يوجد سجل غسلات بعد', style: theme.textTheme.bodyMedium),
                        if (_washHistory.isNotEmpty)
                          Column(
                            children: _washHistory.map((wash) {
                              final car = wash['car']?['make'] != null ? '${wash['car']['make']} ${wash['car']['model']}' : '';
                              final place = wash['washingPlace']?['name'] ?? '';
                              final date = wash['date'] != null ? DateTime.tryParse(wash['date']) : null;
                              final feedback = wash['feedback'];
                              return Card(
                                margin: const EdgeInsets.symmetric(vertical: 8),
                                child: ListTile(
                                  title: Text('السيارة: $car'),
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('المكان: $place'),
                                      if (date != null)
                                        Text('التاريخ: ${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}'),
                                      if (feedback != null)
                                        Row(
                                          children: [
                                            Icon(Icons.check_circle, color: Colors.green, size: 18),
                                            const SizedBox(width: 4),
                                            Text('تم إرسال التقييم'),
                                            if (feedback['photo'] != null && feedback['photo'].toString().isNotEmpty)
                                              Padding(
                                                padding: const EdgeInsets.only(right: 8.0),
                                                child: Icon(Icons.photo, color: Colors.blue, size: 18),
                                              ),
                                          ],
                                        )
                                      else
                                        Row(
                                          children: [
                                            Icon(Icons.info, color: Colors.orange, size: 18),
                                            const SizedBox(width: 4),
                                            Text('لم يتم إرسال التقييم بعد'),
                                            const SizedBox(width: 8),
                                            ElevatedButton(
                                              onPressed: () => _showFeedbackDialog(context, wash),
                                              child: const Text('إضافة تقييم'),
                                            ),
                                          ],
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),

                        const SizedBox(height: 24),

                        // User Stats
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'إحصائيات الحساب',
                                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              Row(
                                children: [
                                  Expanded(
                                    child: _buildStatCard(
                                      context,
                                      'السيارات',
                                      user.cars.length.toString(),
                                      Icons.directions_car,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: _buildStatCard(
                                      context,
                                      'الطلبات',
                                      user.orders.length.toString(),
                                      Icons.receipt,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),



                        const SizedBox(height: 24),

                        // User Packages Section - Replace with a button
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'باقاتي النشطة',
                                    style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                                  ),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: kPrimaryColor.withOpacity(0.1),
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Text(
                                      '${_userPackages.length} باقة',
                                      style: theme.textTheme.bodyMedium?.copyWith(
                                        color: kPrimaryColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 16),
                              if (_userPackages.isEmpty)
                                Center(
                                  child: Column(
                                    children: [
                                      Icon(
                                        Icons.qr_code,
                                        size: 48,
                                        color: Colors.grey[400],
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'لا توجد باقات نشطة',
                                        style: theme.textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'اشتر باقة جديدة لتبدأ في استخدام الخدمة',
                                        style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey[500]),
                                        textAlign: TextAlign.center,
                                      ),
                                    ],
                                  ),
                                ),
                              if (_userPackages.isNotEmpty)
                                Column(
                                  children: [
                                    // Show first 2 packages as preview
                                    ..._userPackages.take(2).map((up) => _buildUserPackagePreview(context, up)).toList(),
                                    if (_userPackages.length > 2) ...[
                                      const SizedBox(height: 12),
                                      Center(
                                        child: Text(
                                          'و ${_userPackages.length - 2} باقة أخرى',
                                          style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey[600]),
                                        ),
                                      ),
                                    ],
                                    const SizedBox(height: 16),
                                    SizedBox(
                                      width: double.infinity,
                                      child: ElevatedButton.icon(
                                        onPressed: () {
                                          Navigator.of(context).push(
                                            MaterialPageRoute(
                                              builder: (context) => UserPackagesScreen(userPackages: _userPackages),
                                            ),
                                          );
                                        },
                                        icon: const Icon(Icons.qr_code, size: 20),
                                        label: const Text('عرض جميع الباقات'),
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: kPrimaryColor,
                                          foregroundColor: Colors.white,
                                          padding: const EdgeInsets.symmetric(vertical: 12),
                                          shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(12),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Account Settings
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'إعدادات الحساب',
                                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              _buildSettingItem(
                                context,
                                'تعديل الملف الشخصي',
                                Icons.edit,
                                () {
                                  // Navigate to edit profile
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'تغيير كلمة المرور',
                                Icons.lock,
                                () {
                                  // Navigate to change password
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'الإشعارات',
                                Icons.notifications,
                                () {
                                  // Navigate to notifications settings
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'الخصوصية',
                                Icons.privacy_tip,
                                () {
                                  // Navigate to privacy settings
                                },
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Support & Help
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: theme.cardColor,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.1),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'الدعم والمساعدة',
                                style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                              ),
                              const SizedBox(height: 16),
                              _buildSettingItem(
                                context,
                                'مركز المساعدة',
                                Icons.help,
                                () {
                                  // Navigate to help center
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'تواصل معنا',
                                Icons.contact_support,
                                () {
                                  // Navigate to contact us
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'سياسة الخصوصية',
                                Icons.policy,
                                () {
                                  // Navigate to privacy policy
                                },
                              ),
                              _buildSettingItem(
                                context,
                                'شروط الاستخدام',
                                Icons.description,
                                () {
                                  // Navigate to terms of service
                                },
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Logout Button
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: OutlinedButton(
                            onPressed: () async {
                              final confirmed = await showDialog<bool>(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: const Text('تأكيد تسجيل الخروج'),
                                  content: const Text('هل أنت متأكد أنك تريد تسجيل الخروج؟'),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.of(context).pop(false),
                                      child: const Text('إلغاء'),
                                    ),
                                    ElevatedButton(
                                      onPressed: () => Navigator.of(context).pop(true),
                                      child: const Text('تسجيل الخروج'),
                                    ),
                                  ],
                                ),
                              );
                              if (confirmed == true) {
                                final provider = Provider.of<AppProvider>(context, listen: false);
                                await provider.logout();
                                Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
                              }
                            },
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.red,
                              side: const BorderSide(color: Colors.red),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            child: Text(
                              'تسجيل الخروج',
                              style: theme.textTheme.labelLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
      );
  }

  Widget _buildStatCard(BuildContext context, String title, String value, IconData icon) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.primaryColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: theme.primaryColor,
            size: 32,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: theme.textTheme.headlineMedium?.copyWith(
              fontWeight: FontWeight.bold,
              color: theme.primaryColor,
            ),
          ),
          Text(
            title,
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }

  Widget _buildSettingItem(BuildContext context, String title, IconData icon, VoidCallback onTap) {
    final theme = Theme.of(context);
    return ListTile(
      leading: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: theme.primaryColor.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(
          icon,
          color: theme.primaryColor,
          size: 20,
        ),
      ),
      title: Text(
        title,
        style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w500),
      ),
      trailing: Icon(
        Icons.arrow_forward_ios,
        size: 16,
        color: theme.iconTheme.color,
      ),
      onTap: onTap,
    );
  }

  void _showLogoutDialog(BuildContext context) {
    final theme = Theme.of(context);
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('تسجيل الخروج', style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
        content: Text('هل أنت متأكد من أنك تريد تسجيل الخروج؟', style: theme.textTheme.bodyMedium),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('إلغاء', style: theme.textTheme.labelLarge),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              // Perform logout
              Navigator.of(context).pushReplacementNamed('/');
            },
            child: Text(
              'تسجيل الخروج',
              style: theme.textTheme.labelLarge?.copyWith(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  void _showFeedbackDialog(BuildContext context, Map<String, dynamic> wash) {
    final _formKey = GlobalKey<FormState>();
    int _rating = 5;
    String _comment = '';
    File? _photo;
    bool _isSubmitting = false;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('إضافة تقييم'),
              content: SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('التقييم:'),
                      Row(
                        children: List.generate(5, (i) => IconButton(
                          icon: Icon(
                            i < _rating ? Icons.star : Icons.star_border,
                            color: Colors.amber,
                          ),
                          onPressed: () => setState(() => _rating = i + 1),
                        )),
                      ),
                      TextFormField(
                        decoration: const InputDecoration(labelText: 'تعليق (اختياري)'),
                        maxLines: 2,
                        onChanged: (v) => _comment = v,
                      ),
                      const SizedBox(height: 8),
                      if (_photo != null)
                        Image.file(_photo!, height: 80),
                      Row(
                        children: [
                          ElevatedButton.icon(
                            onPressed: () async {
                              final picker = ImagePicker();
                              final picked = await picker.pickImage(source: ImageSource.gallery);
                              if (picked != null) setState(() => _photo = File(picked.path));
                            },
                            icon: const Icon(Icons.photo),
                            label: const Text('إرفاق صورة'),
                          ),
                          if (_photo != null)
                            IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: () => setState(() => _photo = null),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('إلغاء'),
                ),
                ElevatedButton(
                  onPressed: _isSubmitting
                      ? null
                      : () async {
                          if (!_formKey.currentState!.validate()) return;
                          setState(() => _isSubmitting = true);
                          String? photoBase64;
                          if (_photo != null) {
                            final bytes = await _photo!.readAsBytes();
                            photoBase64 = base64Encode(bytes);
                          }
                          // Call feedback API
                          try {
                            await ApiService.createFeedbackRaw({
                              'user': wash['user'],
                              'wash': wash['_id'],
                              'washingPlace': wash['washingPlace']?['_id'],
                              'rating': _rating,
                              'comment': _comment,
                              'photo': photoBase64,
                            });
                            Navigator.of(context).pop();
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تم إرسال التقييم بنجاح!')),
                            );
                            _loadWashHistory();
                          } catch (e) {
                            setState(() => _isSubmitting = false);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('حدث خطأ أثناء إرسال التقييم')),);
                          }
                        },
                  child: _isSubmitting ? const CircularProgressIndicator() : const Text('إرسال'),
                ),
              ],
            );
          },
        );
      },
    );
  }



  Widget _buildUserPackageCard(BuildContext context, UserPackage up) {
    final theme = Theme.of(context);
    final isExpired = up.expiry.isBefore(DateTime.now());
    final daysLeft = up.expiry.difference(DateTime.now()).inDays;
    
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      color: isExpired ? Colors.grey[100] : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isExpired ? Colors.grey[300] : kPrimaryColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    isExpired ? Icons.access_time : Icons.qr_code,
                    color: isExpired ? Colors.grey[600] : kPrimaryColor,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                      Text(
                        up.package?.name ?? 'باقة غير معروفة',
                        style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      Text(
                        up.carSize != null ? kCarSizes.firstWhere((e) => e['key'] == up.carSize, orElse: () => {'name': 'غير محدد'})['name'] : 'سيارة غير معروفة',
                        style: theme.textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isExpired ? Colors.red[100] : Colors.green[100],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    isExpired ? 'منتهي' : 'نشط',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: isExpired ? Colors.red[700] : Colors.green[700],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
                    const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildPackageInfoItem(
                    context,
                    'الغسلات المتبقية',
                    '${up.washesLeft}',
                    Icons.local_car_wash,
                    isExpired ? Colors.grey : kPrimaryColor,
                  ),
                ),
                Expanded(
                  child: _buildPackageInfoItem(
                    context,
                    'الأيام المتبقية',
                    isExpired ? '0' : '$daysLeft',
                    Icons.schedule,
                    isExpired ? Colors.grey : Colors.orange,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Center(
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey[300]!),
                    ),
                    child: BarcodeWidget(
                  barcode: Barcode.qrCode(),
                  data: up.barcode,
                      width: 120,
                      height: 120,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'رمز QR للاستخدام',
                    style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 4),
                  SelectableText(
                    up.barcode,
                    style: theme.textTheme.bodySmall?.copyWith(
                      fontSize: 10,
                      color: Colors.grey[500],
                      fontFamily: 'monospace',
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Clipboard.setData(ClipboardData(text: up.barcode));
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('تم نسخ رمز QR!')),
                      );
                    },
                    icon: const Icon(Icons.copy, size: 16),
                    label: const Text('نسخ الرمز'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: kPrimaryColor,
                      side: BorderSide(color: kPrimaryColor),
                    ),
                ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: isExpired ? null : () {
                      _showQRCodeModal(context, up);
                    },
                    icon: const Icon(Icons.play_arrow, size: 16),
                    label: const Text('استخدام غسلة'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPrimaryColor,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

    Widget _buildUserPackagePreview(BuildContext context, UserPackage up) {
    final theme = Theme.of(context);
    final isExpired = up.expiry.isBefore(DateTime.now());
    final daysLeft = up.expiry.difference(DateTime.now()).inDays;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isExpired ? Colors.grey[300] : kPrimaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                isExpired ? Icons.access_time : Icons.qr_code,
                color: isExpired ? Colors.grey[600] : kPrimaryColor,
                size: 20,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    up.package?.name ?? 'باقة غير معروفة',
                    style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  Text(
                    up.carSize != null ? kCarSizes.firstWhere((e) => e['key'] == up.carSize, orElse: () => {'name': 'غير محدد'})['name'] : 'سيارة غير معروفة',
                    style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey[600]),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(Icons.local_car_wash, size: 14, color: kPrimaryColor),
                      const SizedBox(width: 4),
                      Text(
                        '${up.washesLeft} غسلة متبقية',
                        style: theme.textTheme.bodySmall?.copyWith(color: kPrimaryColor),
                      ),
                      const SizedBox(width: 12),
                      Icon(Icons.schedule, size: 14, color: Colors.orange),
                      const SizedBox(width: 4),
                      Text(
                        isExpired ? 'منتهي' : '$daysLeft يوم',
                        style: theme.textTheme.bodySmall?.copyWith(color: Colors.orange),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: isExpired ? Colors.red[100] : Colors.green[100],
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                isExpired ? 'منتهي' : 'نشط',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: isExpired ? Colors.red[700] : Colors.green[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showQRCodeModal(BuildContext context, UserPackage up) {
    final theme = Theme.of(context);
    showDialog(
      context: context,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          padding: const EdgeInsets.all(24),
          child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'استخدام الباقة',
                    style: theme.textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
                    const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey[300]!),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Text(
                      'امسح رمز QR هذا في محطة الغسيل',
                      style: theme.textTheme.bodyLarge?.copyWith(
                        fontWeight: FontWeight.w500,
                        color: Colors.grey[700],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey[200]!),
                      ),
                      child: BarcodeWidget(
                        barcode: Barcode.qrCode(),
                        data: up.barcode,
                        width: 200,
                        height: 200,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      up.barcode,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontFamily: 'monospace',
                        color: Colors.grey[600],
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${up.washesLeft} غسلة متبقية',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: kPrimaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: up.barcode));
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('تم نسخ رمز QR!')),
                        );
                      },
                      icon: const Icon(Icons.copy, size: 16),
                      label: const Text('نسخ الرمز'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: kPrimaryColor,
                        side: BorderSide(color: kPrimaryColor),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () {
                        Navigator.of(context).pop();
                        // TODO: Navigate to washing place selection or QR scanner
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('سيتم إضافة هذه الميزة قريباً')),
                        );
                      },
                      icon: const Icon(Icons.qr_code_scanner, size: 16),
                      label: const Text('مسح QR'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kPrimaryColor,
                        foregroundColor: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPackageInfoItem(BuildContext context, String label, String value, IconData icon, Color color) {
    final theme = Theme.of(context);
    return Column(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 4),
        Text(
          value,
          style: theme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(color: Colors.grey[600]),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
