import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants.dart';
import '../../core/api_service.dart';
import '../../providers/app_provider.dart';
import '../../core/models.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/foundation.dart';

class TipPaymentScreen extends StatefulWidget {
  final int tipAmount;
  final WashStation station;
  const TipPaymentScreen({Key? key, required this.tipAmount, required this.station}) : super(key: key);

  @override
  State<TipPaymentScreen> createState() => _TipPaymentScreenState();
}

class _TipPaymentScreenState extends State<TipPaymentScreen> {
  String _selectedPaymentMethod = 'mada';
  bool _isLoading = false;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _surnameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final user = Provider.of<AppProvider>(context, listen: false).currentUser;
    if (user != null) {
      _nameController.text = user.name.split(' ').first;
      _surnameController.text = user.name.split(' ').length > 1 ? user.name.split(' ').last : '';
      _phoneController.text = user.phone;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _surnameController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _startTipPayment() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);
    try {
      final provider = Provider.of<AppProvider>(context, listen: false);
      final user = provider.currentUser;
      if (user == null) throw Exception('الرجاء تسجيل الدخول أولاً');

      final merchantTransactionId = 'TIP_${DateTime.now().millisecondsSinceEpoch}';
      final response = await ApiService.createHyperpayCheckout(
        amount: widget.tipAmount.toDouble(),
        currency: 'SAR',
        merchantTransactionId: merchantTransactionId,
        customerEmail: user.email,
        billingStreet1: 'Riyadh',
        billingCity: 'Riyadh',
        billingState: 'Riyadh',
        billingCountry: 'SA',
        billingPostcode: '12211',
        customerGivenName: _nameController.text,
        customerSurname: _surnameController.text,
      );

      final checkoutId = response['id'];
      if (checkoutId == null) throw Exception('فشل في الحصول على checkoutId');
      if (!mounted) return;

      final params = [
        'checkoutId=$checkoutId',
        'userId=${user.id}',
        'stationId=${widget.station.id}',
        'tipAmount=${widget.tipAmount}',
        'billingStreet1=Riyadh',
        'billingCity=Riyadh',
        'billingState=Riyadh',
        'billingCountry=SA',
        'billingPostcode=12211',
        'customerGivenName=${Uri.encodeComponent(_nameController.text)}',
        'customerSurname=${Uri.encodeComponent(_surnameController.text)}',
        'customerPhone=${Uri.encodeComponent(_phoneController.text)}',
        'total=${widget.tipAmount.toStringAsFixed(2)}',
      ].join('&');
      final paymentUrl = 'https://mellifluous-eclair-f3f079.netlify.app/?$params';

      final result = await Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => _TipWebViewScreen(
          paymentUrl: paymentUrl,
          checkoutId: checkoutId,
          stationId: widget.station.id,
          tipAmount: widget.tipAmount,
        ),
      ));
      if (result == true) {
        Navigator.of(context).pop(true); // Success, return to previous
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('خطأ في الدفع: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Widget _buildPaymentOption(String value, String title, List<String> imageAssets, String subtitle) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: _selectedPaymentMethod == value ? kPrimaryColor : Colors.grey.shade300,
          width: _selectedPaymentMethod == value ? 2 : 1,
        ),
        borderRadius: BorderRadius.circular(12),
        color: _selectedPaymentMethod == value ? kPrimaryColor.withOpacity(0.1) : Colors.transparent,
      ),
      child: RadioListTile<String>(
        value: value,
        groupValue: _selectedPaymentMethod,
        onChanged: (newValue) {
          setState(() {
            _selectedPaymentMethod = newValue!;
          });
        },
        title: Row(
          children: [
            if (imageAssets.length == 1)
              Image.asset(imageAssets[0], width: 36, height: 36, fit: BoxFit.contain)
            else
              Row(
                children: [
                  Image.asset(imageAssets[0], width: 36, height: 36, fit: BoxFit.contain),
                  const SizedBox(width: 8),
                  Image.asset(imageAssets[1], width: 36, height: 36, fit: BoxFit.contain),
                ],
              ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(subtitle, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ],
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, String hint, {String? Function(String?)? validator, TextInputType? keyboardType}) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
      validator: validator,
      keyboardType: keyboardType,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('دفع بقشيش للمحطة'),
        backgroundColor: kPrimaryColor,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('محطة الغسيل: ${widget.station.name}', style: theme.textTheme.titleLarge),
              const SizedBox(height: 12),
              Text('المبلغ: ${widget.tipAmount} ريال', style: theme.textTheme.titleLarge?.copyWith(color: kPrimaryColor)),
              const SizedBox(height: 24),
              _buildPaymentOption('credit', 'بطاقة ائتمان', ['assets/payment logos/visa.png', 'assets/payment logos/mada.png'], 'Visa, Mada'),
              const SizedBox(height: 12),
              _buildPaymentOption('applepay', 'Apple Pay', ['assets/payment logos/applePay.png'], 'ادفع عبر Apple Pay'),
              const SizedBox(height: 24),
              _buildTextField(_nameController, 'الاسم الأول', 'أدخل الاسم الأول', validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null),
              const SizedBox(height: 12),
              _buildTextField(_surnameController, 'اسم العائلة', 'أدخل اسم العائلة', validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null),
              const SizedBox(height: 12),
              _buildTextField(_phoneController, 'رقم الجوال', '05xxxxxxxx', validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null, keyboardType: TextInputType.phone),
              const SizedBox(height: 24),
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _startTipPayment,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: kPrimaryColor,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: _isLoading
                      ? const CircularProgressIndicator(color: Colors.white)
                      : Text('إتمام الدفع - ${widget.tipAmount} ريال', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TipWebViewScreen extends StatefulWidget {
  final String paymentUrl;
  final String checkoutId;
  final String stationId;
  final int tipAmount;
  const _TipWebViewScreen({Key? key, required this.paymentUrl, required this.checkoutId, required this.stationId, required this.tipAmount}) : super(key: key);

  @override
  State<_TipWebViewScreen> createState() => _TipWebViewScreenState();
}

class _TipWebViewScreenState extends State<_TipWebViewScreen> {
  late final WebViewController _controller;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController();
    _controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            setState(() => _isLoading = true);
          },
          onPageFinished: (url) {
            setState(() => _isLoading = false);
            _checkPaymentResult(url);
          },
          onWebResourceError: (error) {
            print('WebView error: ${error.description}');
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.paymentUrl));
  }

  void _checkPaymentResult(String url) async {
    if (url.contains('payment-result.html')) {
      final uri = Uri.parse(url);
      final status = uri.queryParameters['status'];
      if (status == 'success') {
        // Call backend to record tip payment
        final provider = Provider.of<AppProvider>(context, listen: false);
        await provider.createTipPaymentFromHyperPay(
          transactionId: widget.checkoutId,
          stationId: widget.stationId,
          amount: widget.tipAmount.toDouble(),
        );
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.check_circle, color: Colors.green, size: 32),
                SizedBox(width: 8),
                Text('تم الدفع بنجاح'),
              ],
            ),
            content: const Text('تمت عملية دفع البقشيش بنجاح. شكراً لك!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).popUntil((route) => route.isFirst);
                },
                child: const Text('حسناً'),
              ),
            ],
          ),
        );
        Navigator.of(context).pop(true);
      } else {
        if (!mounted) return;
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (_) => AlertDialog(
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: const [
                Icon(Icons.error, color: Colors.red, size: 32),
                SizedBox(width: 8),
                Text('فشل الدفع'),
              ],
            ),
            content: const Text('فشلت عملية الدفع. يرجى المحاولة مرة أخرى.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                },
                child: const Text('حسناً'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إتمام دفع البقشيش'),
        backgroundColor: kPrimaryColor,
        foregroundColor: Colors.white,
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('جاري المعالجة', style: TextStyle(fontSize: 18)),
                ],
              ),
            ),
        ],
      ),
    );
  }
} 