import 'package:flutter/material.dart';
import 'package:qr_code_scanner_plus/qr_code_scanner_plus.dart';
import 'package:provider/provider.dart';
import '../core/api_service.dart';
import '../providers/app_provider.dart';

class OwnerQRScanScreen extends StatefulWidget {
  const OwnerQRScanScreen({Key? key}) : super();

  @override
  State<OwnerQRScanScreen> createState() => _OwnerQRScanScreenState();
}

class _OwnerQRScanScreenState extends State<OwnerQRScanScreen> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? controller;
  bool _isProcessing = false;
  String? _resultMessage;
  Map<String, dynamic>? _infoData;
  int? _washesLeft;
  String? _scannedBarcode;
  String? _selectedStationId;

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void _onQRViewCreated(QRViewController ctrl) {
    controller = ctrl;
    controller!.scannedDataStream.listen((scanData) async {
      if (_isProcessing) return;
      setState(() => _isProcessing = true);
      try {
        final response = await ApiService.scanOwnerInfo(scanData.code!);
        setState(() {
          _infoData = response;
          _washesLeft = response['washesLeft'] as int?;
          _scannedBarcode = scanData.code;
          _resultMessage = null;
        });
      } catch (e) {
        setState(() {
          _resultMessage = 'حدث خطأ: $e';
          _infoData = null;
          _washesLeft = null;
          _scannedBarcode = null;
        });
      } finally {
        setState(() => _isProcessing = false);
      }
    });
  }

  Future<void> _onConfirm() async {
    if (_scannedBarcode == null || _selectedStationId == null) return;
    setState(() => _isProcessing = true);
    try {
      final response = await ApiService.startOwnerWash(_scannedBarcode!, _selectedStationId!);
      setState(() {
        _resultMessage = response['message'] ?? 'تم بدء الغسيل بنجاح';
        _infoData = null;
        _washesLeft = null;
        _scannedBarcode = null;
        _selectedStationId = null;
      });
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تم بدء الغسيل'),
          content: Text(_resultMessage ?? 'تم تأكيد بدء عملية الغسيل بنجاح!'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('حسناً'),
            ),
          ],
        ),
      );
    } catch (e) {
      setState(() {
        _resultMessage = 'حدث خطأ أثناء بدء الغسيل: $e';
      });
    } finally {
      setState(() => _isProcessing = false);
    }
  }

  Widget _buildUserInfo() {
    if (_infoData == null) return const SizedBox.shrink();
    final user = _infoData!['user'] as Map<String, dynamic>?;
    final car = _infoData!['car'] as Map<String, dynamic>?;
    final pkg = _infoData!['package'] as Map<String, dynamic>?;
    final carSize = _infoData!['carSize'];
    return Card(
      margin: const EdgeInsets.all(16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (user != null) ...[
              Text('العميل: ${user['name'] ?? ''}', style: const TextStyle(fontSize: 18)),
              Text('البريد: ${user['email'] ?? ''}', style: const TextStyle(fontSize: 16)),
            ],
            if (car != null) ...[
              const SizedBox(height: 8),
              Text('السيارة: ${car['model'] ?? ''} - ${car['plate'] ?? ''}', style: const TextStyle(fontSize: 16)),
            ],
            if (pkg != null) ...[
              const SizedBox(height: 8),
              Text('الباقة: ${pkg['name'] ?? ''}', style: const TextStyle(fontSize: 16)),
            ],
            if (carSize != null) ...[
              const SizedBox(height: 8),
              Text('حجم السيارة: $carSize', style: const TextStyle(fontSize: 16)),
            ],
            if (_washesLeft != null) ...[
              const SizedBox(height: 8),
              Text('عدد الغسلات المتبقية: $_washesLeft', style: const TextStyle(fontSize: 16)),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final stations = Provider.of<AppProvider>(context).stations;
    return Scaffold(
      appBar: AppBar(title: const Text('مسح رمز QR للعميل')),
      body: Column(
        children: [
          Expanded(
            flex: 4,
            child: QRView(
              key: qrKey,
              onQRViewCreated: _onQRViewCreated,
            ),
          ),
          if (_isProcessing) const LinearProgressIndicator(),
          if (_infoData != null) ...[
            _buildUserInfo(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedStationId,
                    items: stations.map((station) => DropdownMenuItem(
                      value: station.id,
                      child: Text(station.name),
                    )).toList(),
                    onChanged: (val) => setState(() => _selectedStationId = val),
                    decoration: const InputDecoration(
                      labelText: 'اختر محطة الغسيل',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _isProcessing || _selectedStationId == null ? null : _onConfirm,
                      child: const Text('تأكيد بدء الغسيل'),
                    ),
                  ),
                ],
              ),
            ),
          ] else if (_resultMessage != null) ...[
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(_resultMessage!, style: const TextStyle(fontSize: 18)),
            ),
          ],
        ],
      ),
    );
  }
}