import 'package:flutter/material.dart';
import '../core/maps_helper.dart';
import '../core/config.dart';

class MapsTestScreen extends StatefulWidget {
  const MapsTestScreen({Key? key}) : super(key: key);

  @override
  State<MapsTestScreen> createState() => _MapsTestScreenState();
}

class _MapsTestScreenState extends State<MapsTestScreen> {
  bool _isLoading = true;
  String _status = '';
  String _error = '';

  @override
  void initState() {
    super.initState();
    _runTests();
  }

  Future<void> _runTests() async {
    setState(() {
      _isLoading = true;
      _status = '';
      _error = '';
    });

    try {
      // Test 1: API Key validation
      final apiKeyStatus = MapsHelper.getApiKeyStatus();
      final isApiKeyValid = MapsHelper.isApiKeyValid();
      
      setState(() {
        _status += 'API Key Status: $apiKeyStatus\n';
        _status += 'API Key Valid: $isApiKeyValid\n\n';
      });

      // Test 2: Maps initialization
      final isMapsInitialized = await MapsHelper.testMapsInitialization();
      
      setState(() {
        _status += 'Maps Initialization: ${isMapsInitialized ? 'SUCCESS' : 'FAILED'}\n';
        if (!isMapsInitialized) {
          _error = MapsHelper.getLastError() ?? 'Unknown error';
        }
      });

    } catch (e) {
      setState(() {
        _error = e.toString();
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        appBar: AppBar(
          title: Text('اختبار خرائط جوجل', style: theme.appBarTheme.titleTextStyle),
          actions: [
            IconButton(
              icon: Icon(Icons.refresh, color: theme.iconTheme.color),
              onPressed: _runTests,
            ),
          ],
        ),
        body: _isLoading
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircularProgressIndicator(color: theme.primaryColor),
                    const SizedBox(height: 16),
                    Text(
                      'جاري اختبار خرائط جوجل...',
                      style: theme.textTheme.bodyLarge,
                    ),
                  ],
                ),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'نتائج الاختبار',
                              style: theme.textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              _status,
                              style: theme.textTheme.bodyMedium,
                            ),
                            if (_error.isNotEmpty) ...[
                              const SizedBox(height: 16),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: Colors.red.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: Colors.red),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'خطأ:',
                                      style: theme.textTheme.titleSmall?.copyWith(
                                        color: Colors.red,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      _error,
                                      style: theme.textTheme.bodySmall?.copyWith(
                                        color: Colors.red,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'معلومات التكوين',
                              style: theme.textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 16),
                            Text(
                              'API Key: ${MapsConfig.googleMapsApiKey.substring(0, 10)}...',
                              style: theme.textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Base URL: ${MapsConfig.googleMapsBaseUrl}',
                              style: theme.textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Search URL: ${MapsConfig.googleMapsSearchUrl}',
                              style: theme.textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Default Zoom: ${MapsConfig.defaultZoomLevel}',
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'حلول للمشاكل الشائعة',
                              style: theme.textTheme.titleLarge?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 16),
                            _buildSolution(
                              'مفتاح API غير صحيح',
                              'تأكد من أن مفتاح API صحيح ومفعل في Google Cloud Console',
                            ),
                            _buildSolution(
                              'مشكلة في التكوين',
                              'تأكد من إضافة مفتاح API في AndroidManifest.xml و Info.plist',
                            ),
                            _buildSolution(
                              'مشكلة في الشبكة',
                              'تأكد من وجود اتصال بالإنترنت',
                            ),
                            _buildSolution(
                              'مشكلة في التطبيق',
                              'أعد تشغيل التطبيق بعد التغييرات',
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildSolution(String title, String description) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '• $title',
            style: theme.textTheme.titleSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            description,
            style: theme.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
} 