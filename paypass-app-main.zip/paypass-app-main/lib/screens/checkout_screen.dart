import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/models.dart';
import 'package:provider/provider.dart';
import '../providers/app_provider.dart';
import '../main.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<AppProvider>(context);
    final package = provider.selectedPackage;
    final carSizeKey = provider.selectedCarSize;
    final carSize = kCarSizes.firstWhere((e) => e['key'] == carSizeKey, orElse: () => <String, dynamic>{});
    final bool isVip = (package?.name.contains('VIP') ?? false) || (package?.name.contains('فاخرة') ?? false);
    final double price = isVip
      ? (package?.price ?? 0)
      : (package?.price ?? 0) * (carSize['priceFactor'] ?? 1.0);
    final double vat = price * 0.15;
    double total = price + vat;
    total = total.ceilToDouble();
    final double? originalPrice = (package?.originalPrice != null && package?.originalPrice != package?.price)
      ? (isVip ? package!.originalPrice! : package!.originalPrice! * (carSize['priceFactor'] ?? 1.0))
      : null;

    // Get hotel info from arguments if present, else from provider
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
    final hotelInfo = (args != null && args['hotelName'] != null)
        ? args
        : (provider.hotelInfo ?? {});
    final hotelName = hotelInfo['hotelName'] ?? '';
    final guestName = hotelInfo['guestName'] ?? '';
    final guestEmail = hotelInfo['guestEmail'] ?? '';
    final roomNumber = hotelInfo['roomNumber'] ?? '';
    final hasHotel = hotelName.isNotEmpty;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          title: const Text('مراجعة الباقة المختارة'),
          backgroundColor: kPrimaryColor,
          foregroundColor: Colors.white,
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Flexible(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                package?.name ?? '',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: kPrimaryColor,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 8),
                              Text('حجم السيارة: ${carSize['name'] ?? ''}', style: const TextStyle(fontSize: 16)),
                              Text('عدد الغسلات: ${package?.washes ?? ''}', style: const TextStyle(fontSize: 16)),
                              if (originalPrice != null)
                                Row(
                                  children: [
                                    Text(
                                      '${originalPrice.toStringAsFixed(0)} ريال',
                                      style: const TextStyle(
                                        decoration: TextDecoration.lineThrough,
                                        color: Colors.grey,
                                        fontSize: 16,
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    const Text('السعر الأساسي', style: TextStyle(fontSize: 14, color: Colors.grey)),
                                  ],
                                ),
                            ],
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: kPrimaryColor.withOpacity(0.08),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            children: [
                              const Icon(Icons.card_giftcard, color: kPrimaryColor, size: 32),
                              const SizedBox(height: 8),
                              Text(
                                '${total.toStringAsFixed(0)} ريال',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22,
                                  color: kPrimaryColor,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('السعر الأساسي:', style: TextStyle(fontSize: 16)),
                        Text('${price.toStringAsFixed(0)} ريال', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('ضريبة القيمة المضافة:', style: TextStyle(fontSize: 16)),
                        Text('${vat.toStringAsFixed(0)} ريال', style: const TextStyle(fontWeight: FontWeight.bold)),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('المجموع:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: kPrimaryColor)),
                        Text('${total.toStringAsFixed(0)} ريال', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: kPrimaryColor)),
                      ],
                    ),
                  ],
                ),
              ),
              if (hasHotel) ...[
                const SizedBox(height: 24),
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.08),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('معلومات الفندق', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: kPrimaryColor)),
                      const SizedBox(height: 12),
                      _infoRow('اسم الفندق', hotelName),
                      _infoRow('اسم النزيل', guestName),
                      if (guestEmail.isNotEmpty) _infoRow('البريد الإلكتروني', guestEmail),
                      if (roomNumber.isNotEmpty) _infoRow('رقم الغرفة', roomNumber),
                    ],
                  ),
                ),
              ],
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.08),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('المميزات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: kPrimaryColor)),
                    const SizedBox(height: 12),
                    _featureRow('18 غسلة للاستخدام خلال فترة الباقة'),
                    _featureRow('إمكانية استخدام غسلات الباقة في أي محطة ضمن شبكة PayPass'),
                    _featureRow('صلاحية الباقة 18 شهر من تاريخ الشراء'),
                    _featureRow('خدمة عملاء ودعم فني 24/7'),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              SizedBox(
                height: 56,
                child: ElevatedButton(
                  onPressed: () async {
                    showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (_) => const AnimatedAppLoading(),
                    );
                    await Future.delayed(const Duration(seconds: 2));
                    if (Navigator.of(context).canPop()) Navigator.of(context).pop();
                    Navigator.of(context).pushNamed(
                      '/payment',
                      arguments: {
                        if (hasHotel) ...{
                          'hotelName': hotelName,
                          'guestName': guestName,
                          'guestEmail': guestEmail,
                          'roomNumber': roomNumber,
                        }
                      },
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'متابعة إلى الدفع',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),
    );
  }

  Widget _featureRow(String text) => Row(
    children: [
      const Icon(Icons.check_circle, color: kPrimaryColor, size: 20),
      const SizedBox(width: 8),
      Expanded(
        child: Text(
          text,
          style: const TextStyle(fontSize: 16),
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          softWrap: true,
        ),
      ),
    ],
  );

  Widget _infoRow(String label, String value) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
      Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    ],
  );
} 