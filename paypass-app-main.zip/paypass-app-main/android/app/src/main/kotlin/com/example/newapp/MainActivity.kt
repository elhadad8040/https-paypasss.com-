package com.example.newapp

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log

class MainActivity : FlutterActivity() {
    private val CHANNEL = "payment_result_channel"
    
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "payment_result" -> {
                    try {
                        val paymentData = call.arguments as? Map<*, *>
                        if (paymentData != null) {
                            // Convert to Map<String, dynamic> for Dart
                            val convertedData = paymentData.mapKeys { it.key.toString() }
                            Log.d("PaymentHandler", "Received payment result: $convertedData")
                            result.success(null)
                        } else {
                            result.error("INVALID_ARGUMENTS", "Payment data is null", null)
                        }
                    } catch (e: Exception) {
                        Log.e("PaymentHandler", "Error handling payment result", e)
                        result.error("HANDLER_ERROR", e.message, null)
                    }
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Handle deep links or external URLs that might contain payment results
        intent?.data?.let { uri ->
            handlePaymentResultFromUri(uri)
        }
    }
    
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        
        // Handle new intents that might contain payment results
        intent.data?.let { uri ->
            handlePaymentResultFromUri(uri)
        }
    }
    
    private fun handlePaymentResultFromUri(uri: Uri) {
        try {
            val transactionId = uri.getQueryParameter("id")
            val resourcePath = uri.getQueryParameter("resourcePath")
            val success = uri.getQueryParameter("success")?.toBoolean() ?: false
            val message = uri.getQueryParameter("message") ?: ""
            
            if (transactionId != null) {
                val paymentData = mapOf(
                    "success" to success,
                    "transactionId" to transactionId,
                    "message" to message,
                    "resourcePath" to (resourcePath ?: "")
                )
                
                Log.d("PaymentHandler", "Payment result from URI: $paymentData")
                
                // Send to Flutter via MethodChannel
                flutterEngine?.dartExecutor?.binaryMessenger?.let { messenger ->
                    MethodChannel(messenger, CHANNEL).invokeMethod("payment_result", paymentData)
                }
            }
        } catch (e: Exception) {
            Log.e("PaymentHandler", "Error handling payment result from URI", e)
        }
    }
}
